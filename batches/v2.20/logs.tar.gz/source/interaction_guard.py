"""Bounded repeated NPC visits; animation/text changes are not task progress."""
import json
from collections import OrderedDict

from .navigation import interrupted


def progress_key(state):
    return json.dumps({
        'objective': state.get('verified_objective', {}).get('id'),
        'bag': state.get('bag', []),
        'badges': state.get('player', {}).get('badges', []),
        'party': [{k: p.get(k) for k in ('species_id', 'level', 'hp', 'max_hp', 'status', 'moves')}
                  for p in state.get('party', [])],
    }, sort_keys=True)


def facing_target(state):
    pos = state.get('player', {}).get('position', {})
    dx, dy = {'up': (0,-1), 'down': (0,1), 'left': (-1,0), 'right': (1,0)}.get(
        state.get('player', {}).get('facing'), (0,0))
    return next((t['id'] for t in state.get('navigation', {}).get('targets', [])
                 if t['kind'] == 'interact' and t['x'] == pos.get('x', -999)+dx
                 and t['y'] == pos.get('y', -999)+dy), None)


class InteractionGuard:
    def __init__(self):
        self.visits = OrderedDict()
        self.pending = None

    def observe(self, state):
        current = state.get('map', {}).get('map_id')
        signature = progress_key(state)
        if self.pending and not interrupted(state):
            key, before = self.pending
            if key[0] == current:
                old_signature, count = self.visits.get(key, (None, 0))
                count = count if old_signature == signature else 0
                self.visits[key] = (signature, count+1 if before == signature else 0)
                self.visits.move_to_end(key)
            self.pending = None
        while len(self.visits) > 32:
            self.visits.popitem(last=False)
        blocked = [target for (map_id, target), (seen, count) in self.visits.items()
                   if map_id == current and count >= 2 and seen == signature]
        if state.get('verified_objective', {}).get('id') == 'obtain_starter':
            blocked = []  # Uncompleted scripted starter dialogue is not optional entertainment.
        nurses = {t['id'] for t in state.get('navigation', {}).get('targets', [])
                  if t.get('label', '').startswith('Nurse')}
        blocked = [target for target in blocked if target not in nurses]
        # Never suppress inputs needed to finish a conversation or battle.
        if interrupted(state):
            return []
        actions = ['go:'+target for target in blocked]
        if facing_target(state) in blocked:
            actions += ['confirm', 'fast_confirm']
        return actions

    def record(self, state, action, result):
        if self.pending or interrupted(state):
            return
        target = None
        if action.startswith('go:') and result.get('reason') == 'interacted':
            target = action[3:]
        elif action in ('confirm', 'fast_confirm'):
            target = facing_target(state)
        if target:
            self.pending = ((state.get('map', {}).get('map_id'), target), progress_key(state))
