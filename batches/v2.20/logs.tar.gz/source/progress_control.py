"""Bounded progress and repeated-route evidence for the full controller treatment."""
from collections import Counter, deque

from .interaction_guard import InteractionGuard


class ProgressControl:
    def __init__(self):
        self.edges = deque(maxlen=16)
        self.routes = {}
        self.pending = None
        self.positions = set()
        self.last_progress = 0
        self.objective = None
        self.healing = False
        self.interactions = InteractionGuard()

    def observe(self, state, elapsed):
        map_id = state.get('map', {}).get('map_id')
        if self.pending:
            origin, action = self.pending
            if map_id != origin:
                self.edges.append((origin, map_id))
                self.routes[(origin, action)] = map_id
                while len(self.routes) > 64:
                    del self.routes[next(iter(self.routes))]
            self.pending = None
        party = state.get('party', [])
        healthy = any(p.get('hp', 0) >= .8 * max(1, p.get('max_hp', 1)) for p in party)
        weak = bool(party) and all(p.get('hp', 0) < .3 * max(1, p.get('max_hp', 1)) for p in party)
        if self.healing and healthy:
            self.healing = False
        if weak:
            self.healing = True
        # Battle commands remain available; retreat starts once the encounter ends.
        if self.healing and state.get('verified_objective'):
            state['verified_objective'] = {
                'id': 'recover_team',
                'instruction': 'Resolve the current battle safely. Then reach the nearest known Pokemon Center and speak to its nurse. From Viridian Forest retreat through the south gate to Viridian City if Pewter is not yet reached. Resume the journey after healing.',
                'success_evidence': 'At least one party member recovers to 80 percent HP.',
                'source': 'Explicit recovery heuristic: all party members below 30 percent HP.'}
        objective = state.get('verified_objective', {}).get('id')
        # Entering/leaving the south gate is not a new strategic objective.
        objective = 'traverse_forest' if objective in ('reach_forest', 'cross_forest') else objective
        if objective != self.objective:
            self.edges.clear()
            self.positions.clear()
            self.last_progress = elapsed
            self.objective = objective
        pos = state.get('player', {}).get('position', {})
        cell = (map_id, pos.get('x'), pos.get('y'))
        if cell not in self.positions:
            self.positions.add(cell)
            self.last_progress = elapsed
            # A hard cap avoids retaining an unbounded exploration trace.
            if len(self.positions) > 2048:
                self.positions = {cell}
        counts = Counter(self.edges)
        cycling = {dest for (origin, dest), count in counts.items() if origin == map_id and count >= 3}
        avoid = [action for (origin, action), dest in self.routes.items()
                 if origin == map_id and dest in cycling]
        repeated_interactions = self.interactions.observe(state)
        return {'repeated_interaction_actions': repeated_interactions,
                'repeated_return_actions': avoid[:12],
                'seconds_without_new_position': round(max(0, elapsed-self.last_progress)),
                'replan': bool(cycling) or bool(repeated_interactions) or elapsed-self.last_progress >= 120,
                'healing': self.healing,
                'instruction': 'Commit to an untried route toward the objective. Repeated doors leading to the same destination are one failed route, not new exploration. Cancel a retained route only to recover or pursue a materially different plan.'}

    def record(self, state, action, result):
        self.interactions.record(state, action, result)
        if action.startswith('go:') and result.get('reason') == 'map_changed':
            self.pending = (state['map']['map_id'], action)
