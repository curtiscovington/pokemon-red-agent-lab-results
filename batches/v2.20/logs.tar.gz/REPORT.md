# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-reactive-87905656 | reactive | evidence | interrupted | 209 | party_observed, provisional_has_parcel, provisional_has_pokedex |

Interpretation: pending review of saved frames and event logs.
Batch status: failed
