from __future__ import annotations

import argparse
import asyncio
import base64
import hashlib
import queue
import threading
import time
from pathlib import Path
from typing import Any

from fastapi import WebSocket, WebSocketDisconnect

AUDIO_FRAMES_PER_CHUNK = 6
ADDR_IS_IN_BATTLE = 0xD057
ADDR_ENEMY_SPECIES = 0xCFD8
ADDR_ENEMY_BATTLE_MON = 0xCFE5
BATTLE_MON_SIZE = 29


def read_verified_red_battle(reader: Any) -> dict[str, Any]:
    """Decode the active battle struct, rather than the persistent trainer-party struct."""
    from pokemon_agent.memory.red import INTERNAL_TO_DEX, MOVE_NAMES, species_name_from_index

    battle_type = reader.emu.read_u8(ADDR_IS_IN_BATTLE)
    result: dict[str, Any] = {
        "in_battle": battle_type in {1, 2},
        "type": {0: "none", 1: "wild", 2: "trainer", 0xFF: "lost"}.get(
            battle_type, f"unknown({battle_type})"
        ),
    }
    if not result["in_battle"]:
        return result
    enemy_species = reader.emu.read_u8(ADDR_ENEMY_SPECIES)
    data = reader.emu.read_range(ADDR_ENEMY_BATTLE_MON, BATTLE_MON_SIZE)
    result["enemy"] = {
        "species_id": enemy_species,
        "dex_number": INTERNAL_TO_DEX.get(enemy_species, 0),
        "species": species_name_from_index(enemy_species),
        "level": data[14],
        "hp": (data[1] << 8) | data[2],
        "max_hp": (data[15] << 8) | data[16],
        "status": reader._decode_status(data[4]),
        "moves": [MOVE_NAMES.get(move, f"???({move})") for move in data[8:12] if move],
    }
    return result


def sanitize_battle_state(state: dict[str, Any]) -> bool:
    """Reject a known Gen-1 stale-RAM battle signature.

    wIsInBattle can remain/set non-zero while the overworld is active. Enemy
    structs intentionally persist after battle, so a zero-HP enemy is not
    independent evidence. During a real faint sequence the text engine owns
    input; zero HP with no active dialog is therefore treated as stale.
    """
    battle = state.get("battle") or {}
    enemy = battle.get("enemy") or {}
    dialog = state.get("dialog") or {}
    if battle.get("in_battle") and enemy.get("hp") == 0 and not dialog.get("active"):
        state["battle_raw"] = battle
        state["battle"] = {
            "in_battle": False,
            "type": "none",
            "integrity": "rejected_stale_zero_hp_enemy_without_battle_dialog",
        }
        return True
    return False


class AudioFanout:
    """Move bounded PCM chunks from the emulator thread to async listeners."""

    def __init__(self, queue_depth: int = 4) -> None:
        self.queue_depth = queue_depth
        self._subscribers: set[tuple[asyncio.AbstractEventLoop, asyncio.Queue[bytes]]] = set()
        self._lock = threading.Lock()

    def subscribe(self) -> tuple[asyncio.AbstractEventLoop, asyncio.Queue[bytes]]:
        subscriber = (asyncio.get_running_loop(), asyncio.Queue(maxsize=self.queue_depth))
        with self._lock:
            self._subscribers.add(subscriber)
        return subscriber

    def unsubscribe(
        self, subscriber: tuple[asyncio.AbstractEventLoop, asyncio.Queue[bytes]]
    ) -> None:
        with self._lock:
            self._subscribers.discard(subscriber)

    def has_subscribers(self) -> bool:
        with self._lock:
            return bool(self._subscribers)

    def publish_from_thread(self, chunk: bytes) -> None:
        with self._lock:
            subscribers = tuple(self._subscribers)
        for loop, output in subscribers:
            loop.call_soon_threadsafe(self._offer, output, chunk)

    @staticmethod
    def _offer(output: asyncio.Queue[bytes], chunk: bytes) -> None:
        if output.full():
            try:
                output.get_nowait()
            except asyncio.QueueEmpty:
                pass
        output.put_nowait(chunk)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Pokemon Red at display-friendly speed")
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--port", type=int, default=8766)
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--load-state")
    args = parser.parse_args()
    audio = AudioFanout()
    audio_metadata: dict[str, Any] = {
        "sample_rate": 48_000,
        "channels": 2,
        "encoding": "s8",
        "chunk_frames": AUDIO_FRAMES_PER_CHUNK,
    }

    # pokemon-agent normally advances PyBoy only while an action is executing.
    # Run the console continuously instead, while action calls simply wait for
    # the requested number of real emulated frames to pass.
    from pokemon_agent.emulator import PyBoyEmulator
    from pokemon_agent.memory.red import RedBlueMemoryReader

    original_load = PyBoyEmulator.load
    original_close = PyBoyEmulator.close
    original_save_state = PyBoyEmulator.save_state
    original_load_state = PyBoyEmulator.load_state

    def continuous_load(self: PyBoyEmulator, rom_path: str) -> None:
        original_load(self, rom_path)
        self._pyboy.set_emulation_speed(0)
        self._continuous_running = True
        self._frame_condition = threading.Condition()
        self._button_queue = queue.Queue()
        self._emulation_lock = threading.RLock()
        audio_metadata["sample_rate"] = int(self._pyboy.sound.sample_rate)

        def run_console() -> None:
            active_press = None
            next_frame = time.monotonic()
            audio_chunk = bytearray()
            while self._continuous_running:
                stream_audio = audio.has_subscribers()
                with self._emulation_lock:
                    if active_press is None:
                        try:
                            active_press = self._button_queue.get_nowait()
                            self._pyboy.button_press(active_press[0])
                        except queue.Empty:
                            pass
                    self._pyboy.tick(sound=stream_audio)
                    self.frame_count += 1
                    if stream_audio:
                        sound = self._pyboy.sound
                        if sound.raw_buffer_head:
                            audio_chunk.extend(bytes(sound.raw_buffer[: sound.raw_buffer_head]))
                    else:
                        audio_chunk.clear()
                    if active_press is not None:
                        active_press[1] -= 1
                        if active_press[1] <= 0:
                            self._pyboy.button_release(active_press[0])
                            active_press[2].set()
                            active_press = None
                if (
                    stream_audio
                    and self.frame_count % AUDIO_FRAMES_PER_CHUNK == 0
                    and audio_chunk
                ):
                    audio.publish_from_thread(bytes(audio_chunk))
                    audio_chunk.clear()
                with self._frame_condition:
                    self._frame_condition.notify_all()
                next_frame += 1 / 59.7275
                delay = next_frame - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
                elif delay < -0.25:
                    next_frame = time.monotonic()

        self._continuous_thread = threading.Thread(
            target=run_console,
            name="pokemon-red-60hz",
            daemon=True,
        )
        self._continuous_thread.start()

    def wait_for_frames(self: PyBoyEmulator, frames: int = 1) -> None:
        target = self.frame_count + frames
        timeout = max(1.0, frames / 30)
        with self._frame_condition:
            completed = self._frame_condition.wait_for(
                lambda: self.frame_count >= target or not self._continuous_running,
                timeout=timeout,
            )
            if not completed or self.frame_count < target:
                raise TimeoutError('Emulator did not complete requested frames')

    def queued_press(self: PyBoyEmulator, button: str, frames: int = 1) -> None:
        button = button.lower()
        if button not in self.BUTTONS:
            raise ValueError(f"Unknown button '{button}'. Valid: {self.BUTTONS}")
        completed = threading.Event()
        self._button_queue.put([button, max(1, frames), completed])
        if not completed.wait(timeout=max(1.0, frames / 30 + 1)):
            raise TimeoutError('Button completion not acknowledged; input outcome unknown')

    def continuous_close(self: PyBoyEmulator) -> None:
        self._continuous_running = False
        with self._frame_condition:
            self._frame_condition.notify_all()
        self._continuous_thread.join(timeout=2)
        original_close(self)

    def synchronized_save_state(self: PyBoyEmulator, path: str) -> None:
        with self._emulation_lock:
            original_save_state(self, path)

    def synchronized_load_state(self: PyBoyEmulator, path: str) -> None:
        with self._emulation_lock:
            original_load_state(self, path)

    PyBoyEmulator.load = continuous_load
    PyBoyEmulator.tick = wait_for_frames
    PyBoyEmulator.press = queued_press
    PyBoyEmulator.close = continuous_close
    PyBoyEmulator.save_state = synchronized_save_state
    PyBoyEmulator.load_state = synchronized_load_state
    RedBlueMemoryReader.read_battle = read_verified_red_battle

    from pokemon_agent import server as game_server
    from pokemon_agent.server import GameConfig, app, configure

    @app.get("/observation")
    def coherent_observation() -> dict[str, Any]:
        game_server._ensure_emulator()
        emulator = game_server._emulator
        with emulator._emulation_lock:
            state = game_server._get_state_dict()
            screen = game_server._get_screenshot_bytes()
            frame = emulator.frame_count
        state["capture"] = {
            "frame": frame, "synchronized": True,
            "screen_hash": hashlib.sha256(screen).hexdigest(),
        }
        return {"state": state, "screenshot": base64.b64encode(screen).decode()}

    configure(
        GameConfig(
            rom_path=str(args.rom.resolve()),
            game_type="red",
            port=args.port,
            data_dir=str(args.data_dir.resolve()),
            load_state=args.load_state,
        )
    )

    original_get_state_dict = game_server._get_state_dict

    def hardened_get_state_dict() -> dict[str, Any]:
        state = original_get_state_dict()
        from .map_names import correct_map_name
        correct_map_name(state)
        corrected = sanitize_battle_state(state)
        from .interaction import read_interface
        state['interface'] = read_interface(game_server._reader.emu, state)
        state['dialog']['engine_active'] = state['dialog'].get('active', False)
        state['dialog']['active'] = state['interface']['kind'] == 'dialogue'
        if corrected and "collision" not in state:
            try:
                from pokemon_agent.collision import build_collision_grid, render_ascii_map
                col = build_collision_grid(game_server._reader.emu)
                col["ascii"] = render_ascii_map(col, legend=True)
                state["collision"] = col
            except Exception as exc:  # noqa: BLE001
                state["collision_error"] = f"{type(exc).__name__}: {exc}"
        try:
            from .navigation import read_map
            state['navigation'] = read_map(game_server._reader.emu, state)
        except Exception as exc:  # noqa: BLE001 - fail closed; buttons remain available
            state['navigation'] = {'available': False, 'targets': [], 'error': str(exc)}
        return state

    # The vendor /state route and our atomic /observation route both resolve
    # this module global at request time.
    game_server._get_state_dict = hardened_get_state_dict

    @app.websocket("/audio")
    async def audio_stream(websocket: WebSocket) -> None:
        await websocket.accept()
        subscriber = audio.subscribe()
        _, chunks = subscriber
        try:
            await websocket.send_json(audio_metadata)
            while True:
                await websocket.send_bytes(await chunks.get())
        except WebSocketDisconnect:
            pass
        finally:
            audio.unsubscribe(subscriber)

    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=args.port, log_level="info", access_log=False)


if __name__ == "__main__":
    main()
