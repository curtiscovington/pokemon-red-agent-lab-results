"""Experimental llama.cpp next-token scorer; never parses generated confidence."""
import math
import time

from .actions import criteria
from .clients import ModelDecision, compact_state


class TokenScoringClient:
    backend = "llama-score"

    def __init__(self, base_url, client, model_name):
        self.base_url = base_url.rstrip("/")
        self.client = client
        self.model_name = model_name

    async def health(self):
        response = await self.client.get(f"{self.base_url}/health")
        response.raise_for_status()
        return response.json()

    async def post(self, path, body):
        response = await self.client.post(f"{self.base_url}{path}", json=body, timeout=180)
        response.raise_for_status()
        return response.json()

    async def decide(self, *, game_state, ultimate_goal, recent_outcomes=None, **unused):
        import json

        started = time.perf_counter()
        options = criteria()
        if not (game_state.get("battle") or {}).get("in_battle"):
            options = {k: v for k, v in options.items() if k not in {"run", "fight_first_move"}}
        labels = dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ", options, strict=False))
        token_ids = {}
        for label in labels:
            tokens = (await self.post("/tokenize", {"content": label, "add_special": False}))["tokens"]
            if len(tokens) != 1 or not isinstance(tokens[0], int):
                raise ValueError("Decision labels must each be exactly one token")
            token_ids[label] = tokens[0]
        if len(set(token_ids.values())) != len(labels):
            raise ValueError("Decision labels must have distinct token IDs")
        context = {
            "objective": ultimate_goal,
            "observation": compact_state(game_state),
            "exploration": game_state.get("exploration_memory", {}),
            "recent_results": (recent_outcomes or [])[-8:],
            "choices": {label: {"action": action, "description": options[action]}
                        for label, action in labels.items()},
        }
        rendered = await self.post("/apply-template", {"messages": [
            {"role": "system", "content": "Choose one next controller action from observed evidence. "
             "Do not assume route directions from game knowledge. Reply with exactly one choice letter. "
             "Do not explain or think aloud."},
            {"role": "user", "content": json.dumps(context)},
        ], "chat_template_kwargs": {"enable_thinking": False}})
        prompt = rendered["prompt"]
        if prompt.rfind("<think>") > prompt.rfind("</think>"):
            raise ValueError("Server template left thinking enabled; configure it off before scoring")
        payload = await self.post("/completion", {
            "prompt": prompt, "n_predict": 1, "n_probs": 256,
            "post_sampling_probs": False, "temperature": 1.0,
            "top_k": 0, "top_p": 1.0, "min_p": 0.0, "repeat_penalty": 1.0,
            "cache_prompt": True,
        })
        rows = payload.get("completion_probabilities", [])
        if len(rows) != 1:
            raise ValueError("Expected a single answer-position probability distribution")
        scores = {item["id"]: item["logprob"] for item in rows[0]["top_logprobs"]}
        if any(token not in scores for token in token_ids.values()):
            raise ValueError("Incomplete label probabilities: refusing to invent missing scores")
        logits = {labels[label]: float(scores[token]) for label, token in token_ids.items()}
        if not all(math.isfinite(value) and value <= 0 for value in logits.values()):
            raise ValueError("Invalid log probabilities")
        peak = max(logits.values())
        weights = {key: math.exp(value - peak) for key, value in logits.items()}
        probabilities = {key: value / sum(weights.values()) for key, value in weights.items()}
        label_mass = sum(math.exp(value) for value in logits.values())
        choice = max(probabilities, key=probabilities.get)
        return ModelDecision(
            choice=choice, probabilities=probabilities, unknown_probability=0,
            abstained=False, latency_ms=(time.perf_counter() - started) * 1000,
            raw={"decision_diagnostics": {"prompt_profile": "token-scoring-v1",
                 "label_mass": label_mass, "probabilities_are_conditional": True,
                 "text_only": True, "sampled_token_ignored": True}},
            reasoning="", mode="token-score", model=self.model_name,
        )
