#!/usr/bin/python3
"""Dedicated Pokemon Ollama launcher: use Direct I/O with lazy CPU embeddings to limit loading memory."""
import os
import sys
from pathlib import Path


def arguments(args):
    result = []
    i = 0
    while i < len(args):
        if args[i] in {'--load-mode', '-lm', '--lazy-mode', '-lzm'}:
            i += 2
            continue
        if args[i].startswith(('--load-mode=', '--lazy-mode=')):
            i += 1
            continue
        result.append(args[i])
        i += 1
    return result + ['--load-mode', 'dio', '--lazy-mode', 'on']


if __name__ == '__main__':
    original = Path(__file__).resolve().with_name('llama-server.original')
    os.execv(str(original), [str(original), *arguments(sys.argv[1:])])
