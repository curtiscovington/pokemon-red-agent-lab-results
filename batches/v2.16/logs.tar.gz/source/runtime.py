from __future__ import annotations

import asyncio
import base64
import json
import os
import re
import time
from collections import deque
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

import httpx

from . import exploration
from .actions import ACTION_MACROS, resolve
from .clients import ModelDecision, PokemonClient, adjacent_tiles, build_model_client

Publish = Callable[[dict[str, Any]], Awaitable[None]]
MAX_MODEL_LESSONS = 16
AUTOSAVE_NAME = "imajev_autosave"


def outcome_goal(text: str) -> bool:
    """Reject explicit route directions without blocking the model's chosen action."""
    return not re.search(
        r"\b(north\w*|south\w*|east\w*|west\w*|left|right|up|down)\b|\b[xy]\s*=|\(\s*\d+\s*,\s*\d+\s*\)",
        text, re.IGNORECASE,
    )


class PlayerRuntime:
    def __init__(
        self,
        pokemon_url: str,
        model_url: str,
        publish: Publish,
        *,
        model_backend: str = "ollama",
        model_name: str = "qwen3.8:27b-q8_0",
        memory_path: str | Path | None = None,
        checkpoint_path: str | Path | None = None,
    ):
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(30.0, connect=4.0))
        self.pokemon = PokemonClient(pokemon_url, self.http)
        self.model = build_model_client(model_backend, model_url, self.http, model_name)
        self.publish = publish
        self.control = "paused"
        self.ultimate_goal = "Complete Pokémon Red by defeating the Elite Four and becoming Champion."
        self.short_term_goal: str | None = None
        self.medium_term_goal: str | None = None
        self.memory_path = Path(memory_path) if memory_path else None
        self.lessons: deque[dict[str, Any]] = deque(maxlen=MAX_MODEL_LESSONS)
        self._next_lesson_id = 1
        self._load_lessons()
        self.inputs: deque[dict[str, Any]] = deque(maxlen=80)
        self.decisions: deque[dict[str, Any]] = deque(maxlen=30)
        self.outcomes: deque[dict[str, Any]] = deque(maxlen=80)
        self.exploration_memory: dict[str, Any] = {}
        self.frustration: dict[str, Any] = {"score": 0, "threshold": 6, "reset_turn": -1}
        self.frames: deque[bytes] = deque(maxlen=4)
        self.turn = 0
        self.last_error: str | None = None
        self._decision_failures = 0
        self._task: asyncio.Task[None] | None = None
        self._closed = False
        self._draining = False
        self._turn_idle = asyncio.Event()
        self._turn_idle.set()
        self._previous_observation: dict[str, Any] | None = None
        self._previous_choice: str | None = None
        self._played_seconds = 0.0
        self._running_since: float | None = None
        self._model_action_play_times: deque[float] = deque(maxlen=80)
        self.checkpoint_path = Path(checkpoint_path) if checkpoint_path else None
        self._restore_checkpoint()

    def checkpoint(self) -> None:
        if self.checkpoint_path is None:
            return
        payload = {
            "version": 1,
            "goal_policy": "visible-opportunities-v1",
            "short_term_goal": self.short_term_goal,
            "medium_term_goal": self.medium_term_goal,
            "turn": self.turn,
            "played_seconds": self._current_played_seconds(),
            "inputs": list(self.inputs), "decisions": list(self.decisions),
            "outcomes": list(self.outcomes),
            "exploration_memory": self.exploration_memory,
            "frustration": self.frustration,
            "frames": [base64.b64encode(frame).decode() for frame in self.frames],
            "previous_observation": self._previous_observation,
            "previous_choice": self._previous_choice,
            "action_times": list(self._model_action_play_times),
        }
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.checkpoint_path.with_suffix(".tmp")
        with temporary.open("w") as output:
            json.dump(payload, output)
            output.flush()
            os.fsync(output.fileno())
        temporary.replace(self.checkpoint_path)

    def _restore_checkpoint(self) -> None:
        if self.checkpoint_path is None or not self.checkpoint_path.exists():
            return
        # Fail startup on a damaged checkpoint rather than silently resetting progress.
        payload = json.loads(self.checkpoint_path.read_text())
        if payload.get("version") != 1:
            raise ValueError("Unsupported controller checkpoint version")
        self.short_term_goal = payload["short_term_goal"]
        self.medium_term_goal = payload["medium_term_goal"]
        self.turn = int(payload["turn"])
        self.frustration.update(payload.get("frustration", {}))
        if self.frustration.pop("requires_new_objective", False):
            self.short_term_goal = self.short_term_goal or self.frustration.get("retired_objective")
        self.frustration.pop("retired_objective", None)
        if payload.get("goal_policy") != "visible-opportunities-v1":
            self.short_term_goal = None
            self.medium_term_goal = None
        self._played_seconds = float(payload["played_seconds"])
        for name in ("inputs", "decisions", "outcomes"):
            getattr(self, name).extend(payload[name])
        if "exploration_memory" in payload:
            self.exploration_memory = payload["exploration_memory"]
        else:
            for outcome in self.outcomes:
                exploration.record(self.exploration_memory, outcome)
        self.frames.extend(base64.b64decode(frame, validate=True) for frame in payload["frames"])
        self._previous_observation = payload["previous_observation"]
        self._previous_choice = payload["previous_choice"]
        self._model_action_play_times.extend(payload["action_times"])
        # Resume explicitly after checking the emulator; never replay an in-flight action.

    async def start(self) -> None:
        if not self._task:
            self._task = asyncio.create_task(self._loop(), name="imajev-player-loop")

    async def close(self) -> None:
        self._closed = True
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self.http.aclose()
        self.checkpoint()

    async def snapshot(self) -> dict[str, Any]:
        game_state: dict[str, Any] | None = None
        services = {"game": False, "model": False}
        game_result, model_result = await asyncio.gather(
            self.pokemon.state(), self.model.health(), return_exceptions=True
        )
        if not isinstance(game_result, BaseException):
            game_state = game_result
            services["game"] = True
        services["model"] = not isinstance(model_result, BaseException)
        return {
            "control": self.control,
            "goals": self._goals_snapshot(),
            "lessons": list(self.lessons),
            "turn": self.turn,
            "inputs": list(self.inputs),
            "decisions": list(self.decisions),
            "recent_action_outcomes": list(self.outcomes),
            "frustration": self.frustration,
            "last_error": self.last_error,
            "game": game_state,
            "services": services,
            "model": {
                "backend": self.model.backend,
                "name": self.model.model_name,
            },
            "timing": self._timing_snapshot(),
        }

    async def set_control(self, value: str) -> None:
        if value not in {"running", "paused"}:
            raise ValueError("control must be running or paused")
        if value == self.control:
            return
        now = time.monotonic()
        if self.control == "running" and self._running_since is not None:
            self._played_seconds += now - self._running_since
            self._running_since = None
        if value == "running":
            self._running_since = now
        self.control = value
        self.checkpoint()
        await self.publish({"type": "control", "value": value})

    async def set_model_goals(
        self, *, short_term: str | None = None, medium_term: str | None = None
    ) -> None:
        changed = False
        if short_term:
            cleaned = " ".join(short_term.split())[:240]
            if cleaned and outcome_goal(cleaned) and cleaned != self.short_term_goal:
                self.short_term_goal = cleaned
                changed = True
        if medium_term:
            cleaned = " ".join(medium_term.split())[:500]
            if cleaned and outcome_goal(cleaned) and cleaned != self.medium_term_goal:
                self.medium_term_goal = cleaned
                changed = True
        if changed:
            self.checkpoint()
            await self.publish({"type": "goals", "value": self._goals_snapshot()})

    async def update_lessons(
        self, *, remember: tuple[str, ...] = (), forget_ids: tuple[int, ...] = ()
    ) -> None:
        changed = False
        forgotten = set(forget_ids)
        if forgotten:
            retained = [item for item in self.lessons if item["id"] not in forgotten]
            if len(retained) != len(self.lessons):
                self.lessons = deque(retained, maxlen=MAX_MODEL_LESSONS)
                changed = True
        known = {str(item["lesson"]).casefold() for item in self.lessons}
        for lesson in remember:
            cleaned = " ".join(lesson.split())[:300]
            if not cleaned or cleaned.casefold() in known:
                continue
            self.lessons.appendleft(
                {"id": self._next_lesson_id, "lesson": cleaned, "created_at": time.time(),
                 "source": "model", "verification": "unverified",
                 "observation_context": list(self.outcomes)[-4:]}
            )
            self._next_lesson_id += 1
            known.add(cleaned.casefold())
            changed = True
        if changed:
            self._save_lessons()
            await self.publish({"type": "memory", "value": list(self.lessons)})

    async def manual(self, macro_name: str) -> None:
        if self._draining:
            raise ValueError("Controller is draining for maintenance")
        key, macro = resolve(macro_name)
        await self._execute_queue([(key, macro.actions)], source="manual")
        await self._save_progress()

    async def drain(self) -> None:
        """Finish the current model turn, then checkpoint without executing another."""
        self._draining = True
        await self._turn_idle.wait()
        await self.set_control("paused")
        self.checkpoint()

    async def save(self, name: str = "imajev_autosave") -> dict[str, Any]:
        return await self.pokemon.save(name)

    async def _save_progress(self) -> None:
        """Keep emulator RAM and controller history at the same completed turn."""
        try:
            await self.pokemon.save(AUTOSAVE_NAME)
        except Exception:
            # Do not allow another input after a turn that could not be made recoverable.
            now = time.monotonic()
            if self.control == "running" and self._running_since is not None:
                self._played_seconds += now - self._running_since
                self._running_since = None
            self.control = "paused"
            raise
        self.checkpoint()

    async def _execute_queue(
        self, queue: list[tuple[str, tuple[str, ...]]], source: str
    ) -> None:
        before = self._observation((await self.pokemon.observe())[0])
        if source != "manual":
            self._model_action_play_times.append(self._current_played_seconds())
        for queue_index, (macro_name, macro_actions) in enumerate(queue):
            await self.pokemon.act(macro_actions)
            now = time.time()
            for action in macro_actions:
                event = {
                    "action": action,
                    "label": ACTION_MACROS[macro_name].label,
                    "source": source,
                    "turn": self.turn,
                    "ts": now,
                    "queue_index": queue_index,
                    "queue_size": len(queue),
                }
                self.inputs.appendleft(event)
                await self.publish({"type": "input", "value": event})
            # Observe locally between macros; no inference or automatic replacement actions.
            after = self._observation((await self.pokemon.observe())[0])
            outcome = self._action_outcome(macro_name, before, after)
            outcome.update({
                "turn": self.turn, "source": source, "queue_index": queue_index,
                "queue_size": len(queue),
                "skipped_actions": [name for name, _ in queue[queue_index + 1:]]
                if outcome["stop_reason"] else [],
            })
            self.outcomes.append(outcome)
            exploration.record(self.exploration_memory, outcome)
            await self.publish({"type": "outcome", "value": outcome})
            if outcome["stop_reason"]:
                break
            before = after

    async def _loop(self) -> None:
        while not self._closed:
            if self.control != "running" or self._draining:
                await asyncio.sleep(0.2)
                continue
            try:
                self._turn_idle.clear()
                state, screenshot = await self.pokemon.observe()
                await self._check_frustration()
                state["harness_frustration"] = dict(self.frustration)
                exploration.observe_openings(self.exploration_memory, self._observation(state),
                                             adjacent_tiles(state.get("collision") or {}))
                state["exploration_memory"] = exploration.context(
                    self.exploration_memory, self._observation(state)
                )
                state["navigation"] = exploration.navigation(
                    self.exploration_memory, self._observation(state), list(self.outcomes)
                )
                decision = await self.model.decide(
                    # Navigation candidates are recomputed from observed movement.
                    screenshot=screenshot,
                    game_state=state,
                    ultimate_goal=self.ultimate_goal,
                    short_term_goal=self.short_term_goal,
                    medium_term_goal=self.medium_term_goal,
                    lessons=list(self.lessons),
                    recent_actions=[item["action"] for item in reversed(self.inputs)],
                    recent_outcomes=list(self.outcomes),
                    past_frames=list(self.frames),
                )
                reconsidering = bool(self.frustration.get("reconsider_approach"))
                await self.set_model_goals(
                    short_term=decision.short_term_goal_update,
                    medium_term=decision.medium_term_goal_update,
                )
                await self.update_lessons(
                    remember=decision.lessons_to_remember,
                    forget_ids=decision.lesson_ids_to_forget,
                )
                requested_queue = () if decision.abstained else decision.action_queue
                if not requested_queue:
                    await self._incomplete_decision(decision, "No valid action was produced")
                    continue
                self._decision_failures = 0
                if reconsidering or (self.outcomes and self.outcomes[-1].get("reconsider_hypothesis")):
                    requested_queue = requested_queue[:1]
                resolved_queue = [resolve(choice) for choice in requested_queue]
                keys = tuple(key for key, _ in resolved_queue)
                self.turn += 1
                record = self._decision_record(keys, decision)
                self.decisions.appendleft(record)
                self.last_error = None
                await self.publish({"type": "decision", "value": record})
                await self._execute_queue(
                    [(key, macro.actions) for key, macro in resolved_queue],
                    source=self.model.backend,
                )
                self.frames.append(screenshot)
                await self._save_progress()
                await asyncio.sleep(0.25)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - both local services can be warming up
                self.last_error = f"{type(exc).__name__}: {exc}"
                await self.publish({"type": "error", "value": self.last_error})
                await asyncio.sleep(2.0)
            finally:
                self._turn_idle.set()

    async def _incomplete_decision(self, decision: ModelDecision, reason: str) -> None:
        self._decision_failures = min(self._decision_failures + 1, 5)
        delay = min(60, 5 * 2 ** (self._decision_failures - 1))
        self.last_error = f"{reason}; retrying in {delay}s without sending a game input."
        await self.publish({"type": "error", "value": self.last_error})
        record = {
            "turn": self.turn, "choice": None, "choices": [], "label": "RETRY",
            "mode": decision.mode, "confidence": 0, "unknown_probability": 1,
            "model": decision.model, "top": [],
            "abstained": True, "reasoning": decision.reasoning,
            "latency_ms": decision.latency_ms, "ts": time.time(),
            "diagnostics": decision.raw.get("decision_diagnostics", {}),
        }
        self.decisions.appendleft(record)
        await self.publish({"type": "decision", "value": record})
        self.checkpoint()
        await asyncio.sleep(delay)

    async def _check_frustration(self) -> None:
        recent = []
        for outcome in self.outcomes:
            if outcome.get("turn", -1) <= self.frustration["reset_turn"]:
                continue
            if outcome.get("source") == "manual":
                recent.clear()
                continue
            before, after = outcome.get("before", {}), outcome.get("after", {})
            if (outcome.get("map_changed") or before.get("in_battle")
                    or after.get("in_battle") or before.get("dialog_active")
                    or after.get("dialog_active")):
                recent.clear()
                continue
            if outcome.get("action") in {"up", "down", "left", "right"}:
                recent.append(outcome)
        seen = set()
        score = 0
        for outcome in recent[-24:]:
            after = outcome.get("after", {})
            if after.get("position") is None or after.get("map_id") is None:
                continue
            location = json.dumps([after["map_id"], after["position"]], sort_keys=True)
            if outcome.get("stop_reason") == "no_displacement":
                score += 2
            elif location in seen:
                score += 1
            else:
                score = max(0, score - 1)
            seen.add(location)
        self.frustration["score"] = min(score, 6)
        self.frustration["reconsider_approach"] = score >= 6
        if score >= 6:
            self.frustration.update({
                "reason": "Repeated navigation failures or revisiting the same positions.",
            })
            self.checkpoint()
            await self.publish({"type": "goals", "value": self._goals_snapshot()})

    def _decision_record(
        self, choices: tuple[str, ...], decision: ModelDecision
    ) -> dict[str, Any]:
        ranked = sorted(decision.probabilities.items(), key=lambda item: item[1], reverse=True)[:4]
        choice = choices[0]
        return {
            "turn": self.turn,
            "choice": choice,
            "diagnostics": decision.raw.get("decision_diagnostics", {}),
            "label": ACTION_MACROS[choice].label,
            "choices": list(choices),
            "labels": [ACTION_MACROS[item].label for item in choices],
            "confidence": decision.confidence,
            "unknown_probability": decision.unknown_probability,
            "abstained": decision.abstained,
            "latency_ms": decision.latency_ms,
            "reasoning": decision.reasoning,
            "mode": decision.mode,
            "model": decision.model or self.model.model_name,
            "short_term_goal_update": decision.short_term_goal_update,
            "medium_term_goal_update": decision.medium_term_goal_update,
            "lessons_to_remember": list(decision.lessons_to_remember),
            "lesson_ids_to_forget": list(decision.lesson_ids_to_forget),
            "top": [{"choice": name, "probability": score} for name, score in ranked],
            "ts": time.time(),
        }

    def _timing_snapshot(self) -> dict[str, Any]:
        intervals = [
            later - earlier
            for earlier, later in zip(
                self._model_action_play_times, list(self._model_action_play_times)[1:]
            )
        ]
        last_model_input = next(
            (item for item in self.inputs if item.get("source") != "manual"), None
        )
        return {
            "played_seconds": self._current_played_seconds(),
            "running": self.control == "running",
            "last_action_ts": last_model_input.get("ts") if last_model_input else None,
            "average_action_interval_seconds": (
                sum(intervals) / len(intervals) if intervals else None
            ),
        }

    def _current_played_seconds(self) -> float:
        played_seconds = self._played_seconds
        if self._running_since is not None:
            played_seconds += time.monotonic() - self._running_since
        return max(0.0, played_seconds)

    def _goals_snapshot(self) -> dict[str, Any]:
        return {
            "ultimate": self.ultimate_goal,
            "medium_term": self.medium_term_goal,
            "short_term": self.short_term_goal,
            "short_term_owner": "model",
            "medium_term_owner": "model",
            "ultimate_owner": "operator",
        }

    def _load_lessons(self) -> None:
        if self.memory_path is None or not self.memory_path.exists():
            return
        try:
            payload = json.loads(self.memory_path.read_text())
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(payload, list):
            return
        valid: list[dict[str, Any]] = []
        for item in payload[:MAX_MODEL_LESSONS]:
            if not isinstance(item, dict):
                continue
            lesson_id = item.get("id")
            lesson = item.get("lesson")
            if not isinstance(lesson_id, int) or not isinstance(lesson, str) or not lesson.strip():
                continue
            valid.append(
                {
                    "id": lesson_id,
                    "lesson": " ".join(lesson.split())[:300],
                    "created_at": float(item.get("created_at") or 0),
                    "source": "model", "verification": "unverified",
                    "observation_context": item.get("observation_context", [])[-4:]
                    if isinstance(item.get("observation_context", []), list) else [],
                }
            )
        self.lessons.extend(valid)
        if valid:
            self._next_lesson_id = max(item["id"] for item in valid) + 1

    def _save_lessons(self) -> None:
        if self.memory_path is None:
            return
        self.memory_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.memory_path.with_suffix(f"{self.memory_path.suffix}.tmp")
        temporary.write_text(json.dumps(list(self.lessons), indent=2) + "\n")
        temporary.replace(self.memory_path)

    @staticmethod
    def _observation(state: dict[str, Any]) -> dict[str, Any]:
        player = state.get("player") or {}
        map_state = state.get("map") or {}
        battle = state.get("battle") or {}
        dialog = state.get("dialog") or {}
        return {
            "map": map_state.get("map_name"),
            "map_id": map_state.get("map_id"),
            "position": player.get("position"),
            "facing": player.get("facing"),
            "in_battle": bool(battle.get("in_battle")),
            "dialog_active": bool(dialog.get("active")),
            "battle_state": battle if battle.get("in_battle") else {},
            "dialog_state": dialog,
            "party_hp": [p.get("hp") for p in state.get("party", [])],
            "screen_hash": (state.get("capture") or {}).get("screen_hash"),
            "capture_frame": (state.get("capture") or {}).get("frame"),
        }

    def _action_outcome(
        self, action: str, before: dict[str, Any], current: dict[str, Any]
    ) -> dict[str, Any]:
        position_changed = before.get("position") != current.get("position")
        map_changed = before.get("map_id") != current.get("map_id")
        world_changed = position_changed or map_changed
        navigation_known = all(
            observation.get("position") is not None and observation.get("map_id") is not None
            for observation in (before, current)
        )
        no_displacement = (
            navigation_known and action in {"up", "down", "left", "right"}
            and not world_changed
            and not before["in_battle"] and not current["in_battle"]
            and not before["dialog_active"] and not current["dialog_active"]
        )
        stop_reason = None
        if map_changed:
            stop_reason = "map_changed"
        elif before["in_battle"] != current["in_battle"]:
            stop_reason = "battle_changed"
        elif before["dialog_active"] != current["dialog_active"]:
            stop_reason = "dialog_changed"
        elif before["in_battle"] and before.get("battle_state") != current.get("battle_state"):
            stop_reason = "battle_progress"
        elif no_displacement:
            stop_reason = "no_displacement"
        elif not navigation_known:
            stop_reason = "observation_incomplete"
        repeat_count = 1 + sum(
            item.get("action") == action and all(
                (item.get("before") or {}).get(key) == before.get(key)
                for key in ("map_id", "position", "facing", "in_battle", "dialog_active")
            )
            and item.get("stop_reason") == "no_displacement"
            for item in self.outcomes
        ) if no_displacement else 0
        return {
            "action": action,
            "before": before,
            "after": current,
            "position_changed": position_changed,
            "map_changed": map_changed,
            "made_navigation_progress": world_changed,
            "battle_state_changed": before.get("battle_state") != current.get("battle_state"),
            "party_hp_changed": before.get("party_hp") != current.get("party_hp"),
            "dialog_state_changed": before.get("dialog_state") != current.get("dialog_state"),
            "screen_changed": (
                before.get("screen_hash") != current.get("screen_hash")
                if before.get("screen_hash") and current.get("screen_hash") else None
            ),
            "stop_reason": stop_reason,
            "same_state_no_displacement_count": repeat_count,
            "reconsider_hypothesis": repeat_count >= 2,
            "evidence": "observed_state_difference_only; cause_not_inferred",
        }
