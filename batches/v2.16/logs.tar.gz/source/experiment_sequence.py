"""Run a separately recorded rehearsal, then launch the unchanged scored comparison."""
from __future__ import annotations

import json
import os
import signal
import subprocess
import time
from pathlib import Path

import httpx

from .lab import ROOT

TERMINAL = {'complete', 'failed', 'interrupted'}


def service(*args):
    return subprocess.run(['systemctl', '--user', *args], check=True,
                          capture_output=True, text=True, timeout=200).stdout.strip()


def validate_rehearsal(status):
    results = status.get('results', [])
    if status['stage'] != 'complete' or len(results) != 2:
        raise RuntimeError('Rehearsal did not complete both checks')
    for result in results:
        if (result['status'] != 'completed' or result['actions'] < 1
                or result.get('errors', 0) or result.get('model_recoveries', 0)
                or result.get('resource_affected')):
            raise RuntimeError('Rehearsal failed its action, error, or resource checks')


def main():
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt('Sequence stopped')

    signal.signal(signal.SIGTERM, interrupted)
    if service('show', 'pokemon-lab.service', '-p', 'ActiveState', '--value') not in {'inactive', 'failed'}:
        raise RuntimeError('An experiment is already active')
    output = ROOT / 'data' / ('sequence-' + time.strftime('%Y%m%d-%H%M%S'))
    output.mkdir()
    state = {'stage': 'starting_rehearsal', 'started': time.time()}

    def record(**values):
        state.update(values)
        temp = output / 'status.tmp'
        temp.write_text(json.dumps(state, indent=2) + '\n')
        temp.replace(output / 'status.json')
        print(json.dumps(values), flush=True)

    override = Path(f'/run/user/{os.getuid()}/systemd/user/pokemon-lab.service.d/90-rehearsal.conf')
    launched_comparison = False
    try:
        config = json.loads((ROOT / 'experiments/overnight.json').read_text())
        config.update(purpose='rehearsal', repeats=1)
        config_path = output / 'rehearsal.json'
        config_path.write_text(json.dumps(config, indent=2) + '\n')
        override.parent.mkdir(parents=True, exist_ok=True)
        override.write_text('[Service]\nExecStart=\nExecStart=' + str(ROOT / '.venv/bin/python')
                            + ' -m imajev_player.lab --config ' + str(config_path) + '\n')
        service('daemon-reload')
        service('stop', 'pokemon-stream-watch.service')
        service('start', 'pokemon-ollama-next.service')
        service('start', 'pokemon-lab.service')
        record(stage='rehearsal', output=str(output))
        deadline = time.monotonic() + 1800
        health_failures = 0
        with httpx.Client(timeout=3) as http:
            while time.monotonic() < deadline:
                try:
                    response = http.get('http://127.0.0.1:9877/api/status')
                    response.raise_for_status()
                    status = response.json()
                    response = http.get('http://127.0.0.1:9876/broadcast/api/status')
                    response.raise_for_status()
                    health_failures = 0
                except httpx.HTTPError:
                    health_failures += 1
                    if health_failures >= 3:
                        raise RuntimeError('Experiment or viewer repeatedly unresponsive') from None
                    time.sleep(5)
                    continue
                if state.get('rehearsal_batch') != status['batch_id']:
                    record(rehearsal_batch=status['batch_id'])
                if status['stage'] in TERMINAL:
                    validate_rehearsal(status)
                    break
                time.sleep(10)
            else:
                raise TimeoutError('Rehearsal exceeded its 30-minute safety deadline')
        record(stage='rehearsal_passed', rehearsal_results=status['results'])
        service('stop', 'pokemon-lab.service')
        override.unlink()
        service('daemon-reload')
        # The regular launcher includes the loader/model/start-save preflight.
        subprocess.run([str(ROOT / 'scripts/start-overnight-lab.sh')], check=True, timeout=120)
        with httpx.Client(timeout=3) as http:
            for _ in range(30):
                try:
                    response = http.get('http://127.0.0.1:9877/api/status')
                    response.raise_for_status()
                    scored = response.json()
                    if scored['batch_id'] != status['batch_id']:
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(1)
            else:
                raise RuntimeError('Comparison did not expose its new batch')
        if scored['stage'] in {'failed', 'interrupted'}:
            raise RuntimeError('Comparison failed at startup')
        watch = {'batch': str(ROOT / 'data/lab' / scored['batch_id']),
                 'lab_invocation_id': service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value'),
                 'tail_seconds': 30}
        (ROOT / 'data/stream-watch.json').write_text(json.dumps(watch, indent=2) + '\n')
        service('restart', 'pokemon-stream-watch.service')
        record(stage='comparison_started', comparison_batch=scored['batch_id'])
        launched_comparison = True
        with (ROOT / 'RESEARCH-NOTES.md').open('a') as notes:
            notes.write('\nRehearsal ' + status['batch_id'] + ' passed the 15-minute play and one-minute '
                        'cold-reload checks. Automatically launched scored batch ' + scored['batch_id']
                        + '; unchanged eight-run matrix. Sequence audit: ' + str(output) + '.\n')
    except BaseException as exc:
        record(stage='failed', error=repr(exc))
        raise
    finally:
        if not launched_comparison:
            service('stop', 'pokemon-lab.service')
            service('stop', 'pokemon-ollama-next.service')
            service('stop', 'pokemon-youtube-stream.service')
        if override.exists():
            override.unlink()
            service('daemon-reload')


if __name__ == '__main__':
    main()
