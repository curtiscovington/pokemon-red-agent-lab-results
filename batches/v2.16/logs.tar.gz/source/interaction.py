"""Visible interface evidence and short factual recurrence feedback for the lab."""
from collections import Counter, deque


def read_interface(emu, state):
    tiles = bytes(emu.read_range(0xC3A0, 360))
    def char(tile):
        if 0x80 <= tile <= 0x99:
            return chr(ord('A') + tile - 0x80)
        if 0xA0 <= tile <= 0xB9:
            return chr(ord('a') + tile - 0xA0)
        return {0xBA: 'é', 0xE6: '?', 0xE7: '!', 0xE8: '.', 0xF4: ','}.get(tile, ' ')
    lines = [''.join(char(t) for t in tiles[y*20:(y+1)*20]).strip() for y in range(18)]
    borders = []
    for y in range(18):
        row = tiles[y*20:(y+1)*20]
        for x in range(17):
            if row[x:x+3] == bytes([0x79, 0x7A, 0x7A]) and 0x7B in row[x+3:]:
                borders.append((x, y))
    alphabet = any(line.upper().startswith('A B C D E') for line in lines)
    naming = bool(borders and alphabet and any('NAME' in line.upper() for line in lines[:4]))
    preview = bool(lines[2] and lines[6].startswith('HT') and lines[8].startswith('WT'))
    if naming:
        kind = 'naming'
        help_text = 'Naming keyboard: A enters a letter; START submits the name. Use finish_name to submit.'
    elif state.get('battle', {}).get('in_battle'):
        kind, help_text = 'battle', 'Use battle controls.'
    elif preview:
        kind = 'pokemon_preview'
        help_text = 'Pokémon information preview: A advances the page or closes the preview. Walking is unavailable.'
    elif borders and 'YES' in lines and 'NO' in lines:
        kind = 'choice'
        help_text = 'Yes/no menu: up/down changes the choice; A accepts the highlighted choice.'
    elif borders:
        kind = 'dialogue' if any(x == 0 and y >= 12 for x, y in borders) else 'menu'
        help_text = ('A advances or closes the text. Once it closes, choose a destination; '
                     'pressing A again can reopen the same conversation.' if kind == 'dialogue'
                     else 'Use the visible menu cursor and buttons; walking is unavailable.')
    elif state.get('dialog', {}).get('joy_ignore'):
        kind, help_text = 'transition', 'The game currently controls movement; wait for the transition.'
    else:
        kind, help_text = 'overworld', 'Choose a local destination or a button action.'
    visible = lines[12:] if kind == 'dialogue' else lines
    menu = visible_menu(tiles, state, kind, char)
    return {**menu, 'kind': kind, 'text': [line for line in visible if line] if borders or preview else [],
            'navigation_available': kind == 'overworld', 'controls': help_text}


class InteractionMemory:
    def __init__(self):
        self.recent = deque(maxlen=32)

    def observe(self, state):
        ui = state.get('interface', {})
        p = state.get('player', {}).get('position', {})
        key = (state.get('map', {}).get('map_id'), p.get('x'), p.get('y'),
               ui.get('kind'), tuple(ui.get('text', [])))
        repeats = sum(previous == key for previous, _ in self.recent)
        attempts = Counter(action for previous, action in self.recent if previous == key and action)
        self.recent.append((key, None))
        return {'same_state_visits_last_32': repeats + 1,
                'previous_actions_from_this_state': dict(attempts),
                'reconsider': repeats >= 3,
                'message': ('This state has recurred. Repeated interaction has not resolved it. '
                            'Reconsider the target or menu control; do not assume a conversation '
                            'will open a separate selection menu.' if repeats >= 3 else '')}

    def acted(self, action):
        if self.recent:
            key, _ = self.recent[-1]
            self.recent[-1] = (key, action)


def visible_menu(tiles, state, kind, char):
    """Recognize visible command/move labels next to the actual cursor (pokered $ED)."""
    if kind not in ('battle', 'choice', 'menu'):
        return {}
    cursors = [(i % 20, i // 20) for i, tile in enumerate(tiles) if tile == 0xED]
    if len(cursors) != 1:
        return {}
    x, y = cursors[0]
    allowed = {'FIGHT', 'ITEM', 'PKMN', 'RUN'} if kind == 'battle' else {
        'YES', 'NO', 'POKEDEX', 'POKéDEX', 'POKEMON', 'ITEM', 'SAVE', 'OPTION', 'EXIT', 'CANCEL'}
    if kind == 'battle':
        for member in state.get('party', []):
            for move in member.get('moves', []):
                if isinstance(move, dict):
                    name = move.get('name') or move.get('move')
                    if isinstance(name, str):
                        allowed.add(name.upper())
    options = []
    # Only parse inside the bordered rectangle containing the cursor.
    boxes = []
    for top in range(y + 1):
        for left in range(x + 1):
            if tiles[top*20+left] != 0x79:
                continue
            right = next((r for r in range(left+1, 20) if tiles[top*20+r] == 0x7B), None)
            bottom = next((b for b in range(top+1, 18) if tiles[b*20+left] == 0x7D), None)
            if right is not None and bottom is not None and left < x < right and top < y < bottom:
                boxes.append((left, top, right, bottom))
    # Battle move menu's top border is partly overwritten by the TYPE/PP box.
    if (kind == 'battle' and x == 5 and 13 <= y <= 16
            and all(tiles[row*20+4] == 0x7C and tiles[row*20+19] == 0x7C for row in range(13,17))
            and tiles[17*20+4] == 0x7D):
        boxes.append((4,12,19,17))
    if not boxes:
        return {}
    left, top, right, bottom = min(boxes, key=lambda b: (b[2]-b[0])*(b[3]-b[1]))
    for row in range(top+1, bottom):
        col = left+1
        while col < right:
            if char(tiles[row*20+col]).isalpha():
                start = col
                label = ''
                while col < right and char(tiles[row*20+col]).isalpha():
                    label += char(tiles[row*20+col]); col += 1
                # Single-word moves only; unsupported/ambiguous labels use normal controls.
                if label in allowed and (start-1, row) not in [(o['x'], o['y']) for o in options]:
                    options.append({'label': label, 'x': start-1, 'y': row})
            else:
                col += 1
    if not any((o['x'], o['y']) == (x, y) for o in options):
        return {}
    if len({o['label'] for o in options}) != len(options):
        return {}
    return {'menu_options': options, 'menu_cursor': {'x': x, 'y': y}}
