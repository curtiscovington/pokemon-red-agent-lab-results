"""Wait for administrator shutdown of competing backends, then retry the interrupted run."""
import json
import subprocess
import sys
import time

from .experiment_sequence import service
from .lab import ROOT, write_json


def main():
    batch = ROOT / 'data/lab/20261009-101720-b909b8'
    audit = batch / 'exclusive-resume.json'
    write_json(audit, {'stage': 'waiting_for_system_model_shutdown', 'requested_at': time.time()})
    try:
        deadline = time.monotonic() + 86400
        while time.monotonic() < deadline:
            ready = True
            for name in ('ollama.service', 'nemotron-vllm.service'):
                state = subprocess.run(['systemctl', 'show', name, '-p', 'ActiveState', '--value'],
                                       check=True, capture_output=True, text=True, timeout=10).stdout.strip()
                ready &= state in {'inactive', 'failed'}
            if ready:
                break
            time.sleep(5)
        else:
            raise TimeoutError('Administrator shutdown was not completed within 24 hours')
        for item in json.loads((ROOT / 'data/model-exclusivity-before.json').read_text()):
            state = service('show', item['unit'], '-p', 'ActiveState', '--value')
            if state not in {'inactive', 'failed'}:
                raise RuntimeError('Competing user service still active: ' + item['unit'])
        service('stop', 'pokemon-lab.service')
        status = json.loads((batch / 'status.json').read_text())
        results = status['results']
        if (len(results) != 3 or any(r['status'] != 'completed' for r in results[:2])
                or results[2]['status'] != 'run_failed'
                or 'Another llama-server' not in results[2].get('error', '')):
            raise RuntimeError('Experiment state changed; refusing to replace another result')
        attempt = results[2]
        destination = batch / 'interrupted-attempts' / attempt['run_id']
        destination.parent.mkdir(exist_ok=True)
        write_json(batch / 'status-before-exclusive-retry.json', status)
        (batch / attempt['run_id']).rename(destination)
        status['interrupted_attempts'] = [*status.get('interrupted_attempts', []), attempt]
        status['results'] = results[:2]
        status['stage'] = 'interrupted'
        write_json(batch / 'status.json', status)
        write_json(audit, {'stage': 'resuming', 'interrupted_attempt': str(destination)})
        subprocess.run([sys.executable, '-m', 'imajev_player.navigation_handoff',
                        '--batch', str(batch), '--after-runs', '2'], check=True, timeout=300)
        write_json(audit, {'stage': 'resumed', 'resumed_at': time.time(),
                           'interrupted_attempt': str(destination)})
    except Exception as exc:
        write_json(audit, {'stage': 'failed', 'error': repr(exc)})
        raise


if __name__ == '__main__':
    main()
