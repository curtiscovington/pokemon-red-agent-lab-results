"""Bounded UI execution: visible choices only, one input followed by fresh evidence."""
import time


def choices(state):
    ui = state.get('interface', {})
    result = {}
    if ui.get('kind') in ('dialogue', 'pokemon_preview') and not ui.get('menu_options'):
        result['skill:dialogue'] = 'Advance ordinary dialogue/preview, at most 8 inputs; stop at choices, menus, battle or overworld.'
    for item in ui.get('menu_options', []):
        result['select:' + item['label']] = 'Select visible ' + item['label'] + '; stop immediately after one confirmation.'
    if any(i['label'] == 'FIGHT' for i in ui.get('menu_options', [])):
        for member in state.get('party', []):
            for move in member.get('moves', []):
                name = move.get('name', '')
                if name and ' ' not in name and move.get('pp', 0) > 0:
                    result['use:' + name.upper()] = 'Open FIGHT and select ' + name.upper() + ' only if visibly available; confirm once.'
    return result


def resolve(action, state, enabled):
    if enabled and action == 'confirm' and 'skill:dialogue' in choices(state):
        return 'skill:dialogue'
    return action


async def execute(game, action, *, deadline, stopped, log):
    end = min(deadline, time.monotonic() + 15)
    result = {'inputs': [], 'reason': 'limit'}
    initial_map = None
    initial_kind = None
    initial_options = None
    last = None
    opened_fight = False
    for _ in range(8):
        if stopped() or time.monotonic() >= end:
            result['reason'] = 'deadline'
            break
        state = await game.state()
        log('skill_observation', state={k: state.get(k) for k in
            ('map', 'player', 'party', 'bag', 'battle', 'interface')})
        ui = state.get('interface', {})
        map_id = state.get('map', {}).get('map_id')
        if initial_map is None:
            initial_map = map_id
            initial_kind = ui.get('kind')
        if map_id != initial_map:
            result['reason'] = 'map_changed'
            break
        if action == 'skill:dialogue':
            if ui.get('kind') not in ('dialogue', 'pokemon_preview') or ui.get('menu_options') or state.get('battle', {}).get('in_battle'):
                result['reason'] = 'decision_boundary'
                break
            evidence = (ui.get('kind'), tuple(ui.get('text', [])))
            if evidence == last:
                result['reason'] = 'unchanged'
                break
            last = evidence
            button = 'press_a'
        else:
            options = ui.get('menu_options', [])
            signature = [(i['label'], i['x'], i['y']) for i in options]
            if initial_options is None:
                initial_options = signature
            if signature != initial_options or ui.get('kind') != initial_kind:
                result['reason'] = 'menu_changed'
                break
            wanted = action.split(':', 1)[1]
            if action.startswith('use:') and not opened_fight and any(i['label'] == 'FIGHT' for i in options):
                wanted = 'FIGHT'
            target = next((i for i in options if i['label'] == wanted), None)
            cursor = ui.get('menu_cursor')
            if not target or not cursor:
                result['reason'] = 'unavailable'
                break
            position = (cursor['x'], cursor['y'])
            if position == last:
                result['reason'] = 'unchanged'
                break
            last = position
            if position == (target['x'], target['y']):
                button = 'press_a'
            elif cursor['y'] != target['y']:
                button = 'walk_down' if cursor['y'] < target['y'] else 'walk_up'
            else:
                button = 'walk_right' if cursor['x'] < target['x'] else 'walk_left'
        if stopped() or time.monotonic() >= end:
            result['reason'] = 'deadline'
            break
        await game.act([button])  # Unknown write outcome propagates; never retry blindly.
        result['inputs'].append(button)
        log('skill_input', skill=action, button=button)
        if action.startswith('use:') and button == 'press_a' and wanted == 'FIGHT':
            opened_fight = True
            initial_options = None
            last = None
            continue
        if action.startswith(('select:', 'use:')) and button == 'press_a':
            result['reason'] = 'confirmed_once'
            break
    return result
