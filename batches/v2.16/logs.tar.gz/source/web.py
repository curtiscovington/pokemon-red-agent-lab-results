from __future__ import annotations

import asyncio
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from websockets.asyncio.client import connect as websocket_connect
from websockets.exceptions import ConnectionClosed

from .presentation import LabPresentation
from .runtime import PlayerRuntime

STATIC_DIR = Path(__file__).parent / "static"
presentation = LabPresentation(Path(__file__).resolve().parents[2] / "data/lab")


class ControlBody(BaseModel):
    state: str


class ActionBody(BaseModel):
    action: str


class SaveBody(BaseModel):
    name: str = "imajev_autosave"


class Hub:
    def __init__(self) -> None:
        self.clients: set[WebSocket] = set()

    async def publish(self, event: dict[str, Any]) -> None:
        message = json.dumps(event)
        dead: list[WebSocket] = []
        for client in self.clients:
            try:
                await client.send_text(message)
            except Exception:  # noqa: BLE001 - disconnected socket implementations vary
                dead.append(client)
        for client in dead:
            self.clients.discard(client)


hub = Hub()
runtime = PlayerRuntime(
    os.getenv("POKEMON_URL", "http://127.0.0.1:8766"),
    os.getenv("POKEMON_MODEL_URL", os.getenv("IMAJEV_URL", "http://127.0.0.1:11434")),
    hub.publish,
    checkpoint_path=os.getenv("POKEMON_CHECKPOINT_PATH", str(STATIC_DIR.parent.parent.parent / "data/controller_checkpoint.json")),
    model_backend=os.getenv("POKEMON_MODEL_BACKEND", "ollama"),
    model_name=os.getenv("POKEMON_MODEL_NAME", "qwen3.8:27b-q8_0"),
    memory_path=os.getenv(
        "POKEMON_MEMORY_PATH", str(Path(__file__).resolve().parents[2] / "data/model_lessons.json")
    ),
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await runtime.start()
    yield
    await runtime.close()


app = FastAPI(title="imajev plays Pokémon Red", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-store"})


async def lab_status() -> dict[str, Any] | None:
    try:
        response = await runtime.http.get("http://127.0.0.1:9877/api/status", timeout=1)
        response.raise_for_status()
        return response.json()
    except (httpx.HTTPError, ValueError):
        return None


@app.get("/broadcast/api/status")
async def broadcast_status() -> dict[str, Any]:
    lab = await lab_status()
    if lab is None:
        return await runtime.snapshot()
    game = None
    try:
        response = await runtime.http.get("http://127.0.0.1:8768/state", timeout=1)
        response.raise_for_status()
        game = response.json()
    except (httpx.HTTPError, ValueError):
        pass
    return presentation.snapshot(lab, game)


@app.websocket("/broadcast/ws")
async def broadcast_websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        while True:
            await websocket.send_json({"type": "snapshot", "value": await broadcast_status()})
            await asyncio.sleep(1)
    except (WebSocketDisconnect, RuntimeError):
        pass


@app.get("/broadcast/highlights")
async def broadcast_highlights() -> FileResponse:
    config_path = Path(__file__).resolve().parents[2] / "data/stream-watch.json"
    if config_path.exists():
        config = json.loads(config_path.read_text())
        path = Path(config["batch"]) / "highlights.md"
        if path.exists():
            return FileResponse(path, media_type="text/markdown", filename="stream-highlights.md")
    raise HTTPException(status_code=404, detail="Highlights are not available yet")


@app.get("/broadcast/api/frame")
async def broadcast_frame() -> Response:
    if await lab_status() is not None:
        response = await runtime.http.get("http://127.0.0.1:9877/api/frame", timeout=2)
        response.raise_for_status()
        return Response(response.content, media_type="image/png",
                        headers={"Cache-Control": "no-store"})
    return await frame()


@app.websocket("/broadcast/audio")
async def broadcast_audio(websocket: WebSocket) -> None:
    await websocket.accept()
    upstream = ("ws://127.0.0.1:8768/audio" if await lab_status() is not None
                else runtime.pokemon.base_url.replace("http://", "ws://") + "/audio")
    try:
        async with websocket_connect(upstream, compression=None, max_size=None) as source:
            async for message in source:
                if isinstance(message, bytes):
                    await websocket.send_bytes(message)
                else:
                    await websocket.send_text(message)
    except (OSError, ConnectionClosed, WebSocketDisconnect, RuntimeError):
        pass


@app.get("/api/status")
async def status() -> dict[str, Any]:
    return await runtime.snapshot()


@app.get("/api/frame")
async def frame() -> Response:
    try:
        image = await runtime.pokemon.screenshot()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return Response(image, media_type="image/png", headers={"Cache-Control": "no-store"})


@app.post("/api/control")
async def control(body: ControlBody) -> dict[str, str]:
    if await lab_status() is not None:
        raise HTTPException(status_code=409, detail="The overnight lab manages this run.")
    try:
        await runtime.set_control(body.state)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"state": runtime.control}


@app.post("/api/action")
async def action(body: ActionBody) -> dict[str, str]:
    if await lab_status() is not None:
        raise HTTPException(status_code=409, detail="The overnight lab manages this run.")
    await runtime.manual(body.action)
    return {"action": body.action}


@app.post("/api/maintenance/drain")
async def drain_controller() -> dict[str, str]:
    await runtime.drain()
    return {"state": "paused", "checkpoint": "saved"}


@app.post("/api/save")
async def save(body: SaveBody) -> dict[str, Any]:
    if await lab_status() is not None:
        raise HTTPException(status_code=409, detail="The overnight lab manages this run.")
    return await runtime.save(body.name)


@app.websocket("/ws")
async def websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    hub.clients.add(websocket)
    try:
        await websocket.send_json({"type": "snapshot", "value": await runtime.snapshot()})
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        hub.clients.discard(websocket)


@app.websocket("/audio")
async def audio(websocket: WebSocket) -> None:
    """Proxy emulator PCM without exposing its internal port to browsers."""
    await websocket.accept()
    upstream_url = runtime.pokemon.base_url.replace("http://", "ws://").replace(
        "https://", "wss://"
    )
    try:
        async with websocket_connect(
            f"{upstream_url}/audio", compression=None, max_size=None
        ) as upstream:
            async for message in upstream:
                if isinstance(message, bytes):
                    await websocket.send_bytes(message)
                else:
                    await websocket.send_text(message)
    except (ConnectionClosed, WebSocketDisconnect, RuntimeError):
        pass
