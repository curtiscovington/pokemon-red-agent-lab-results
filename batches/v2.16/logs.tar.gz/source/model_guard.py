"""Keep the experiment's model inside a shared-memory budget and recover within its clock."""
from __future__ import annotations

import asyncio
import contextlib
import json
import time
from pathlib import Path

import httpx

GIB = 1024 ** 3


class InvalidModelRequest(RuntimeError):
    """A rejected request must never trigger a model reload."""


class ResourcePressure(RuntimeError):
    pass


def memory_snapshot(service: str) -> dict:
    values = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        name, amount, *_ = line.split()
        if name in {'MemAvailable:', 'MemTotal:', 'SwapFree:', 'SwapTotal:'}:
            values[name.rstrip(':')] = int(amount) * 1024
    competitors, owned = [], []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            name = (proc / 'comm').read_text().strip()
            if not name.startswith('llama-server'):
                continue
            group = (proc / 'cgroup').read_text().strip()
            item = {'pid': int(proc.name), 'name': name, 'cgroup': group}
            (owned if service in group else competitors).append(item)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    pressure = Path('/proc/pressure/memory').read_text().splitlines()
    stalled = next(float(row.split('avg10=')[1].split()[0]) for row in pressure if row.startswith('full '))
    return {'ts': time.time(), **values, 'memory_stall_avg10': stalled, 'competitors': competitors, 'owned': owned}


def pressure_reason(sample: dict, minimum_gib: float) -> str | None:
    if sample['competitors']:
        return 'Another llama-server is resident or loading'
    if sample.get('memory_stall_avg10', 0) >= 10:
        return 'Memory stalls exceed 10 percent of wall time'
    if sample['MemAvailable'] < minimum_gib * GIB:
        return f'Available memory below {minimum_gib:g} GiB reserve'
    return None


class ManagedModel:
    def __init__(self, http, url, config, output, update):
        self.http, self.url, self.config = http, url, config
        self.output, self.update = output, update
        self.service = config['service']
        if self.service != 'pokemon-ollama-next.service' or url != 'http://127.0.0.1:11436':
            raise ValueError('Recovery is restricted to the dedicated Pokemon model service')
        self.running = True
        self.warmup = None
        self.recoveries = 0
        self.needs_warmup = False
        self.run_id = None

    def begin_run(self, run_id, warmup):
        self.run_id, self.warmup = run_id, warmup
        self.recoveries = 0
        self.needs_warmup = False

    def record(self, kind, **values):
        with (self.output / 'resources.jsonl').open('a', buffering=1) as target:
            target.write(json.dumps({'type': kind, 'ts': time.time(),
                                     'run_id': self.run_id, **values}) + '\n')

    def sample(self):
        sample = memory_snapshot(self.service)
        self.record('memory', **{k: v for k, v in sample.items() if k != 'ts'})
        return sample

    async def service_action(self, action):
        process = await asyncio.create_subprocess_exec(
            'systemctl', '--user', action, self.service,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            _, error = await asyncio.wait_for(process.communicate(), timeout=45)
        except BaseException:
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.wait()
            raise
        if process.returncode:
            raise RuntimeError(f'Model service {action} failed: {error.decode()[:300]}')
        self.running = action != 'stop'
        self.record('service', action=action)

    async def stop(self):
        # Stopping the service kills its runner too and prevents auto-restart churn.
        await self.service_action('stop')
        deadline = time.monotonic() + 15
        while self.sample()['owned']:
            if time.monotonic() >= deadline:
                raise RuntimeError('Dedicated model runner did not exit')
            await asyncio.sleep(1)

    async def wait_for_headroom(self, deadline):
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Resource wait reached deadline')
            reason = pressure_reason(self.sample(), self.config['load_min_available_gib'])
            if not reason:
                return
            self.update(stage='waiting_for_memory', error=reason)
            await asyncio.sleep(min(2, max(0, deadline - time.monotonic())))

    async def ready(self, deadline):
        if not self.running:
            await self.wait_for_headroom(deadline)
            await self.service_action('start')
        while time.monotonic() < deadline:
            try:
                response = await self.http.get(self.url + '/api/tags', timeout=2)
                response.raise_for_status()
                return
            except httpx.HTTPError:
                await asyncio.sleep(1)
        raise TimeoutError('Model service readiness deadline')

    async def guarded_post(self, request, deadline):
        response_task = None
        low_memory_since = None
        grace = self.config.get('cold_load_grace_seconds', 0) if request is self.warmup else self.config.get('low_memory_grace_seconds', 0)
        try:
            sample = self.sample()
            reason = pressure_reason(sample, self.config['min_available_gib'])
            if reason:
                raise ResourcePressure(reason)
            response_task = asyncio.create_task(self.http.post(
                self.url + '/api/chat', json=request, timeout=180))
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('Run deadline reached')
                done, _ = await asyncio.wait({response_task}, timeout=min(1, remaining))
                sample = self.sample()
                reason = pressure_reason(sample, self.config['min_available_gib'])
                if reason:
                    if sample['competitors']:
                        raise ResourcePressure(reason)
                    low_memory_since = low_memory_since or time.monotonic()
                    if time.monotonic() - low_memory_since >= grace:
                        raise ResourcePressure(reason)
                else:
                    low_memory_since = None
                if done:
                    response = response_task.result()
                    if 400 <= response.status_code < 500:
                        raise InvalidModelRequest(f'Model rejected request ({response.status_code}): {response.text[:500]}')
                    response.raise_for_status()
                    return response.json()
        finally:
            if response_task and not response_task.done():
                response_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await response_task

    async def request(self, request, *, deadline, is_warmup=False, event_log=None):
        while time.monotonic() < deadline:
            try:
                await self.ready(deadline)
                if self.needs_warmup and not is_warmup:
                    self.update(stage='recovering_model', error=None)
                    if event_log:
                        event_log('recovery_warmup_request', request=self.warmup)
                    payload = await self.guarded_post(self.warmup, deadline)
                    if event_log:
                        event_log('recovery_warmup_response', response=payload)
                    self.needs_warmup = False
                self.update(stage='loading' if is_warmup else 'thinking', error=None)
                return await self.guarded_post(request, deadline)
            except ResourcePressure as exc:
                self.record('resource_abort', reason=str(exc))
                self.update(stage='resource_abort', error=str(exc))
                await self.stop()
                raise
            except (httpx.HTTPError, TimeoutError) as exc:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Original run deadline reached') from exc
                self.recoveries += 1
                self.record('recovery', reason=repr(exc), number=self.recoveries)
                if event_log:
                    event_log('model_recovery', reason=repr(exc), number=self.recoveries)
                self.update(stage='recovering_model', error=str(exc), recoveries=self.recoveries)
                await self.stop()
                self.needs_warmup = True
                if self.recoveries > self.config['max_recoveries_per_run']:
                    raise RuntimeError('Model recovery budget exhausted') from exc
                # No reset, new seed, new starting save, or extension to the run's deadline.
                await asyncio.sleep(min(5, max(0, deadline - time.monotonic())))
        raise TimeoutError('Original run deadline reached')
