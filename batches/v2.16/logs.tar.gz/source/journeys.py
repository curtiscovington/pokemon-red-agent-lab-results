"""Directed, observed map journeys; normal navigation inputs and verified arrivals."""
import time
from collections import deque

from .navigation import interrupted, navigate


class Journeys:
    def __init__(self):
        self.edges = {}
        self.destination = None

    def learn(self, before, target, after):
        source = before.get('map', {}).get('map_id')
        destination = after.get('map', {}).get('map_id')
        if source is not None and destination is not None and source != destination:
            # A changed destination replaces a stale edge, never implies a reverse edge.
            self.edges[(source, target)] = destination

    def path(self, source, destination):
        queue = deque([(source, [])])
        seen = {source}
        while queue:
            current, steps = queue.popleft()
            if current == destination:
                return steps
            for (origin, target), arrival in self.edges.items():
                if origin == current and arrival not in seen:
                    seen.add(arrival)
                    queue.append((arrival, steps + [(origin, target, arrival)]))
        return None

    def choices(self, state):
        current = state.get('map', {}).get('map_id')
        choices = {}
        if not interrupted(state):
            for destination in sorted(set(self.edges.values())):
                path = self.path(current, destination)
                if path and len(choices) < 8:
                    choices[f'travel:{destination}'] = f'Travel to visited map {destination} via {len(path)} observed connections.'
            if self.destination is not None:
                choices['resume_journey'] = f'Resume journey to map {self.destination}; arrival is checked.'
        if self.destination is not None:
            choices['cancel_journey'] = 'Cancel the retained destination.'
        return choices

    def context(self, state):
        current = state.get('map', {}).get('map_id')
        if current == self.destination:
            self.destination = None
        return {'destination_map_id': self.destination,
                'instruction': 'Travel pauses for battle/dialogue. Resolve it, then resume_journey. Cancel if the goal changes.'}

    async def execute(self, game, action, *, deadline, stopped, log, update):
        result = {'inputs': [], 'reason': 'cancelled'}
        if action == 'cancel_journey':
            self.destination = None
            return result
        if action.startswith('travel:'):
            self.destination = int(action.split(':')[1])
        for _ in range(8):
            if stopped() or time.monotonic() >= deadline:
                result['reason'] = 'deadline'
                return result
            state = await game.state()
            current = state.get('map', {}).get('map_id')
            if self.destination is None or current == self.destination:
                self.destination = None
                result['reason'] = 'arrived'
                return result
            if interrupted(state):
                result['reason'] = 'dialogue_or_battle'
                return result
            path = self.path(current, self.destination)
            if not path:
                result['reason'] = 'no_observed_route'
                return result
            source, target, expected = path[0]
            step = await navigate(game, target, deadline=deadline, stopped=stopped, log=log, update=update)
            result['inputs'].extend(step['inputs'])
            after = await game.state()
            actual = after.get('map', {}).get('map_id')
            log('journey_leg', source=source, target=target, expected=expected, actual=actual,
                destination=self.destination, reason=step['reason'])
            if actual != current:
                self.learn(state, target, after)
                if actual != expected:
                    result['reason'] = 'unexpected_arrival'
                    return result
            else:
                if step['reason'] in ('blocked', 'target_unavailable'):
                    self.edges.pop((source, target), None)
                result['reason'] = step['reason']
                return result
        result['reason'] = 'leg_limit'
        return result
