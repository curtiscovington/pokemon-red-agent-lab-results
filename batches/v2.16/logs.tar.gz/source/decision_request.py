"""Shared factual inputs for structured versus action-only decision experiments."""
import base64
import json

from .actions import LAB_ACTION_MACROS
from .navigation import choices as navigation_choices
from .skills import choices as skill_choices


def compact_facts(state):
    return {
        'map': state.get('map'), 'position': state.get('player', {}).get('position'),
        'facing': state.get('player', {}).get('facing'),
        'badges': state.get('player', {}).get('badges'),
        'party': [{k: p.get(k) for k in ('species', 'species_id', 'level', 'hp', 'max_hp', 'status', 'moves')}
                  for p in state.get('party', [])],
        'bag': state.get('bag', []), 'battle': state.get('battle'),
        'interface': state.get('interface'),
    }


def build(run, state, screenshot, history, memory):
    allowed = {k:v.description for k,v in LAB_ACTION_MACROS.items()}
    if state.get('interface', {}).get('kind') != 'naming':
        allowed.pop('finish_name', None)
    allowed.update(navigation_choices(state))
    allowed.update(skill_choices(state))
    if any(a.startswith('use:') for a in allowed):
        allowed.pop('fight_first_move', None)
    if 'skill:dialogue' in allowed:
        allowed['confirm'] = allowed['skill:dialogue']
    memory = memory or {}
    destinations = {}
    current_map = state.get('map', {}).get('map_id')
    for fact in memory.get('persistent_evidence', []):
        if isinstance(fact, list) and len(fact) >= 4 and fact[0] == 'route' and fact[1] == current_map:
            action = 'go:' + fact[2]
            if action in allowed:
                destinations[action] = {'map_id': fact[3],
                    'name': fact[4] if len(fact) > 4 else f'Map {fact[3]}'}
                allowed[action] += f"; observed destination: {destinations[action]['name']} (map {fact[3]})"
    context = {'state': compact_facts(state), 'evidence': (memory or {}).get('persistent_evidence', []),
               'recent_actions': [h.get('action') for h in history[-4:]], 'allowed_actions': allowed}
    context['observed_destinations'] = destinations
    context['repeat_feedback'] = {
        'same_state_action_repeats': memory.get('observed_repeated_attempts', 0),
        'reconsider': memory.get('reconsider', False)}
    if memory.get('reconsider'):
        repeated = list(dict.fromkeys(h.get('action') for h in history[-4:] if h.get('action') in allowed))
        context['repeat_feedback']['repeated_local_actions'] = repeated
        context['repeat_feedback']['instruction'] = (
            'These choices repeatedly returned to the same state without progress. '
            'Choose a different local target now; explore an untried exit if available. '
            'Only repeat if you can identify a changed condition that makes it useful.')
    if run.get('objective_controller'):
        context['objective'] = state.get('verified_objective', {})
    prefix = ('Play Pokemon Red and become Champion. Current observation overrides old assumptions. '
              'go: walks to a local target and stops on interruption. confirm advances ordinary dialogue '
              'but stops at choices. use: selects a named battle move once. Do not invent map IDs. '
              'Observed destinations override guessed exits. When reconsider is true, repeated actions '
              'have returned to the same state: choose a different available target unless backtracking '
              'is necessary for the current task. If an explanation is requested, write one complete '
              'sentence of at most 20 words; do not narrate coordinates or repeat the action list. ')
    # Both modes use identical evidence/action pruning. Output contract is in the schema.
    def encode():
        return prefix + json.dumps(context, ensure_ascii=False, separators=(',', ':'))
    if len(encode().encode()) > 6000:
        # Descriptions duplicate action names; retain every legal choice and current facts.
        context['allowed_actions'] = list(allowed)
    while len(encode().encode()) > 6000 and context['recent_actions']:
        context['recent_actions'].pop(0)
    while len(encode().encode()) > 6000 and context['evidence']:
        context['evidence'] = context['evidence'][:-1]
    if len(encode().encode()) > 6000:
        raise ValueError('Essential decision state exceeds prompt budget')
    schema = {'type':'object', 'properties':{'action':{'type':'string','enum':list(allowed)}},
              'required':['action'], 'additionalProperties':False}
    if not run.get('action_only'):
        schema['properties']['explanation'] = {'type':'string','maxLength':480}
        schema['required'].append('explanation')
    return {'model':run['model'],'stream':False,'think':False,'keep_alive':-1,'format':schema,
            'options':{'temperature':0.2,'seed':run['seed'],'num_ctx':8192,
                       'num_predict':64 if run.get('action_only') else 384},
            'messages':[{'role':'user','images':[base64.b64encode(screenshot).decode()], 'content':encode()}]}
