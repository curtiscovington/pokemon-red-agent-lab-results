from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def wait_for(url: str, name: str, timeout: int = 180) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2):
                print(f"✓ {name} ready")
                return
        except (OSError, urllib.error.URLError):
            time.sleep(1)
    raise RuntimeError(f"Timed out waiting for {name}: {url}")


def ollama_model_info(base_url: str, model: str) -> dict[str, object]:
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/show",
        data=json.dumps({"model": model}).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        return json.load(response)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a local vision model playing Pokémon Red")
    parser.add_argument("rom", type=Path, help="Path to your legally obtained Pokémon Red .gb ROM")
    parser.add_argument("--port", type=int, default=9876, help="Dashboard port")
    parser.add_argument(
        "--load-state",
        help="Restore a named save state from data/saves when starting the emulator",
    )
    parser.add_argument("--no-model", action="store_true", help="Only start the game and dashboard")
    parser.add_argument("--external-emulator", action="store_true", help="Attach to an independently managed emulator; never stop it on controller exit")
    parser.add_argument(
        "--model-backend",
        choices=("ollama", "imajev"),
        default=os.getenv("POKEMON_MODEL_BACKEND", "ollama"),
        help="Model API to use (default: ollama)",
    )
    parser.add_argument("--model", help="Model name (defaults to the preferred model for the backend)")
    parser.add_argument("--model-url", help="Use an already-running model server at this URL")
    args = parser.parse_args()

    rom = args.rom.expanduser().resolve()
    if not rom.is_file() or rom.suffix.lower() not in {".gb", ".gbc"}:
        parser.error(f"ROM not found or not a .gb/.gbc file: {rom}")

    model_name = args.model or (
        "qwen3.8:27b-q8_0" if args.model_backend == "ollama" else "imajev-4b"
    )
    model_url = args.model_url or (
        "http://127.0.0.1:11434" if args.model_backend == "ollama" else "http://127.0.0.1:8767"
    )

    runtime_dir = ROOT / ".runtime"
    model_repo = runtime_dir / "imajev"
    model_python = model_repo / ".venv" / "bin" / "python"
    adapter = model_repo / "adapters" / "imajev-4b"
    bundle = model_repo / "artifacts" / "model-qwen4b.json"
    if not args.no_model and args.model_backend == "imajev" and not args.model_url:
        model_ready = False
        if (
            model_python.exists()
            and adapter.joinpath("adapter_model.safetensors").exists()
            and bundle.exists()
        ):
            try:
                bundle_data = json.loads(bundle.read_text())
                snapshot = Path(bundle_data["path"])
                if not snapshot.is_absolute():
                    snapshot = model_repo / snapshot
                index_path = snapshot / "model.safetensors.index.json"
                index = json.loads(index_path.read_text())
                shards = set(index["weight_map"].values())
                model_ready = bool(shards) and all(
                    (snapshot / shard).is_file() and (snapshot / shard).stat().st_size > 0
                    for shard in shards
                )
            except (KeyError, OSError, ValueError):
                model_ready = False
        if not model_ready:
            parser.error("imajev weights are incomplete. Run ./scripts/setup.sh to resume setup.")

    if not args.no_model and args.model_backend == "ollama":
        try:
            info = ollama_model_info(model_url, model_name)
        except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
            parser.error(f"Cannot load Ollama model {model_name!r} at {model_url}: {exc}")
        missing = {"vision", "tools"} - set(info.get("capabilities", []))
        if missing:
            parser.error(f"Ollama model {model_name!r} lacks: {', '.join(sorted(missing))}")

    data_dir = ROOT / "data"
    data_dir.mkdir(exist_ok=True)
    env = os.environ.copy()
    env["POKEMON_URL"] = "http://127.0.0.1:8766"
    env["POKEMON_MODEL_BACKEND"] = args.model_backend
    env["POKEMON_MODEL_NAME"] = model_name
    env["POKEMON_MODEL_URL"] = "http://127.0.0.1:1" if args.no_model else model_url
    processes: list[subprocess.Popen[bytes]] = []
    try:
        emulator_command = [
            str(ROOT / ".venv/bin/python"),
            "-m",
            "imajev_player.emulator_server",
            "--rom",
            str(rom),
            "--port",
            "8766",
            "--data-dir",
            str(data_dir),
        ]
        if args.load_state:
            emulator_command.extend(["--load-state", args.load_state])
        if not args.external_emulator:
            processes.append(
                subprocess.Popen(
                    emulator_command,
                    cwd=ROOT,
                    env=env,
                )
            )
        wait_for("http://127.0.0.1:8766/health", "Pokémon emulator")
        if not args.no_model and args.model_backend == "imajev" and not args.model_url:
            processes.append(
                subprocess.Popen(
                    [
                        str(model_python),
                        "scripts/playground/server.py",
                        "--backend",
                        "torch",
                        "--model-bundle",
                        str(bundle),
                        "--adapter",
                        str(adapter),
                        "--rotations",
                        "1",
                        "--calibration",
                        str(adapter / "calibration.json"),
                        "--model-name",
                        model_name,
                        "--port",
                        "8767",
                    ],
                    cwd=model_repo,
                    env={**env, "PYTHONPATH": "src:scripts"},
                )
            )
            wait_for(f"{model_url}/docs", model_name, timeout=420)
        print(f"\nOpen http://127.0.0.1:{args.port}\n")
        dashboard = subprocess.Popen(
            [
                str(ROOT / ".venv/bin/uvicorn"),
                "imajev_player.web:app",
                "--host",
                "0.0.0.0",
                "--port",
                str(args.port),
                "--no-access-log",
            ],
            cwd=ROOT,
            env=env,
        )
        processes.append(dashboard)
        dashboard.wait()
    except KeyboardInterrupt:
        pass
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.send_signal(signal.SIGTERM)
        for process in reversed(processes):
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()


if __name__ == "__main__":
    main()
