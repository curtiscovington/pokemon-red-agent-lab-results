"""Persistent observations, never inferred routes or hidden map knowledge."""
import json
from collections import deque


def location(observation):
    position = observation.get("position")
    if observation.get("map_id") is None or not isinstance(position, dict):
        return None
    if not all(isinstance(position.get(axis), int) for axis in ("x", "y")):
        return None
    return json.dumps([observation["map_id"], position["x"], position["y"]])


def record(memory, outcome):
    before, after = outcome.get("before", {}), outcome.get("after", {})
    if any(obs.get("in_battle") or obs.get("dialog_active") for obs in (before, after)):
        return
    start, end = location(before), location(after)
    if start is None or end is None:
        return
    for key in {start, end}:
        memory.setdefault(key, {"visits": 0, "attempts": {}})
    memory[end]["visits"] += 1
    action = outcome.get("action")
    if action not in {"up", "down", "left", "right"}:
        return
    attempt = memory[start]["attempts"].setdefault(action, {
        "moved": 0, "no_displacement": 0, "turned": 0, "destinations": [],
    })
    result = "moved" if start != end else (
        "turned" if before.get("facing") != after.get("facing") else "no_displacement"
    )
    attempt[result] += 1
    attempt["last_turn"] = outcome.get("turn")
    attempt["last_result"] = result
    if start != end and end not in attempt["destinations"]:
        attempt["destinations"].append(end)


def context(memory, observation):
    key = location(observation)
    if key is None:
        return {}
    map_id, x, y = json.loads(key)
    same_map = [(k, v) for k, v in memory.items() if json.loads(k)[0] == map_id]
    same_map.sort(key=lambda item: abs(json.loads(item[0])[1] - x)
                  + abs(json.loads(item[0])[2] - y))
    return {
        "source": "recorded controller observations",
        "limits": "Only visited positions; unlisted terrain is unknown. No displacement is not proof of a wall.",
        "visited_positions_total": len(memory),
        "visited_positions_this_map": len(same_map),
        "nearby_observed_positions": dict(same_map[:16]),
        "current_position_attempts": memory.get(key, {}).get("attempts", {}),
        "observed_untested_openings": [
            {"position": k, "direction": direction, "status": "estimated_open_untried"}
            for k, value in same_map
            for direction, estimate in value.get("openings", {}).items()
            if estimate == "estimated_open" and not value["attempts"].get(direction)
        ][:16],
        "observed_map_transitions": [
            {"from": k, "action": action, "to": destination}
            for k, value in same_map for action, attempt in value["attempts"].items()
            for destination in attempt["destinations"] if json.loads(destination)[0] != map_id
        ],
    }


def observe_openings(memory, observation, adjacent):
    """Remember local estimates only; never infer an exit or global crop coordinates."""
    key = location(observation)
    if key is None or observation.get("in_battle") or observation.get("dialog_active"):
        return
    entry = memory.setdefault(key, {"visits": 0, "attempts": {}})
    entry["openings"] = dict(adjacent)


def navigation(memory, observation, outcomes):
    """Shortest directed routes to untested openings, using observed edges only."""
    start = location(observation)
    if start is None or observation.get("in_battle") or observation.get("dialog_active"):
        return {"options": [], "loop_detected": False}
    recent = []
    for outcome in outcomes:
        if outcome.get("source") == "manual" or any(
            outcome.get(side, {}).get(flag)
            for side in ("before", "after") for flag in ("in_battle", "dialog_active")
        ):
            recent.clear()
            continue
        end = location(outcome.get("after", {}))
        if end:
            recent.append(end)
    window = recent[-12:]
    paths, pending, candidates = {start: []}, deque([start]), []
    while pending and len(paths) <= 2048:
        node = pending.popleft()
        entry = memory.get(node, {})
        attempts, path = entry.get("attempts", {}), paths[node]
        for direction, estimate in entry.get("openings", {}).items():
            attempt = attempts.get(direction, {})
            if direction in {"up", "down", "left", "right"} and estimate == "estimated_open" and not attempt.get("moved") and not attempt.get("no_displacement"):
                candidates.append({"position": node, "test_direction": direction,
                    "steps": len(path) + 1, "first_action": path[0] if path else direction,
                    "kind": "test_unexplored_opening", "visits": entry.get("visits", 0)})
        for direction, attempt in attempts.items():
            destinations = attempt.get("destinations", [])
            if direction not in {"up", "down", "left", "right"} or len(destinations) != 1 or attempt.get("last_result") == "no_displacement":
                continue
            destination = destinations[0]
            if not attempt.get("moved") or destination in paths or destination not in memory:
                continue
            paths[destination] = path + [direction]
            pending.append(destination)
    candidates.sort(key=lambda item: (item["steps"], item["visits"], item["position"], item["test_direction"]))
    return {
        "options": [{**item, "id": f"navigate_{i}"} for i, item in enumerate(candidates[:6])],
        "loop_detected": len(window) >= 8 and len(set(window)) <= 4,
        "recent_unique_positions": len(set(window)), "recent_moves": len(window),
        "reachable_positions": len(paths), "observed_positions": len(memory),
        "policy": "Routes use observed directed moves only. Final step tests an opening estimate. Execute one step and replan from fresh evidence.",
    }
