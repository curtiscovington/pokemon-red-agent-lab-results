"""Small per-run notebook: model-written intentions, separately labeled observed outcomes."""
import json
from collections import deque
from itertools import zip_longest


def short(value, size=160):
    return value.encode()[:size].decode(errors='ignore') if isinstance(value, str) else ''


class TaskMemory:
    def __init__(self):
        self.objective = ''
        self.note = ''
        self.visited = deque(maxlen=6)
        self.outcomes = deque(maxlen=4)

    def observe(self, state):
        item = state.get('map', {})
        name = short(str(item.get('map_name', '')), 40)
        entry = [item.get('map_id'), name]
        if entry not in self.visited:
            self.visited.append(entry)

    def record(self, payload, action, result):
        content = json.loads(payload['message']['content'])
        if isinstance(content.get('objective'), str):
            self.objective = short(content['objective'])
        if isinstance(content.get('note'), str):
            self.note = short(content['note'])
        if action.startswith('go:'):
            self.outcomes.append([short(action, 60), short(result.get('reason'), 40),
                                  len(result.get('inputs', []))])

    def snapshot(self):
        value = {'model_objective': self.objective, 'model_note': self.note,
                 'observed_maps': list(self.visited), 'observed_navigation': list(self.outcomes)}
        while len(json.dumps(value, ensure_ascii=False).encode()) > 900:
            if value['observed_navigation']:
                value['observed_navigation'].pop(0)
            elif value['observed_maps']:
                value['observed_maps'].pop(0)
            else:
                break
        return value


class AdaptiveTaskMemory(TaskMemory):
    """Evidence-linked plan with advisory repetition detection, never automatic success."""

    def __init__(self):
        super().__init__()
        self.plan = {key: '' for key in ('next_step', 'success_check', 'blocker', 'status')}
        self.attempts = deque(maxlen=12)
        self.observation = ''
        self.repeat_count = 0

    def observe(self, state):
        super().observe(state)
        # Ignore clocks/animation; include dialogue, inventory and battle changes.
        evidence = {key: state.get(key) for key in ('map', 'party', 'bag', 'interface', 'battle')}
        evidence['position'] = state.get('player', {}).get('position')
        self.observation = json.dumps(evidence, sort_keys=True)
        self.repeat_count = max((sum(item == (self.observation, action) for item in self.attempts)
                                 for _, action in self.attempts), default=0)

    def record(self, payload, action, result):
        super().record(payload, action, result)
        content = json.loads(payload['message']['content'])
        for key in self.plan:
            if isinstance(content.get(key), str):
                self.plan[key] = short(content[key], 80)
        self.objective = short(self.objective, 80)
        self.note = short(self.note, 80)
        self.attempts.append((self.observation, action))

    def snapshot(self):
        value = super().snapshot()
        value['model_plan'] = dict(self.plan)
        value['observed_repeated_attempts'] = self.repeat_count
        value['reconsider'] = self.repeat_count >= 3
        while len(json.dumps(value, ensure_ascii=False).encode()) > 900:
            if value['observed_maps']:
                value['observed_maps'].pop(0)
            elif value['observed_navigation']:
                value['observed_navigation'].pop(0)
            else:
                break
        return value


class EvidenceTaskMemory(AdaptiveTaskMemory):
    """Small literal observation journal; never interprets dialogue or predicts routes."""

    def __init__(self):
        super().__init__()
        self.journal = deque(maxlen=3)
        self.inventory_change = None
        self.previous_map = None
        self.previous_bag = None
        self.last_action = None

    def observe(self, state):
        super().observe(state)
        map_id = state.get('map', {}).get('map_id')
        bag = {str(i.get('id')): i.get('quantity') for i in state.get('bag', [])}
        if self.previous_bag is not None and bag != self.previous_bag:
            changes = [[k, bag.get(k, 0)] for k in sorted(bag.keys() | self.previous_bag.keys())
                       if bag.get(k, 0) != self.previous_bag.get(k, 0)]
            self.inventory_change = ['bag_changed_id_quantity', changes[:3]]
        if self.previous_map is not None and map_id != self.previous_map:
            self.add_evidence(['map_transition', self.previous_map, map_id, self.last_action])
        text = ' '.join(state.get('interface', {}).get('text', []))
        if text and not state.get('battle', {}).get('in_battle'):
            self.add_evidence(['dialogue_fragment', map_id, short(text, 100)])
        self.previous_map, self.previous_bag = map_id, bag

    def add_evidence(self, entry):
        # Do not let repeated pages refresh themselves indefinitely.
        if entry not in self.journal:
            self.journal.append(entry)

    def record(self, payload, action, result):
        super().record(payload, action, result)
        self.last_action = short(action, 60)

    def snapshot(self):
        value = super().snapshot()
        entries = list(self.journal)
        pinned = [self.inventory_change] if self.inventory_change else []
        while entries and len(json.dumps(pinned + entries, ensure_ascii=False).encode()) > 320:
            entries.pop(0)
        value['observed_evidence'] = pinned + entries
        while len(json.dumps(value, ensure_ascii=False).encode()) > 900:
            if value['observed_maps']:
                value['observed_maps'].pop(0)
            elif value['observed_navigation']:
                value['observed_navigation'].pop(0)
            elif len(value['observed_evidence']) > len(pinned):
                value['observed_evidence'].pop(len(pinned))
            else:
                # Preserve the plan; the latest inventory observation takes priority over notes.
                key = 'model_note' if value['model_note'] else 'model_objective'
                if not value[key]:
                    value['observed_evidence'] = []
                    break
                value[key] = short(value[key], max(0, len(value[key].encode()) - 20))
        return value


class DurableEvidenceMemory(AdaptiveTaskMemory):
    """Bounded deduplicated facts, with separate capacity for routes and dialogue."""

    def __init__(self):
        super().__init__()
        self.routes = {}
        self.map_names = {}
        self.facts = {}
        self.tasks = {}
        self.current_map = None
        self.pending_target = None
        self.bag = []

    def observe(self, state):
        super().observe(state)
        current = state.get('map', {}).get('map_id')
        name = state.get('map', {}).get('map_name')
        if name:
            self.map_names[current] = short(name, 40)
        while len(self.map_names) > 24:
            del self.map_names[next(iter(self.map_names))]
        if self.pending_target and current != self.pending_target[0]:
            origin, target = self.pending_target
            self.routes[(origin, target)] = current
            self.pending_target = None
        self.current_map = current
        self.bag = [[i.get('id'), i.get('quantity')] for i in state.get('bag', [])][:8]
        text = ' '.join(state.get('interface', {}).get('text', []))
        if text and not state.get('battle', {}).get('in_battle'):
            fragment = short(text, 100)
            key = (current, fragment)
            # Repetition does not refresh/evict facts; routes never evict dialogue.
            self.facts.setdefault(key, fragment)
            if any(word in text.lower() for word in ('deliver', 'parcel', 'take this', 'bring', 'give this')):
                self.tasks.setdefault(key, fragment)
        for table, limit in ((self.routes, 24), (self.facts, 16), (self.tasks, 4)):
            while len(table) > limit:
                del table[next(iter(table))]

    def record(self, payload, action, result):
        super().record(payload, action, result)
        if action.startswith('go:'):
            if result.get('reason') == 'map_changed':
                self.pending_target = (self.current_map, short(action[3:], 55))
            elif result.get('reason') in ('blocked', 'target_unavailable'):
                self.routes.pop((self.current_map, action[3:]), None)

    def snapshot(self):
        value = super().snapshot()
        value.pop('observed_maps', None)
        value.pop('observed_navigation', None)
        value['model_note'] = short(value['model_note'], 40)
        # Retrieval is local-first; underlying records survive changing maps.
        routes = sorted(self.routes.items(), key=lambda pair: pair[0][0] != self.current_map)
        facts = sorted(self.facts, key=lambda key: key[0] != self.current_map)
        candidates = ([['task_text_unverified', k[0], v] for k, v in self.tasks.items()]
                      + [['route', origin, target, dest, self.map_names.get(dest, f'Map {dest}')]
                         for (origin, target), dest in routes[:4]]
                      + [['dialogue_fragment', k[0], self.facts[k]] for k in facts[:4]])
        # Interleave local facts with routes so one category cannot crowd out the other.
        task_count = len(self.tasks)
        route_count = min(4, len(routes))
        candidates = candidates[:task_count] + [item for pair in zip_longest(
            candidates[task_count:task_count+route_count],
            candidates[task_count+route_count:]) for item in pair if item is not None]
        value['inventory_now'] = self.bag[:3]
        value['persistent_evidence'] = []
        for item in candidates:
            value['persistent_evidence'].append(item)
            if len(json.dumps(value, ensure_ascii=False).encode()) > 900:
                value['persistent_evidence'].pop()
        return value
