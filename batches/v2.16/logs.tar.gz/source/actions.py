from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionMacro:
    label: str
    description: str
    actions: tuple[str, ...]


ACTION_MACROS: dict[str, ActionMacro] = {
    "confirm": ActionMacro(
        "A",
        "Confirm, talk, select, or advance text.",
        ("press_a",),
    ),
    "fast_confirm": ActionMacro(
        "B + A",
        "Finish slow text, then confirm once.",
        ("hold_b_60", "press_a"),
    ),
    "cancel": ActionMacro("B", "Cancel, return, or close the current menu.", ("press_b",)),
    "menu": ActionMacro("START", "Open or close the main game menu.", ("press_start",)),
    "up": ActionMacro("UP", "Walk exactly one tile up.", ("walk_up",)),
    "down": ActionMacro("DOWN", "Walk exactly one tile down.", ("walk_down",)),
    "left": ActionMacro("LEFT", "Walk exactly one tile left.", ("walk_left",)),
    "right": ActionMacro("RIGHT", "Walk exactly one tile right.", ("walk_right",)),
    "fight_first_move": ActionMacro(
        "FIGHT · MOVE 1",
        "In battle, choose FIGHT and use the first move.",
        ("press_a", "press_a", "hold_b_60"),
    ),
    "run": ActionMacro(
        "RUN",
        "From the default battle command cursor, move to RUN and confirm.",
        ("walk_down", "walk_right", "press_a"),
    ),
    "wait": ActionMacro(
        "WAIT",
        "Wait once for a non-looping transition; never repeat on a title screen or unchanged frame.",
        ("wait_60",),
    ),
}


def criteria() -> dict[str, str]:
    return {key: macro.description for key, macro in ACTION_MACROS.items()}


def resolve(choice: str | None) -> tuple[str, ActionMacro]:
    key = choice if choice in ACTION_MACROS else "wait"
    return key, ACTION_MACROS[key]


LAB_ACTION_MACROS = {
    **ACTION_MACROS,
    "finish_name": ActionMacro("FINISH NAME", "On the naming keyboard, submit the current name with START.", ("press_start",)),
}
