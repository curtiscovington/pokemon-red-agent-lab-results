"""Pinned, one-shot navigation upgrade at a completed-run boundary."""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import httpx

from .experiment_sequence import service
from .lab import ROOT, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', type=Path, required=True)
    parser.add_argument('--after-runs', type=int, required=True)
    args = parser.parse_args()
    batch, boundary = args.batch.resolve(), args.after_runs
    original_invocation = service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value')
    plan = {'batch': str(batch), 'after_runs': boundary, 'protocol': 'lab-v2.3-downward-ledges',
            'original_invocation': original_invocation, 'requested_at': time.time()}

    def record(**values):
        plan.update(values)
        write_json(batch / 'autowalk-handoff.json', plan)
        print(json.dumps(values), flush=True)

    override = Path(f'/run/user/{os.getuid()}/systemd/user/pokemon-lab.service.d/95-navigation-resume.conf')
    transitioning = False
    record(stage='waiting_for_run_boundary')
    try:
        expires = time.monotonic() + 7200
        while time.monotonic() < expires:
            status = json.loads((batch / 'status.json').read_text())
            if len(status['results']) == boundary:
                if any(r['status'] != 'completed' for r in status['results']):
                    raise RuntimeError('A preceding run failed; refusing automatic continuation')
                break
            if len(status['results']) > boundary or status['stage'] in {'failed', 'interrupted', 'complete'}:
                raise RuntimeError('Requested run boundary is no longer available')
            if service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value') != original_invocation:
                raise RuntimeError('Another lab service invocation replaced the pinned experiment')
            time.sleep(.2)
        else:
            raise TimeoutError('Run-boundary wait expired')
        if service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value') != original_invocation:
            raise RuntimeError('Pinned experiment changed at the boundary')
        transitioning = True
        record(stage='restarting_at_boundary', boundary_reached_at=time.time())
        service('stop', 'pokemon-stream-watch.service')
        service('stop', 'pokemon-lab.service')
        # There can be an unscored load attempt in the brief polling/stop window.
        # Preserve it outside the run list; the replacement starts fresh at run N+1.
        archived = []
        for folder in sorted(batch.iterdir()):
            if folder.is_dir() and folder.name[:2].isdigit() and int(folder.name[:2]) > boundary:
                summary = folder / 'summary.json'
                if summary.exists() and json.loads(summary.read_text()).get('actions', 0):
                    raise RuntimeError('A later run already acted; refusing to discard scored play')
                destination = batch / 'superseded-loads' / folder.name
                destination.parent.mkdir(exist_ok=True)
                folder.rename(destination)
                archived.append(folder.name)
        # Discard only an interrupted zero-action load summary, if one was emitted.
        stopped = json.loads((batch / 'status.json').read_text())
        stopped['results'] = stopped['results'][:boundary]
        write_json(batch / 'status.json', stopped)
        override.parent.mkdir(parents=True, exist_ok=True)
        override.write_text('[Service]\nExecStart=\nExecStart=' + str(ROOT / '.venv/bin/python')
                            + f' -m imajev_player.lab --resume {batch} --after-runs {boundary}\n')
        service('daemon-reload')
        service('start', 'pokemon-ollama-next.service')
        service('start', 'pokemon-lab.service')
        with httpx.Client(timeout=3) as http:
            for _ in range(60):
                try:
                    response = http.get('http://127.0.0.1:9877/api/status')
                    response.raise_for_status()
                    resumed = response.json()
                    if resumed.get('batch_id') == batch.name and resumed.get('protocol_changes'):
                        if resumed['stage'] in {'failed', 'interrupted'}:
                            raise RuntimeError('Resumed experiment failed startup')
                        if (resumed.get('current') or {}).get('index') == boundary + 1:
                            break
                except httpx.HTTPError:
                    pass
                time.sleep(1)
            else:
                raise RuntimeError('Resumed experiment did not reach the next run')
        write_json(ROOT / 'data/stream-watch.json', {
            'batch': str(batch), 'tail_seconds': 30,
            'lab_invocation_id': service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value'),
        })
        service('restart', 'pokemon-stream-watch.service')
        record(stage='applied', applied_at=time.time(), superseded_loads=archived)
        with (ROOT / 'RESEARCH-NOTES.md').open('a') as notes:
            notes.write(f'\nNavigation handoff applied to {batch.name} after run {boundary}. '
                        f'Runs {boundary+1}–8 use v2.3; earlier runs retain v2.2. '
                        'Original source snapshot and results preserved; revision manifest/source archived.\n')
    except Exception as exc:
        record(stage='failed', error=repr(exc))
        if transitioning:
            service('stop', 'pokemon-lab.service')
            service('stop', 'pokemon-ollama-next.service')
        raise
    finally:
        if override.exists():
            override.unlink()
            service('daemon-reload')


if __name__ == '__main__':
    main()
