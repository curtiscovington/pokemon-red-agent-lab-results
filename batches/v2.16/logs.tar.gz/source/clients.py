from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass
from io import BytesIO
from typing import Any, Protocol

import httpx
from PIL import Image, ImageDraw

from .actions import criteria

MAX_QUEUED_ACTIONS = 6
MAX_SHORT_TERM_GOAL_LENGTH = 240
MAX_MEDIUM_TERM_GOAL_LENGTH = 500
MAX_LESSON_LENGTH = 300
MAX_LESSON_UPDATES_PER_TURN = 3

LEGACY_OLLAMA_SYSTEM_PROMPT = (
    "You are playing Pokémon Red with short, bounded controller queues. Study the current frame "
    "and structured state, reason about the safest next step, then call press_buttons exactly once "
    "with one to six actions. Use a multi-action queue only for a sequence that is safe without "
    "seeing an intermediate frame, such as certain movement across clear tiles. Use one action "
    "around dialogue, menus, battles, map transitions, obstacles, or any uncertainty. Never combine "
    "wait with another action. Keep analysis focused and under 120 words: do not repeatedly restate "
    "the goals, state, collision map, or an unsupported belief. Finish with the tool call before the "
    "generation limit. Never claim an action without calling the tool. Prefer confirm when text is "
    "waiting, use battle macros only in battle, and use wait only for an active non-looping "
    "transition. The ultimate goal is fixed: complete Pokémon Red. You—not the operator—own the "
    "short- and medium-term goals. If either is unset, set it now with the appropriate goal tool. "
    "Change either goal whenever it is complete, stale, poorly scoped, or a better plan emerges. "
    "You must still call press_buttons exactly once on every turn. "
    "\n\nUse this evidence-and-memory loop on every turn: "
    "Read current_game_state.adjacent_tiles before interpreting the ASCII map. These are "
    "local collision estimates, not guaranteed movement. Use attempts_from_current_position "
    "to check what actually happened here. A facing change without displacement is a turn-only "
    "observation, not proof of a wall. Do not spend analysis transcribing the grid or guessing "
    "a familiar town layout; choose an observable experiment from the supplied evidence. "
    "Check harness_frustration. If requires_new_objective is true, your previous objective has "
    "been retired. You MUST set a materially different short-term goal using the goal tool before "
    "acting. Propose a different observable experiment, not a paraphrase of the retired route. "
    "Use one action to test that idea. Repeated movement through the same positions is not progress. "
    "The harness observes state after each queued macro without another model call. "
    "recent_action_outcomes is a factual experiment log, not a route guide. A stop_reason "
    "means the listed skipped_actions were NOT executed. No displacement does not prove a wall: "
    "check facing, dialogue and timing. Goals and model-authored lessons are hypotheses unless "
    "supported by observations. In your reasoning briefly label Hypothesis, Expected observation, "
    "and Disproof before choosing the next experiment. When reconsider_hypothesis is true, "
    "explicitly revise the hypothesis rather than inventing an explanation for failure. "
    "(1) Read every saved lesson before choosing. Treat an applicable verified lesson as a constraint; "
    "do not contradict or retry it unless new evidence disproves it. "
    "(2) Compare the proposed action and route with recent_action_outcomes. Current screen, RAM, "
    "collision, and observed outcomes outrank assumptions about the familiar game layout. Never keep "
    "using a remembered map location when current evidence conflicts with it. "
    "(3) Make the short-term goal a concrete, observable experiment or checkpoint for the next few "
    "actions—not an unsupported location claim. Choose a tactic that recent outcomes have not already "
    "disproved. "
    "(4) If an input from the same state makes no progress, do not immediately repeat it. If two "
    "attempts based on the same route or landmark hypothesis fail, abandon that hypothesis: call "
    "remember_lesson with the map and the specific failed route, replace the short-term goal with a "
    "different observable experiment, and take a materially different action. Detect longer cycles, "
    "not only two-position oscillation. "
    "(5) Add concise lessons whenever verified information would prevent another repeated mistake, "
    "including failed routes, blocked approaches, character identity, landmarks, and mechanics. "
    "Remove a lesson if later evidence disproves it. Never save a guess as fact. "
    "Your reasoning is shown in a local operator dashboard."
)


OLLAMA_SYSTEM_PROMPT = (
    "Before choosing, compare immediate_options: current walkability estimate plus recorded "
    "attempts at this exact position. An open option with no attempts is an opportunity to test. "
    "Prefer a one-action test of an untried opening when other options repeat explored movement. "
    "observed_untested_openings remembers opportunities passed earlier; these are estimates, "
    "not known exits. Never explain a choice by asserting which direction a named town lies. "
    "Play Pokémon Red. First inspect the CURRENT screenshot for visible opportunities: "
    "an opening, doorway, person, item, unexplored passage, or active menu. "
    "Choose an opportunity from what is actually visible, not remembered game geography. "
    "Goals describe desired outcomes, NEVER directions, coordinates, or assumed destinations. "
    "For example: 'Investigate the visible opening; observe whether it continues' or "
    "'Find a connection to a new area'. Do not claim an opening is an exit until observed. "
    "Reconsider the opportunity on each new frame; a goal must not override new evidence. "
    "Direction words belong ONLY in the immediate controller choice, never saved goals. "
    "Choose a small experiment, briefly explain what you expect to observe, then call "
    "press_buttons exactly once. Prefer one action when uncertain; queue up to six only "
    "for a clear sequence. Never combine wait with other actions. Use wait only for an "
    "ongoing transition and battle macros only in battle.\n"
    "Observed action results outrank remembered game layouts. Adjacent tiles are estimates; "
    "turning without moving does not prove a wall. The harness checks each action and may "
    "skip the rest of a queue. Test a different approach when recent attempts repeat.\n"
    "You own the short- and medium-term goals. Set missing goals with their tools and revise "
    "them when needed. If harness_frustration.reconsider_approach is true, reconsider the route "
    "assumption, not necessarily the objective. The ultimate goal stays fixed. Memory tools are "
    "optional; save observations, not guesses.\n"
    "Goals and model-authored memories are unverified hypotheses, never evidence. "
    "Write short-term goals around a visible opportunity and an observable result. When observations conflict "
    "with a belief, choose one action that tests it. Retired goals are unsuccessful hypotheses, "
    "not map facts; memory context does not prove a memory's explanation.\n"
    "A direction's destination is unknown until observed. Open tiles do not establish an exit "
    "or where a route leads. Retain the intended objective but test any unsupported geography. "
    "Use exploration_memory to avoid repeating experiments; missing entries mean unknown, not blocked.\n"
    "The current image and state share a capture frame. Historical images show past states. "
    "Use battle_state_changed and party_hp_changed to assess battle effects. screen_changed "
    "only reports pixel changes, which may be idle animation; it does not prove progress.\n"
    "Keep the explanation under 120 words. Do not transcribe the grid or recount every "
    "possibility. When unsure, choose one informative action and observe its result."
)


@dataclass(frozen=True)
class ModelDecision:
    choice: str | None
    probabilities: dict[str, float]
    unknown_probability: float
    abstained: bool
    latency_ms: float
    raw: dict[str, Any]
    reasoning: str = ""
    mode: str = "choice"
    model: str = ""
    short_term_goal_update: str | None = None
    medium_term_goal_update: str | None = None
    queued_choices: tuple[str, ...] = ()
    lessons_to_remember: tuple[str, ...] = ()
    lesson_ids_to_forget: tuple[int, ...] = ()

    @property
    def action_queue(self) -> tuple[str, ...]:
        if self.queued_choices:
            return self.queued_choices
        return (self.choice,) if self.choice else ()

    @property
    def confidence(self) -> float:
        if not self.choice:
            return 0.0
        return float(self.probabilities.get(self.choice, 0.0))


class ModelClient(Protocol):
    backend: str
    model_name: str

    async def health(self) -> dict[str, Any]: ...

    async def decide(
        self,
        *,
        screenshot: bytes,
        game_state: dict[str, Any],
        ultimate_goal: str,
        short_term_goal: str | None,
        medium_term_goal: str | None,
        lessons: list[dict[str, Any]],
        recent_actions: list[str],
        recent_outcomes: list[dict[str, Any]] | None = None,
        past_frames: list[bytes] | None = None,
    ) -> ModelDecision: ...


class PokemonClient:
    def __init__(self, base_url: str, client: httpx.AsyncClient):
        self.base_url = base_url.rstrip("/")
        self.client = client

    async def health(self) -> dict[str, Any]:
        response = await self.client.get(f"{self.base_url}/health")
        response.raise_for_status()
        return response.json()

    async def state(self) -> dict[str, Any]:
        response = await self.client.get(f"{self.base_url}/state")
        response.raise_for_status()
        return response.json()

    async def screenshot(self) -> bytes:
        response = await self.client.get(f"{self.base_url}/screenshot")
        response.raise_for_status()
        return response.content

    async def observe(self) -> tuple[dict[str, Any], bytes]:
        response = await self.client.get(f"{self.base_url}/observation")
        response.raise_for_status()
        payload = response.json()
        return payload["state"], base64.b64decode(payload["screenshot"], validate=True)

    async def act(self, actions: tuple[str, ...] | list[str]) -> dict[str, Any]:
        response = await self.client.post(
            f"{self.base_url}/action", json={"actions": list(actions)}
        )
        response.raise_for_status()
        return response.json()

    async def save(self, name: str) -> dict[str, Any]:
        response = await self.client.post(f"{self.base_url}/save", json={"name": name})
        response.raise_for_status()
        return response.json()


class ImajevClient:
    backend = "imajev"

    def __init__(self, base_url: str, client: httpx.AsyncClient, model_name: str = "imajev-4b"):
        self.base_url = base_url.rstrip("/")
        self.client = client
        self.model_name = model_name

    async def health(self) -> dict[str, Any]:
        response = await self.client.get(f"{self.base_url}/v1/models", timeout=3.0)
        response.raise_for_status()
        return response.json()

    async def decide(
        self,
        *,
        screenshot: bytes,
        game_state: dict[str, Any],
        ultimate_goal: str,
        short_term_goal: str | None,
        medium_term_goal: str | None,
        lessons: list[dict[str, Any]],
        recent_actions: list[str],
        recent_outcomes: list[dict[str, Any]] | None = None,
        past_frames: list[bytes] | None = None,
    ) -> ModelDecision:
        history_frames = (past_frames or [])[-4:]
        request = {
            "state": {
                "goals": {
                    "ultimate": ultimate_goal,
                    "medium_term": medium_term_goal,
                    "short_term": short_term_goal,
                },
                "model_lessons_newest_first": lessons,
                "current_game_state": compact_state(game_state),
                "recent_controller_inputs": recent_actions[-12:],
                "recent_action_outcomes": compact_outcomes(recent_outcomes or []),
                "visual_history": {
                    "reference_image": (
                        "A contact sheet of previous game frames, oldest to newest, labeled T-n."
                        if history_frames
                        else "Not available yet."
                    ),
                    "target_image": "The second image is the authoritative current frame.",
                    "past_frame_count": len(history_frames),
                },
            },
            "questions": {
                "next_action": {
                    "type": "choice",
                    "instructions": (
                        "Choose the single safest controller macro that most directly advances the "
                        "model-owned short-term goal, medium-term goal, and ultimate goal from the "
                        "CURRENT screenshot and state. The screenshot is authoritative "
                        "before a save file exists: choose confirm on the Pokemon title screen, intro, "
                        "New Game menu, and whenever text is waiting. Use wait only once for a non-looping "
                        "transition; never repeat wait on a title animation or unchanged screen. Use "
                        "battle-only macros only in battle and one-tile movement when navigating. Avoid "
                        "repeating an input whose recorded outcome made no progress. Treat alternating "
                        "between the same two positions as a loop and choose a different direction."
                    ),
                    "criteria": criteria(),
                }
            },
        }
        started = time.perf_counter()
        files: list[tuple[str, tuple[str, bytes, str]]] = []
        if history_frames:
            files.append(
                ("image", ("history.png", build_frame_history(history_frames), "image/png"))
            )
        files.append(("image", ("current.png", screenshot, "image/png")))
        response = await self.client.post(
            f"{self.base_url}/v1/systemone",
            files=files,
            data={"request": json.dumps(request, separators=(",", ":"))},
            timeout=120.0,
        )
        response.raise_for_status()
        payload = response.json()
        answer = payload.get("answers", {}).get("next_action", {})
        elapsed = (time.perf_counter() - started) * 1000
        return ModelDecision(
            choice=answer.get("choice"),
            probabilities={
                str(key): float(value) for key, value in answer.get("probabilities", {}).items()
            },
            unknown_probability=float(answer.get("unknown_probability", 0.0)),
            abstained=bool(answer.get("abstained", False)),
            latency_ms=float(payload.get("usage", {}).get("total_ms", elapsed)),
            raw=payload,
            model=self.model_name,
        )


class OllamaClient:
    """Current-frame controller with constrained action-first JSON responses."""

    backend = "ollama"

    def __init__(self, base_url: str, client: httpx.AsyncClient, model_name: str):
        self.base_url = base_url.rstrip("/")
        self.client = client
        self.model_name = model_name

    async def health(self) -> dict[str, Any]:
        response = await self.client.post(
            f"{self.base_url}/api/show", json={"model": self.model_name}, timeout=5.0
        )
        response.raise_for_status()
        payload = response.json()
        capabilities = set(payload.get("capabilities", []))
        missing = {"vision", "tools"} - capabilities
        if missing:
            raise RuntimeError(
                f"{self.model_name} is missing required capabilities: {', '.join(sorted(missing))}"
            )
        return payload

    async def decide(
        self,
        *,
        screenshot: bytes,
        game_state: dict[str, Any],
        ultimate_goal: str,
        short_term_goal: str | None,
        medium_term_goal: str | None,
        lessons: list[dict[str, Any]],
        recent_actions: list[str],
        recent_outcomes: list[dict[str, Any]] | None = None,
        past_frames: list[bytes] | None = None,
    ) -> ModelDecision:
        unavailable_actions = _unavailable_actions(recent_outcomes or [])
        allowed = [name for name in criteria() if name not in unavailable_actions]
        navigation = game_state.get("navigation") or {}
        routes = {item["id"]: item for item in navigation.get("options", [])
                  if item.get("first_action") in allowed}
        if navigation.get("loop_detected") and routes:
            allowed = [name for name in allowed if name not in {"up", "down", "left", "right", "wait"}]
        action_descriptions = {name: criteria()[name] for name in allowed}
        action_descriptions.update({name: f"Route toward {item['position']} then test {item['test_direction']}; {item['steps']} steps total, execute one step now."
                                    for name, item in routes.items()})
        allowed = list(action_descriptions)
        context = {
            "current_game_state": compact_state(game_state),
            "goals": {
                "ultimate": ultimate_goal, "medium_term": medium_term_goal,
                "short_term": short_term_goal,
                "epistemic_status": "Proposed objectives, not observed facts.",
            },
            "model_lessons_newest_first": [
                {"id": item.get("id"), "lesson": str(item.get("lesson", ""))[:300],
                 "source": "model", "verification": "unverified"} for item in lessons
            ],
            "harness_frustration": hypothesis_context(game_state.get("harness_frustration", {})),
            "exploration_memory": game_state.get("exploration_memory", {}),
            "attempts_from_current_position": local_attempts(game_state, recent_outcomes or []),
            "recent_action_outcomes": compact_outcomes((recent_outcomes or [])[-6:]),
            "allowed_actions": action_descriptions,
            "navigation": navigation,
            "image_order": "One image only: the authoritative current frame, captured with this state.",
        }
        context = bounded_action_context(context)
        schema = {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": allowed},
                "explanation": {"type": "string", "maxLength": 240},
                "short_term_goal": {"type": "string", "maxLength": MAX_SHORT_TERM_GOAL_LENGTH},
                "medium_term_goal": {"type": "string", "maxLength": MAX_MEDIUM_TERM_GOAL_LENGTH},
                "remember_lesson": {"type": "string", "maxLength": MAX_LESSON_LENGTH},
                "forget_lesson_id": {
                    "type": "integer",
                    "enum": [item["id"] for item in lessons if isinstance(item.get("id"), int)] or [-1],
                },
            },
            "required": ["action", "explanation"],
            "additionalProperties": False,
        }
        # A single self-contained user message keeps image, instructions and state
        # together even when a model renderer mishandles consecutive user messages.
        instruction = (
            "Play Pokemon Red. Return only JSON matching the schema. Write action FIRST: "
            "choose exactly one allowed controller action using the CURRENT image and state. "
            "Prefer a navigate_N option to investigate an unexplored opening: the pathfinder executes its first step, then replans. "
            "When loop_detected is true, choose a navigation option instead of repeating the failed route, unless dialogue or interaction is needed. "
            "Then give one brief explanation (at most 240 characters), stating the observable "
            "effect you intend to test. Do not write a reasoning essay. "
            "Current observations outrank goals, lessons and remembered geography. "
            "Do not invent sign text, names or landmarks; unreadable text is unknown. "
            "Do not describe previous frames as current. Adjacent tiles are estimates; "
            "no displacement alone does not prove a wall. Prefer an untried visible opening "
            "when recent actions repeat. Use confirm for waiting dialog, battle actions only "
            "in battle, and wait only for an ongoing transition. "
            "Optionally update your goals or memory after the action and explanation. "
            "Goals must describe observable outcomes without directions or coordinates. "
            "Saved lessons are unverified; do not turn a guess into a fact.\n\n"
        )
        request = {
            "model": self.model_name,
            "messages": [{
                "role": "user",
                "content": instruction + json.dumps(context, separators=(",", ":")),
                "images": [_base64_image(screenshot)],
            }],
            "format": schema,
            "think": False,
            "stream": False,
            "options": {"temperature": 0.0, "num_predict": 384},
        }
        started = time.perf_counter()
        response = await self.client.post(
            f"{self.base_url}/api/chat", json=request, timeout=180.0
        )
        # Tokenization varies by model. Retry a context overflow once with only
        # current evidence, rather than repeating the same oversized request.
        if response.status_code == 400 and "exceeds" in response.text and "context" in response.text:
            minimal = {key: value for key, value in context.items() if key in {
                "current_game_state", "goals", "allowed_actions", "image_order",
            }}
            request["messages"][0]["content"] = instruction + json.dumps(minimal, separators=(",", ":"))
            response = await self.client.post(
                f"{self.base_url}/api/chat", json=request, timeout=180.0
            )
        response.raise_for_status()
        payload = response.json()
        message = payload.get("message") or {}
        try:
            answer = json.loads(message.get("content") or "")
        except (TypeError, ValueError):
            answer = {}
        if not isinstance(answer, dict):
            answer = {}
        choice = answer.get("action")
        if not isinstance(choice, str) or choice not in allowed or payload.get("done_reason") == "length":
            choice = None

        def bounded_text(name: str, limit: int) -> str | None:
            value = answer.get(name)
            if not choice or not isinstance(value, str):
                return None
            return " ".join(value.split())[:limit] or None

        explanation = bounded_text("explanation", 240)
        if not explanation:
            choice = None
        lesson = bounded_text("remember_lesson", MAX_LESSON_LENGTH)
        forget_id = answer.get("forget_lesson_id")
        known_ids = {item.get("id") for item in lessons}
        payload["decision_diagnostics"] = {
            "prompt_profile": "current-frame-action-first-v1",
            "analysis_finish_reason": payload.get("done_reason", "unknown"),
            "analysis_tokens": payload.get("eval_count"),
            "analysis_limit_reached": payload.get("done_reason") == "length",
            "recovery_used": False,
            "action_valid": choice is not None,
            "image_count": 1,
            "capture": game_state.get("capture"),
        }
        elapsed = (time.perf_counter() - started) * 1000
        if choice in routes:
            payload["decision_diagnostics"]["navigation_target"] = routes[choice]
            choice = routes[choice]["first_action"]
        return ModelDecision(
            choice=choice, probabilities={}, unknown_probability=0.0,
            abstained=choice is None,
            latency_ms=float(payload.get("total_duration") or 0) / 1_000_000 or elapsed,
            raw=payload,
            reasoning=explanation if choice else "No valid structured action was returned.",
            mode="action_first_json",
            model=str(payload.get("model") or self.model_name),
            short_term_goal_update=bounded_text("short_term_goal", MAX_SHORT_TERM_GOAL_LENGTH),
            medium_term_goal_update=bounded_text("medium_term_goal", MAX_MEDIUM_TERM_GOAL_LENGTH),
            queued_choices=(choice,) if choice else (),
            lessons_to_remember=(lesson,) if lesson else (),
            lesson_ids_to_forget=(forget_id,) if choice and type(forget_id) is int and forget_id in known_ids else (),
        )


def build_model_client(
    backend: str, base_url: str, client: httpx.AsyncClient, model_name: str
) -> ModelClient:
    if backend == "llama-score":
        from .token_scoring import TokenScoringClient
        return TokenScoringClient(base_url, client, model_name)
    if backend == "imajev":
        return ImajevClient(base_url, client, model_name)
    if backend == "ollama":
        return OllamaClient(base_url, client, model_name)
    raise ValueError(f"Unsupported model backend: {backend}")


def _base64_image(image: bytes) -> str:
    return base64.b64encode(image).decode("ascii")


def _tool_results(
    tool_calls: Any,
    *,
    allowed_actions: set[str] | None = None,
    known_lesson_ids: set[int] | None = None,
) -> tuple[tuple[str, ...], str | None, str | None, tuple[str, ...], tuple[int, ...]]:
    if not isinstance(tool_calls, list):
        return (), None, None, (), ()
    choices: tuple[str, ...] = ()
    short_goal_update: str | None = None
    medium_goal_update: str | None = None
    lessons_to_remember: list[str] = []
    lesson_ids_to_forget: list[int] = []
    for call in tool_calls:
        if not isinstance(call, dict):
            continue
        function = call.get("function")
        if not isinstance(function, dict):
            continue
        arguments = function.get("arguments")
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError:
                continue
        if not isinstance(arguments, dict):
            continue
        valid_actions = allowed_actions if allowed_actions is not None else set(criteria())
        if function.get("name") == "press_buttons" and not choices:
            requested = arguments.get("actions")
            # Accept the old singular shape during upgrades and from less reliable models.
            if requested is None and "action" in arguments:
                requested = [arguments["action"]]
            if (
                isinstance(requested, list)
                and 1 <= len(requested) <= MAX_QUEUED_ACTIONS
                and all(isinstance(action, str) and action in valid_actions for action in requested)
                and not (len(requested) > 1 and "wait" in requested)
            ):
                choices = tuple(requested)
        if function.get("name") == "set_short_term_goal" and isinstance(
            arguments.get("goal"), str
        ):
            cleaned = " ".join(arguments["goal"].split())[:MAX_SHORT_TERM_GOAL_LENGTH]
            short_goal_update = cleaned or short_goal_update
        if function.get("name") == "set_medium_term_goal" and isinstance(
            arguments.get("goal"), str
        ):
            cleaned = " ".join(arguments["goal"].split())[:MAX_MEDIUM_TERM_GOAL_LENGTH]
            medium_goal_update = cleaned or medium_goal_update
        if (
            function.get("name") == "remember_lesson"
            and isinstance(arguments.get("lesson"), str)
            and len(lessons_to_remember) < MAX_LESSON_UPDATES_PER_TURN
        ):
            cleaned = " ".join(arguments["lesson"].split())[:MAX_LESSON_LENGTH]
            if cleaned and cleaned.casefold() not in {
                lesson.casefold() for lesson in lessons_to_remember
            }:
                lessons_to_remember.append(cleaned)
        if (
            function.get("name") == "forget_lesson"
            and isinstance(arguments.get("id"), int)
            and arguments["id"] in (known_lesson_ids or set())
            and len(lesson_ids_to_forget) < MAX_LESSON_UPDATES_PER_TURN
        ):
            lesson_id = int(arguments["id"])
            if lesson_id not in lesson_ids_to_forget:
                lesson_ids_to_forget.append(lesson_id)
    return (
        choices,
        short_goal_update,
        medium_goal_update,
        tuple(lessons_to_remember),
        tuple(lesson_ids_to_forget),
    )


def _unavailable_actions(recent_outcomes: list[dict[str, Any]]) -> set[str]:
    if not recent_outcomes:
        return set()
    latest = recent_outcomes[-1]
    action = latest.get("action")
    if action == "wait" and not latest.get("made_navigation_progress"):
        return {"wait"}
    if action in {"up", "down", "left", "right"} and not (
        latest.get("position_changed") or latest.get("map_changed")
    ):
        before, after = latest.get("before", {}), latest.get("after", {})
        if before.get("facing") and after.get("facing") and before["facing"] != after["facing"]:
            return set()
        return {str(action)}
    return set()


def build_frame_history(frames: list[bytes], max_frames: int = 4) -> bytes:
    """Build a compact, chronological 2x2 reference image from recent frames."""
    selected = frames[-max_frames:]
    if not selected:
        raise ValueError("at least one past frame is required")
    decoded: list[Image.Image] = []
    for frame in selected:
        with Image.open(BytesIO(frame)) as image:
            decoded.append(image.convert("RGB"))

    frame_width = max(image.width for image in decoded)
    frame_height = max(image.height for image in decoded)
    label_height = 14
    columns = 2
    rows = (len(decoded) + columns - 1) // columns
    sheet = Image.new("RGB", (columns * frame_width, rows * (frame_height + label_height)), "white")
    draw = ImageDraw.Draw(sheet)
    count = len(decoded)
    for index, image in enumerate(decoded):
        x = (index % columns) * frame_width
        y = (index // columns) * (frame_height + label_height)
        draw.text((x + 3, y + 2), f"T-{count - index}", fill="black")
        sheet.paste(image, (x, y + label_height))

    output = BytesIO()
    sheet.save(output, format="PNG", optimize=True)
    return output.getvalue()


def hypothesis_context(frustration: dict[str, Any]) -> dict[str, Any]:
    context = {key: value for key, value in frustration.items() if key != "retired_objective"}
    if frustration.get("requires_new_objective"):
        context["unsuccessful_hypothesis"] = {
            "claim": "Withheld to avoid repeating an unsupported route assumption.",
            "status": "Unsuccessful approach; neither verified nor proven impossible.",
        }
    return context


def adjacent_tiles(collision: dict[str, Any]) -> dict[str, Any]:
    """Summarize only the supplied collision crop; unknown cells remain unknown."""
    directions = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}
    result = {name: "unknown" for name in directions}
    cell = collision.get("player_cell")
    grid = collision.get("walkable")
    if not isinstance(cell, str) or not isinstance(grid, list):
        return result
    if len(cell) < 2 or cell[0] not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" or not cell[1:].isdigit():
        return result
    row, col = int(cell[1:]) - 1, ord(cell[0]) - ord("A")
    if row < 0 or row >= len(grid) or not isinstance(grid[row], list) or col >= len(grid[row]):
        return result
    for direction, (dy, dx) in directions.items():
        y, x = row + dy, col + dx
        if 0 <= y < len(grid) and isinstance(grid[y], list) and 0 <= x < len(grid[y]):
            value = grid[y][x]
            if isinstance(value, bool):
                result[direction] = "estimated_open" if value else "estimated_blocked"
    return result


def local_attempts(state: dict[str, Any], outcomes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    position = (state.get("player") or {}).get("position")
    map_id = (state.get("map") or {}).get("map_id")
    if position is None or map_id is None:
        return []
    attempts = []
    for outcome in outcomes:
        before, after = outcome.get("before", {}), outcome.get("after", {})
        if (before.get("map_id") != map_id or before.get("position") != position
                or outcome.get("action") not in {"up", "down", "left", "right"}
                or before.get("in_battle") or after.get("in_battle")
                or before.get("dialog_active") or after.get("dialog_active")):
            continue
        if after.get("position") is None or after.get("map_id") is None:
            continue
        result = "no_displacement"
        if outcome.get("map_changed"):
            result = "map_changed"
        elif outcome.get("position_changed"):
            result = "moved"
        elif before.get("facing") != after.get("facing"):
            result = "turned_without_displacement"
        attempts.append({"action": outcome["action"], "result": result,
                         "facing_before": before.get("facing"), "turn": outcome.get("turn")})
    return attempts[-8:]


def bounded_action_context(context: dict[str, Any], max_chars: int = 12000) -> dict[str, Any]:
    """Bound historical prompt data without modifying persisted observations."""
    result = json.loads(json.dumps(context))
    memory = result.get("exploration_memory", {})
    for field in ("nearby_observed_positions", "observed_untested_openings", "observed_map_transitions"):
        collection = memory.get(field)
        while collection and len(json.dumps(result, separators=(",", ":"))) > max_chars:
            if isinstance(collection, dict):
                del collection[next(reversed(collection))]
            else:
                collection.pop()
    for field in ("recent_action_outcomes", "attempts_from_current_position", "model_lessons_newest_first"):
        collection = result.get(field, [])
        while collection and len(json.dumps(result, separators=(",", ":"))) > max_chars:
            collection.pop(0 if field != "model_lessons_newest_first" else -1)
    return result


def compact_outcomes(outcomes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Retain actionable evidence without resending full observations every turn."""
    observation_fields = (
        "map", "map_id", "position", "facing", "in_battle", "dialog_active",
    )
    outcome_fields = (
        "action", "turn", "source", "position_changed", "map_changed",
        "made_navigation_progress", "battle_state_changed", "party_hp_changed",
        "dialog_state_changed", "stop_reason", "same_state_no_displacement_count",
        "reconsider_hypothesis", "skipped_actions",
    )
    result = []
    for outcome in outcomes[-12:]:
        item = {field: outcome[field] for field in outcome_fields if field in outcome}
        for side in ("before", "after"):
            observation = outcome.get(side) or {}
            item[side] = {
                field: observation[field]
                for field in observation_fields
                if field in observation
            }
        result.append(item)
    return result


def compact_state(state: dict[str, Any]) -> dict[str, Any]:
    """Keep imajev's request focused and comfortably below its 32 KB state limit."""
    player = state.get("player") or {}
    battle = state.get("battle")
    dialog = state.get("dialog") or {}
    collision = state.get("collision") or {}
    map_state = state.get("map") or {}
    return {
        "map": {
            "id": map_state.get("map_id"),
            "name": map_state.get("map_name"),
        },
        "player": {
            "name": player.get("name"),
            "position": player.get("position"),
            "facing": player.get("facing"),
            "badges": player.get("badges"),
            "money": player.get("money"),
        },
        "party": state.get("party", []),
        "bag": state.get("bag", []),
        "battle": battle,
        "capture": state.get("capture"),
        "dialog": dialog,
        "interface": state.get("interface"),
        "interaction_feedback": state.get("interaction_feedback"),
        "flags": state.get("flags", {}),
        "player_cell": collision.get("player_cell"),
        "adjacent_tiles": adjacent_tiles(collision),
        "walkability_near_player": collision.get("ascii"),
        "walkability_note": (
            "This is a local crop centered near the player. Its row/column labels are local only and "
            "must not be equated with the global RAM x/y position. Use @ as the player cell."
        ),
        "frame": (state.get("metadata") or {}).get("frame_count"),
    }
