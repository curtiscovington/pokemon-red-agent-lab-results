"""Watch one pinned experiment, collect highlights, and stop its encoder on completion."""
from __future__ import annotations

import argparse
import fcntl
import json
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

TERMINAL = {'complete', 'failed', 'interrupted'}


def save(path: Path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def stamp(seconds):
    seconds = max(0, int(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f'{hours}:{minutes:02}:{seconds:02}' if hours else f'{minutes:02}:{seconds:02}'


def stop_due(stage, terminal_since, now, tail_seconds=30):
    return stage in TERMINAL and terminal_since is not None and now - terminal_since >= tail_seconds


class Highlights:
    def __init__(self, batch: Path):
        self.batch = batch
        self.path = batch / 'stream-watch-state.json'
        self.state = json.loads(self.path.read_text()) if self.path.exists() else {
            'offsets': {}, 'runs': {}, 'markers': [], 'experiment_start': None,
        }

    def add(self, key, label, event, confidence='observed'):
        if any(marker['key'] == key for marker in self.state['markers']):
            return
        self.state['markers'].append({
            'key': key, 'label': label, 'ts': event['ts'], 'run_id': event.get('run_id'),
            'run_elapsed': event.get('elapsed'), 'confidence': confidence,
        })

    def consume(self, event, run):
        kind = event['type']
        run_id = event.get('run_id', run['run_id'])
        label = f"Run {run['index']} ({run['policy']})"
        observed = self.state['runs'].setdefault(run_id, {'maps': [], 'badges': []})
        if kind == 'observation':
            state = event['state']
            if not observed.get('started'):
                start = event['ts'] - (event.get('elapsed') or 0)
                self.add(run_id + ':start', label + ' starts', {**event, 'ts': start, 'elapsed': 0})
                observed['started'] = True
                if self.state['experiment_start'] is None:
                    self.state['experiment_start'] = start
            map_info = state.get('map') or {}
            map_id = map_info.get('map_id')
            if map_id is not None and map_id not in observed['maps']:
                if observed['maps']:
                    self.add(run_id + f':map:{map_id}', label + ': first visit to ' +
                             str(map_info.get('map_name', map_id)), event)
                observed['maps'].append(map_id)
            party = state.get('party') or []
            if party and not observed.get('party'):
                self.add(run_id + ':party', label + ': first Pokémon observed in party', event)
                observed['party'] = True
            for badge in (state.get('player') or {}).get('badges') or []:
                if badge not in observed['badges']:
                    self.add(run_id + ':badge:' + str(badge), label + f': {badge} badge observed', event)
                    observed['badges'].append(badge)
            battle = state.get('battle') or {}
            if battle.get('in_battle') and not observed.get('battle'):
                self.add(run_id + ':battle', label + ': first battle observed', event)
                observed['battle'] = True
        elif kind == 'milestone_evidence' and event['name'].startswith('provisional_'):
            self.add(run_id + ':' + event['name'], label + ': ' + event['name'].replace('_', ' '),
                     event, confidence='unverified flag; review before publishing')
        elif kind == 'failure':
            self.add(run_id + ':failure', label + ': run failed', event)

    def scan(self):
        for folder in sorted(self.batch.iterdir()):
            manifest_path = folder / 'manifest.json'
            events_path = folder / 'events.jsonl'
            if not folder.is_dir() or not manifest_path.exists() or not events_path.exists():
                continue
            run = json.loads(manifest_path.read_text())
            run['index'] = int(folder.name.split('-')[0])
            offset = self.state['offsets'].get(folder.name, 0)
            with events_path.open('rb') as source:
                source.seek(offset)
                for line in source:
                    if not line.endswith(b'\n'):
                        break
                    event = json.loads(line)
                    self.consume(event, run)
                    offset += len(line)
            self.state['offsets'][folder.name] = offset
            summary_path = folder / 'summary.json'
            if summary_path.exists():
                summary = json.loads(summary_path.read_text())
                self.add(folder.name + ':end', f"Run {run['index']} ({run['policy']}): {summary['status']}",
                         {'ts': summary_path.stat().st_mtime, 'run_id': run['run_id'],
                          'elapsed': summary.get('elapsed_seconds')})

    def export(self):
        session_path = self.batch / 'youtube-session.json'
        session = json.loads(session_path.read_text()) if session_path.exists() else {}
        broadcast_start = session.get('actual_start_epoch')
        origin = broadcast_start or self.state['experiment_start']
        markers = sorted(self.state['markers'], key=lambda marker: marker['ts'])
        save(self.batch / 'highlights.json', {
            'broadcast_url': session.get('url'), 'actual_broadcast_start': broadcast_start,
            'experiment_start': self.state['experiment_start'], 'markers': markers,
        })
        lines = ['# Stream highlights', '',
                 'UTC and Pacific times are exact event-log times. Experiment offsets include loading between runs.',
                 'YouTube offsets require the actual broadcast start time; encoder restarts do not establish it.', '',
                 '| Pacific time | Experiment offset | YouTube offset | Moment | Evidence |',
                 '|---|---|---|---|---|']
        for marker in markers:
            local = datetime.fromtimestamp(marker['ts'], ZoneInfo('America/Los_Angeles'))
            elapsed = marker['ts'] - (self.state['experiment_start'] or marker['ts'])
            video_offset = ('Not aligned' if not broadcast_start else
                            'Before broadcast' if marker['ts'] < broadcast_start else
                            stamp(marker['ts'] - broadcast_start))
            lines.append(f"| {local:%Y-%m-%d %H:%M:%S %Z} | {stamp(elapsed)} | {video_offset} | "
                         f"{marker['label']} | {marker['confidence']} |")
        (self.batch / 'highlights.md').write_text('\n'.join(lines) + '\n')
        chapter_lines = ['00:00 Broadcast begins' if broadcast_start else '00:00 Experiment begins']
        last_offset = 0
        if origin:
            for marker in markers:
                offset = int(marker['ts'] - origin)
                if marker['confidence'] != 'observed' or offset < 0:
                    continue
                if offset - last_offset < 10:
                    chapter_lines[-1] += ' / ' + marker['label']
                else:
                    chapter_lines.append(stamp(offset) + ' ' + marker['label'])
                    last_offset = offset
        filename = 'youtube-chapters.txt' if broadcast_start else 'chapter-draft-experiment-relative.txt'
        (self.batch / filename).write_text('\n'.join(chapter_lines) + '\n')
        save(self.path, self.state)


def service_info(name):
    result = subprocess.run(['systemctl', '--user', 'show', name,
                             '-p', 'ActiveState', '-p', 'InvocationID'],
                            capture_output=True, text=True, check=True, timeout=10)
    return dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)


def run(config):
    batch = Path(config['batch'])
    highlights = Highlights(batch)
    state = highlights.state
    with (batch / 'stream-watch.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if state.get('stream_stopped'):
            return
        while True:
            now = time.time()
            highlights.scan()
            status = json.loads((batch / 'status.json').read_text())
            info = service_info('pokemon-lab.service')
            # A new experiment must never be stopped by a watcher for an old one.
            if info.get('InvocationID') != config['lab_invocation_id'] and info.get('ActiveState') == 'active':
                state['watch_status'] = 'superseded by another batch; encoder left running'
                highlights.export()
                return
            stage = status['stage']
            if info.get('ActiveState') not in {'active', 'activating'} and stage not in TERMINAL:
                state.setdefault('unavailable_since', now)
                if now - state['unavailable_since'] >= 30:
                    stage = 'interrupted'
            else:
                state.pop('unavailable_since', None)
            if stage in TERMINAL:
                state.setdefault('terminal_since', now)
                highlights.add('batch:' + stage, 'Experiment ' + stage,
                               {'ts': state['terminal_since'], 'run_id': None})
                state['watch_status'] = 'final result card; stream stops shortly'
            else:
                state.pop('terminal_since', None)
                state['watch_status'] = 'watching; encoder stops after this batch ends'
            highlights.export()
            if stop_due(stage, state.get('terminal_since'), now, config.get('tail_seconds', 30)):
                subprocess.run(['systemctl', '--user', 'stop', 'pokemon-youtube-stream.service'],
                               check=True, timeout=60)
                state['stream_stopped'] = datetime.now(UTC).isoformat()
                state['watch_status'] = 'encoder stopped; YouTube end state requires Auto-stop or API access'
                highlights.export()
                print('Experiment ended; YouTube encoder stopped.', flush=True)
                return
            time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--scan-only', action='store_true')
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    if args.scan_only:
        highlights = Highlights(Path(config['batch']))
        highlights.scan()
        highlights.export()
    else:
        run(config)


if __name__ == '__main__':
    main()
