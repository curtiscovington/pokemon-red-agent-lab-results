"""imajev plays Pokémon Red."""

__version__ = "0.1.0"

