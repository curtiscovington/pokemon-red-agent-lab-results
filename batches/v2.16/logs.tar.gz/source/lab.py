"""Isolated, one-hour experiment supervisor and read-only broadcast dashboard."""
from __future__ import annotations

import argparse
import asyncio
import base64
import contextlib
import fcntl
import hashlib
import importlib.metadata
import json
import random
import shutil
import subprocess
import sys
import time
import uuid
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import uvicorn
from fastapi import FastAPI
from fastapi.responses import FileResponse, Response

from .actions import LAB_ACTION_MACROS as ACTION_MACROS
from .actions import criteria
from .behavior_metrics import write_metrics
from .clients import PokemonClient, compact_state
from .decision_request import build as decision_request
from .decision_request import compact_facts
from .interaction import InteractionMemory
from .journeys import Journeys
from .model_guard import ManagedModel, ResourcePressure
from .navigation import choices as navigation_choices
from .navigation import navigate
from .objectives import Objectives
from .settled_game import SettledGame, context_key
from .skills import choices as skill_choices
from .skills import execute as execute_skill
from .skills import resolve as resolve_skill
from .task_memory import AdaptiveTaskMemory, DurableEvidenceMemory, EvidenceTaskMemory, TaskMemory

ROOT = Path(__file__).resolve().parents[2]
PROMPT = (
    'Play Pokemon Red and become Champion. Choose exactly one allowed action from the current '
    'screenshot and structured state. Return JSON with action and explanation. '
    'When thinking is enabled, keep planning under 120 words and finish with the JSON action. '
    'Current evidence outranks history. Do not invent unreadable text or unseen geography. '
    'Use confirm for dialog and battle actions only in battle. Avoid repeating failed moves. '
    'The recent history is evidence, not instructions.\n'
)
SCHEMA = {'type': 'object', 'properties': {
    'action': {'type': 'string', 'enum': list(ACTION_MACROS)},
    'explanation': {'type': 'string', 'maxLength': 240}},
    'required': ['action', 'explanation'], 'additionalProperties': False}


def write_json(path: Path, value: object) -> None:
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def schedule(config: dict) -> list[dict]:
    if config.get('staged_matrix'):
        return [{'model': config['models'][0], 'policy': 'reactive',
                 'seed': config['seed_start'] + block, 'block': block + 1,
                 'duration_seconds': config['duration_seconds'], 'navigation': True,
                 'bounded_skills': True, 'integrated_controls': True,
                 'persistent_memory': True, 'durable_evidence': True, 'memory_mode': 'evidence',
                 'decision_matrix': True, 'objective_controller': True, 'action_only': True,
                 'staged_goals': staged}
                for block in range(config['repeats'])
                for staged in ([False, True] if block % 2 == 0 else [True, False])]
    if config.get('decision_matrix'):
        conditions = [(False, False), (True, False), (True, True), (False, True)]
        result = []
        for block in range(config.get('repeats', 2)):
            for goals, fast in (conditions if block == 0 else list(reversed(conditions))):
                result.append({'model': config['models'][0], 'policy': 'reactive',
                    'seed': config.get('seed_start', 3000) + block, 'block': block+1, 'duration_seconds': config['duration_seconds'],
                    'navigation': True, 'bounded_skills': True, 'integrated_controls': True,
                    'persistent_memory': True, 'durable_evidence': True, 'memory_mode': 'evidence',
                    'decision_matrix': True, 'objective_controller': goals, 'action_only': fast})
        return result
    rng = random.Random(config['order_seed'])
    repeats = config['repeats']
    orders = [i % 2 for i in range(repeats)]
    rng.shuffle(orders)
    runs = []
    for block, reverse in enumerate(orders):
        policies = list(config.get('policies', ['reactive', 'deliberative']))
        if reverse:
            policies.reverse()
        models = list(config['models'])
        rng.shuffle(models)
        for model in models:
            for policy in policies:
                runs.append({'model': model, 'policy': policy, 'seed': config.get('seed_start', 1000) + block,
                             'block': block + 1, 'duration_seconds': config['duration_seconds'],
                             'navigation': config.get('navigation', False),
                             **({'bounded_skills': True} if config.get('bounded_skills') else {}),
                             **({'integrated_controls': True} if config.get('integrated_controls') else {}),
                             **({'durable_evidence': True} if config.get('durable_evidence') else {})})
    if config.get('memory_variants'):
        expanded = []
        for run in runs:
            variants = list(config['memory_variants'])
            if (run['block'] in config['reverse_blocks'] if 'reverse_blocks' in config
                    else run['block'] % 2 == 0):
                variants.reverse()
            expanded.extend({**run, 'persistent_memory': True, 'memory_mode': mode,
                             **({'reserve_notebook_bytes': 900} if config.get('reserve_notebook_bytes') else {})}
                            for mode in variants)
        return expanded
    if config.get('compare_memory'):
        expanded = []
        for run in runs:
            conditions = [False, True] if run['block'] % 2 else [True, False]
            expanded.extend({**run, 'persistent_memory': enabled} for enabled in conditions)
        return expanded
    return runs


def brief_history(history):
    # Emulator action responses include full state; never recursively feed those back.
    result = []
    for item in history[-4:]:
        before = item.get('before', {})
        outcome = item.get('outcome', {})
        result.append({'map': before.get('map'),
                       'position': before.get('player', {}).get('position'),
                       'action': item.get('action'),
                       'outcome': {key: outcome[key] for key in ('reason', 'target') if key in outcome}})
    return result


def request_for(run: dict, state: dict, screenshot: bytes, history: list, memory=None) -> dict:
    if run.get('decision_matrix'):
        return decision_request(run, state, screenshot, history, memory)
    allowed = criteria()
    if state.get('interface', {}).get('kind') != 'naming':
        allowed.pop('finish_name', None)
    else:
        allowed['finish_name'] = ACTION_MACROS['finish_name'].description
        allowed['confirm'] = 'Enter the highlighted letter; this does NOT submit the name.'
        allowed['menu'] = 'START: submit the name (same as finish_name).'
    if run.get('bounded_skills'):
        allowed.update(skill_choices(state))
        if run.get('integrated_controls') and any(k.startswith('use:') for k in allowed):
            allowed.pop('fight_first_move', None)
        if run.get('integrated_controls') and 'skill:dialogue' in allowed:
            allowed['confirm'] = allowed['skill:dialogue']
    guidance = ''
    if run.get('navigation'):
        allowed.update(navigation_choices(state))
        guidance = (' Local map assistance is available: choose a go: action to walk to an exit, '
                    'passage, person or object. Interactable targets are approached, faced, and '
                    'confirmed once. Walking stops for dialogue, battle, obstructions or map changes. '
                    'Choose destinations to advance your objective; use buttons for dialogue/menus. '
                    'Targets reveal only the current map, not where exits lead. '
                    'Read interface.controls and interaction_feedback before acting. '
                    'Poké Ball labels identify the visible sprite, not its contents. '
                    'Use finish_name on a naming keyboard; repeated A enters letters. ')
    if run.get('memory_mode') == 'journey':
        allowed.update(state.get('journey_actions', {}))
    context = {'state': compact_state(state), 'recent_history': brief_history(history),
               'allowed_actions': allowed}
    if run.get('memory_mode') == 'journey':
        context['journey'] = state.get('journey', {})
    # Preserve current evidence first. UTF-8 bytes are a conservative text-token bound;
    # leave room for the image, schema/template and up to 1024 generated tokens.
    prefix = PROMPT + guidance
    if run.get('persistent_memory'):
        context['notebook'] = memory or {}
        prefix += (' Your notebook persists within this run. Optionally return objective and note '
                   '(each <=160 characters) to replace them. Record encountered facts and a local goal, '
                   'not assumed outcomes. Model notes may be mistaken; current evidence takes priority. ')
    adaptive = run.get('persistent_memory') and run.get('memory_mode') in ('adaptive', 'evidence', 'journey')
    if adaptive:
        prefix += (' Return next_step, success_check, blocker and status (each <=80 characters). '
                   'Choose one concrete local step. State observable evidence that would complete it. '
                   'On each turn compare current evidence with that check; status is active, blocked, '
                   'or complete, and is your assessment, not verified fact. Never claim completion '
                   'from an issued action alone. If notebook.reconsider is true, repeated attempts '
                   'at unchanged evidence need review: name the blocker and choose a different '
                   'approach or explain why repetition is necessary. Revise stale goals. ')
    if run.get('integrated_controls') and run.get('memory_mode') == 'journey':
        prefix += (' Return destination: local for local actions, a listed map ID to travel there, '
                   'resume after resolving interruptions, or cancel to clear the retained goal. '
                   'A travel destination overrides action; choose local during battle/dialogue. ')
    if run.get('durable_evidence'):
        prefix += (' Persistent evidence records observed routes and dialogue; task_text_unverified '
                   'is an encountered instruction, not verified completion. Inventory_now is current. '
                   'Do not invent map IDs. Repeatedly observed exits to houses cannot become a route '
                   'to a different map without new evidence. Resolve unmet instructions before repeating exploration. ')
    def encode():
        return prefix + json.dumps(context, separators=(',', ':'), ensure_ascii=False)
    def prompt_size():
        reserve = run.get('reserve_notebook_bytes', 0) if run.get('persistent_memory') else 0
        notebook_size = len(json.dumps(context.get('notebook', {}), separators=(',', ':'), ensure_ascii=False).encode())
        return len(encode().encode()) + max(0, reserve - notebook_size)
    while prompt_size() > 6000 and context['recent_history']:
        context['recent_history'].pop(0)
    if prompt_size() > 6000:
        context['state'].pop('walkability_near_player', None)
    if prompt_size() > 6000:
        context['state'] = compact_facts(state)
        context['allowed_actions'] = list(allowed)
        prefix = ('Play Pokemon Red. Return the required JSON. Follow current evidence; notes may be wrong. '
                  'go: navigates locally; travel: follows observed connections; use: selects a move. '
                  'Respect interface controls. Do not invent destinations. ')
    if prompt_size() > 6000:
        raise ValueError('Observation exceeds the safe prompt budget; refusing oversized request')
    content = encode()
    schema = {**SCHEMA, 'properties': {**SCHEMA['properties'],
              'action': {'type': 'string', 'enum': list(allowed)}}}
    if run.get('persistent_memory'):
        schema['properties'].update({key: {'type': 'string', 'maxLength': 160}
                                     for key in ('objective', 'note')})
    if run.get('integrated_controls') and run.get('memory_mode') == 'journey':
        destinations = ['local'] + [k.split(':')[1] for k in allowed if k.startswith('travel:')]
        if 'cancel_journey' in allowed:
            destinations.append('cancel')
        if 'resume_journey' in allowed:
            destinations.append('resume')
        schema['properties']['destination'] = {'type': 'string', 'enum': destinations}
        schema['required'] = [*schema['required'], 'destination']
    if adaptive:
        schema['properties'].update({key: {'type': 'string', 'maxLength': 80}
                                     for key in ('next_step', 'success_check', 'blocker')})
        schema['properties']['status'] = {'type': 'string', 'enum': ['active', 'blocked', 'complete']}
        schema['required'] = [*schema['required'], 'next_step', 'success_check', 'blocker', 'status']
    return {'model': run['model'], 'stream': False, 'think': run['policy'] == 'deliberative',
            'keep_alive': -1, 'format': schema,
            'options': {'temperature': 0.2, 'seed': run['seed'], 'num_ctx': 8192,
                        'num_predict': 1024 if run['policy'] == 'deliberative' else 384},
            'messages': [{'role': 'user', 'images': [base64.b64encode(screenshot).decode()],
                          'content': content}]}


def parse_action(payload: dict, allowed=None, action_only=False) -> str | None:
    if payload.get('done_reason') == 'length':
        return None
    try:
        answer = json.loads((payload.get('message') or {}).get('content', ''))
    except (TypeError, ValueError):
        return None
    if not isinstance(answer, dict):
        return None
    action = answer.get('action')
    if (isinstance(action, str) and action in (allowed if allowed is not None else ACTION_MACROS)
            and (action_only or (isinstance(answer.get('explanation'), str) and answer['explanation'].strip()))):
        return action
    return None


def evidence(state: dict) -> dict:
    # The vendor's story flags have not been independently validated for this ROM.
    flags = state.get('flags') or {}
    bag = state.get('bag') or []
    return {'party_observed': bool(state.get('party')),
            'badges_observed': (state.get('player') or {}).get('badges', []),
            'provisional_has_pokedex': flags.get('has_pokedex'),
            'provisional_has_parcel': flags.get('has_oaks_parcel'), 'bag': bag}


class Lab:
    def __init__(self, config: dict, output: Path, *, resume_after: int = 0):
        self.config = config
        self.output = output
        self.queue = schedule(config)
        if config.get('purpose') == 'rehearsal':
            self.queue = self.queue[:2]
            self.queue[0]['duration_seconds'] = 900
            self.queue[1]['duration_seconds'] = 60
        self.status = {'batch_id': output.name, 'stage': 'queued', 'runs': self.queue, 'results': [], 'current': None,
                       'purpose': config.get('purpose', 'comparison')}
        self.resume_after = resume_after
        if resume_after:
            previous = json.loads((output / 'status.json').read_text())
            original = json.loads((output / 'manifest.json').read_text())
            results = previous['results']
            if (len(results) != resume_after or resume_after >= len(original['queue'])
                    or any(result['status'] != 'completed' for result in results)):
                raise ValueError('Resume requires exactly the requested completed runs')
            self.queue = original['queue']
            self.status.update(runs=self.queue, results=results,
                               interrupted_attempts=previous.get('interrupted_attempts', []), protocol_changes=[{
                'first_run': resume_after + 1, 'protocol': 'lab-v2.6-persistent-memory-comparison',
                'reason': 'User requested ledge-aware auto-walk for the remaining runs',
            }])
        self.frame = (ROOT / 'experiments/post_intro.png').read_bytes()
        self.stop = asyncio.Event()
        self.process = None
        self.model_url = config['model_url'].rstrip('/')
        self.game_url = f"http://127.0.0.1:{config['emulator_port']}"
        self.lock = None
        self.owns_model = False
        self.managed_model = None

    def update(self, **values):
        self.status.update(values)
        write_json(self.output / 'status.json', self.status)

    async def post(self, url: str, body: dict, timeout: float = 30):
        response = await self.http.post(url, json=body, timeout=timeout)
        response.raise_for_status()
        return response.json()

    async def unload(self):
        self.update(stage='unloading')
        if self.managed_model:
            await self.managed_model.stop()
            return
        response = await self.http.get(self.model_url + '/api/ps')
        response.raise_for_status()
        for model in response.json().get('models', []):
            await self.post(self.model_url + '/api/generate',
                            {'model': model['name'], 'keep_alive': 0}, timeout=120)
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            response = await self.http.get(self.model_url + '/api/ps')
            response.raise_for_status()
            if not response.json().get('models'):
                return
            await asyncio.sleep(1)
        raise RuntimeError('Model memory was not released; refusing to load another model')

    async def start_emulator(self):
        data = self.output / 'emulator'
        (data / 'saves').mkdir(parents=True, exist_ok=True)
        shutil.copyfile(self.config['start_state'], data / 'saves/initial.state')
        # A private ROM copy also isolates cartridge battery save writes.
        shutil.copyfile(self.config['rom'], data / 'red.gb')
        log_name = f'emulator-after-{self.resume_after:02}.log' if self.resume_after else 'emulator.log'
        self.emulator_log = (self.output / log_name).open('w')
        self.process = await asyncio.to_thread(subprocess.Popen, [
            sys.executable, '-m', 'imajev_player.emulator_server', '--rom', str(data / 'red.gb'),
            '--data-dir', str(data), '--port', str(self.config['emulator_port']),
            '--load-state', 'initial'], stdout=self.emulator_log, stderr=subprocess.STDOUT)
        for _ in range(60):
            if self.process.poll() is not None:
                raise RuntimeError('Lab emulator exited; inspect emulator.log')
            try:
                await self.game.health()
                # Explicit load fails loudly if the startup loader silently fell back to boot.
                await self.post(self.game_url + '/load', {'name': 'initial'})
                return
            except httpx.HTTPError:
                await asyncio.sleep(0.5)
        raise RuntimeError('Lab emulator startup timeout')

    async def run_one(self, run: dict, index: int):
        run_id = f"{index + 1:02d}-{run['policy']}-{uuid.uuid4().hex[:8]}"
        folder = self.output / run_id
        folder.mkdir()
        (folder / 'frames').mkdir()
        write_json(folder / 'manifest.json', {**run, 'run_id': run_id,
                                            'start_sha256': digest(Path(self.config['start_state']))})
        self.update(stage='loading', current={**run, 'run_id': run_id, 'index': index + 1},
                    deadline=None, latest_action=None, milestones={}, error=None, actions=0, recoveries=0, navigation=None)
        summary = {**run, 'run_id': run_id, 'status': 'load_failed', 'actions': 0,
                   'controller_inputs': 0, 'navigation_actions': 0, 'navigation_requests': 0,
                   'zero_input_navigation': 0, 'stale_actions': 0, 'attempts': 0, 'invalid': 0, 'valid_responses': 0, 'errors': 0,
                   'input_tokens': 0, 'output_tokens': 0, 'milestones': {}}
        input_count_at_start = getattr(self.game, 'inputs_sent', 0)
        started = None
        latencies = []
        history = deque(maxlen=4)
        interaction_memory = InteractionMemory()
        notebook = (DurableEvidenceMemory() if run.get('durable_evidence') else EvidenceTaskMemory() if run.get('memory_mode') in ('evidence', 'journey') else
                    AdaptiveTaskMemory() if run.get('memory_mode') == 'adaptive' else TaskMemory())
        journeys = Journeys()
        objectives = Objectives(staged=run.get('staged_goals', False))
        positions = set()
        same_position = 0
        previous_position = None
        first_frame = None
        load_started = time.monotonic()
        with (folder / 'events.jsonl').open('a', buffering=1) as events:
            def log(kind, **values):
                if kind == 'navigation_step':
                    positions.add(json.dumps([values.get('map'), values.get('position')], sort_keys=True))
                events.write(json.dumps({'type': kind, 'run_id': run_id, 'ts': time.time(),
                                         'elapsed': time.monotonic() - started if started else None,
                                         **values}) + '\n')

            def record_state(state, capture):
                observed = evidence(state)
                for name, value in observed.items():
                    if name == 'bag':
                        continue
                    if value and name not in summary['milestones']:
                        summary['milestones'][name] = {'elapsed': time.monotonic() - started,
                                                       'value': value, 'capture': capture}
                        log('milestone_evidence', name=name, value=value, capture=capture)
                position = json.dumps([state.get('map'), (state.get('player') or {}).get('position')],
                                      sort_keys=True)
                positions.add(position)
                return position

            try:
                await self.post(self.game_url + '/load', {'name': 'initial'})
                state, screen = await self.game.observe()
                # Same fixed warmup for both policies, no game input, outside the clock.
                warmup = request_for({**run, 'policy': 'reactive', 'persistent_memory': False, 'decision_matrix': False}, state, screen, [])
                # This backend crashes on a short first multimodal prefill after cold load.
                # A fixed larger prefill initializes it reliably; never sent during play.
                warmup['messages'][0]['content'] += (
                    '\nIgnore this initialization padding: ' + 'calibration ' * 2000
                )
                log('warmup_request', request=warmup)
                if self.managed_model:
                    self.managed_model.begin_run(run_id, warmup)
                    warm = await self.managed_model.request(
                        warmup, deadline=time.monotonic() + 600, is_warmup=True, event_log=log)
                else:
                    warm = await self.post(self.model_url + '/api/chat', warmup, timeout=600)
                log('warmup_response', response=warm)
                summary['load_warmup_seconds'] = time.monotonic() - load_started
                await self.post(self.game_url + '/load', {'name': 'initial'})
                await self.game.save(run_id + '-initial')
                shutil.copyfile(self.output / 'emulator/saves' / (run_id + '-initial.state'),
                                folder / 'initial.state')
                started = time.monotonic()
                deadline = started + run['duration_seconds']
                self.game.deadline = deadline
                self.update(stage='observing', deadline=time.time() + run['duration_seconds'])
                summary['status'] = 'running'
                consecutive_errors = 0
                while time.monotonic() < deadline and not self.stop.is_set():
                    try:
                        state, screen = await asyncio.wait_for(
                            self.game.observe(), timeout=max(0.001, deadline - time.monotonic()))
                        if time.monotonic() >= deadline:
                            break
                        frame = (state.get('capture') or {}).get('frame')
                        if isinstance(frame, int):
                            if first_frame is None:
                                first_frame = frame
                            summary['observed_emulated_frames'] = frame - first_frame
                        capture = f"frames/{summary['attempts']:06d}.png"
                        (folder / capture).write_bytes(screen)
                        self.frame = screen
                        position = record_state(state, capture)
                        same_position = same_position + 1 if position == previous_position else 0
                        previous_position = position
                        summary['max_same_position_observations'] = max(
                            same_position, summary.get('max_same_position_observations', 0))
                        state['interaction_feedback'] = interaction_memory.observe(state)
                        notebook.observe(state)
                        if run.get('decision_matrix'):
                            state['verified_objective'] = objectives.observe(state)
                        if run.get('memory_mode') == 'journey':
                            state['journey'] = journeys.context(state)
                            state['journey_actions'] = journeys.choices(state)
                        log('observation', state=state, capture=capture)
                        request = request_for(run, state, screen, list(history),
                                              notebook.snapshot() if run.get('persistent_memory') else None)
                        log('request', request=request)
                        summary['attempts'] += 1
                        self.update(stage='thinking', last_observation=time.time(),
                                    milestones=summary['milestones'], actions=summary['actions'])
                        then = time.monotonic()
                        payload = await asyncio.wait_for(
                            (self.managed_model.request(request, deadline=deadline, event_log=log)
                             if self.managed_model else
                             self.post(self.model_url + '/api/chat', request, timeout=180)),
                            timeout=max(0.001, deadline - time.monotonic()))
                        latency = time.monotonic() - then
                        latencies.append(latency)
                        log('response', response=payload, latency_seconds=latency)
                        summary['input_tokens'] += payload.get('prompt_eval_count') or 0
                        summary['output_tokens'] += payload.get('eval_count') or 0
                        action = parse_action(payload, request['format']['properties']['action']['enum'], run.get('action_only', False))
                        consecutive_errors = 0
                        if action is None:
                            summary['invalid'] += 1
                            self.update(stage='invalid_response')
                            await asyncio.sleep(min(2, max(0, deadline - time.monotonic())))
                            continue
                        summary['valid_responses'] += 1
                        # Deadline/stop gate is checked after inference and before EVERY input.
                        if not can_act(deadline, self.stop.is_set()):
                            log('late_response_ignored')
                            break
                        fresh, _ = await asyncio.wait_for(
                            self.game.observe(), timeout=max(.001, deadline-time.monotonic()))
                        if context_key(fresh) != context_key(state):
                            summary['stale_actions'] += 1
                            log('stale_action_discarded', action=action,
                                observed_context=context_key(state), current_context=context_key(fresh))
                            continue
                        if not can_act(deadline, self.stop.is_set()):
                            break
                        if run.get('integrated_controls') and run.get('memory_mode') == 'journey':
                            destination = json.loads(payload['message']['content']).get('destination')
                            if destination in ('resume', 'cancel'):
                                action = destination + '_journey'
                            elif destination and destination != 'local':
                                action = 'travel:' + str(destination)
                            if action not in request['format']['properties']['action']['enum']:
                                log('destination_rejected', destination=destination)
                                continue
                        proposed_action = action
                        action = resolve_skill(action, fresh, run.get('integrated_controls'))
                        if action != proposed_action:
                            log('action_resolved', proposed=proposed_action, executed=action)
                        self.update(stage='executing', latest_action=action)
                        log('action_started', action=action)
                        journey_action = action.startswith('travel:') or action in ('resume_journey', 'cancel_journey')
                        skill_action = action.startswith(('skill:', 'select:', 'use:'))
                        if skill_action:
                            def skill_log(kind, **values):
                                if kind == 'skill_observation':
                                    notebook.observe(values['state'])
                                    if run.get('decision_matrix'):
                                        objectives.observe(values['state'])
                                log(kind, **values)
                            result = await execute_skill(self.game, action, deadline=deadline,
                                stopped=self.stop.is_set, log=skill_log)
                        elif journey_action:
                            summary['navigation_requests'] += 1
                            result = await journeys.execute(self.game, action, deadline=deadline,
                                stopped=self.stop.is_set, log=log, update=self.update)
                        elif action.startswith('go:'):
                            summary['navigation_requests'] += 1
                            result = await navigate(
                                self.game, action[3:], deadline=deadline,
                                stopped=self.stop.is_set, log=log, update=self.update)
                        else:
                            result = await self.game.act(ACTION_MACROS[action].actions)
                        if run.get('memory_mode') == 'journey' and action.startswith('go:') and result.get('reason') == 'map_changed':
                            journeys.learn(state, action[3:], await self.game.state())
                        log('action_completed', action=action, result=result)
                        if run.get('persistent_memory'):
                            notebook.record({'message': {'content': '{}'}} if run.get('decision_matrix') else payload, action, result)
                            log('memory_updated', notebook=notebook.snapshot())
                        interaction_memory.acted(action)
                        executed = bool(result.get('inputs')) if action.startswith('go:') or journey_action or skill_action else True
                        summary['actions'] += int(executed)
                        summary['zero_input_navigation'] += int((action.startswith('go:') or journey_action) and not executed)
                        summary['controller_inputs'] += (len(result['inputs']) if action.startswith('go:') or journey_action or skill_action
                                                         else len(ACTION_MACROS[action].actions))
                        summary['navigation_actions'] += int((action.startswith('go:') or journey_action) and executed)
                        history.append({'before': compact_state(state), 'action': action, 'outcome': result})
                    except (httpx.HTTPError, TimeoutError) as exc:
                        if time.monotonic() >= deadline:
                            log('deadline', interrupted_inference=True)
                            break
                        summary['errors'] += 1
                        consecutive_errors += 1
                        log('error', error=repr(exc), cause=repr(exc.__cause__))
                        self.update(stage='retrying', error=str(exc))
                        if consecutive_errors >= 5:
                            raise RuntimeError('Five consecutive service failures') from exc
                        await asyncio.sleep(min(2, max(0, deadline - time.monotonic())))
                summary['status'] = 'interrupted' if self.stop.is_set() else 'completed'
            except asyncio.CancelledError:
                summary['status'] = 'interrupted'
                raise
            except Exception as exc:  # Retain failed experiment artifacts.
                summary['status'] = 'run_failed' if started else 'load_failed'
                summary['error'] = repr(exc)
                log('failure', error=repr(exc), cause=repr(exc.__cause__))
                if isinstance(exc, ResourcePressure):
                    summary['resource_affected'] = True
                    raise  # End the batch rather than repeating an unsafe load.
            finally:
                self.game.deadline = float('inf')
                if isinstance(self.game, SettledGame):
                    summary['controller_inputs'] = self.game.inputs_sent - input_count_at_start
                self.update(stage='saving', deadline=None, navigation=None)
                if started:
                    summary['elapsed_seconds'] = time.monotonic() - started
                    summary['overshoot_seconds'] = max(0, summary['elapsed_seconds'] - run['duration_seconds'])
                try:
                    final, self.frame = await self.game.observe()
                    write_json(folder / 'final-observation.json', final)
                    (folder / 'final.png').write_bytes(self.frame)
                    # Final evidence can fall after cutoff; keep it separate from timed milestones.
                    summary['final_evidence'] = evidence(final)
                    await self.game.save(run_id + '-final')
                    shutil.copyfile(self.output / 'emulator/saves' / (run_id + '-final.state'),
                                    folder / 'final.state')
                except Exception as exc:  # noqa: BLE001 - retain failed experiment artifacts
                    summary['finalization_error'] = repr(exc)
                    summary['status'] = 'finalization_failed'
                summary['unique_positions'] = len(positions)
                summary['valid_action_rate'] = (summary['valid_responses'] / summary['attempts']
                                                if summary['attempts'] else None)
                summary['actions_per_minute'] = (summary['actions'] * 60 / summary['elapsed_seconds']
                                                 if summary.get('elapsed_seconds') else None)
                if latencies:
                    ordered = sorted(latencies)
                    summary['latency_p50_seconds'] = ordered[len(ordered) // 2]
                    summary['latency_p95_seconds'] = ordered[min(len(ordered)-1, int(len(ordered)*.95))]
                summary['model_recoveries'] = (self.managed_model.recoveries
                                               if self.managed_model else 0)
                summary['resource_affected'] = summary.get('resource_affected', False) or summary['model_recoveries'] > 0
                try:
                    write_metrics(folder)
                except Exception as exc:  # noqa: BLE001 - diagnostics must not abort a scored batch
                    summary['behavior_metrics_error'] = repr(exc)
                write_json(folder / 'summary.json', summary)
                self.status['results'].append(summary)
                self.update(results=self.status['results'])
                self.write_report()
                await self.unload()

    async def run(self):
        self.output.mkdir(parents=True, exist_ok=bool(self.resume_after))
        self.lock = (ROOT / 'data/lab.lock').open('w')
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            async with httpx.AsyncClient(timeout=30) as self.http:
                self.game = SettledGame(PokemonClient(self.game_url, self.http))
                self.update(stage='preflight')
                await preflight(self.config, self.http)
                if self.config.get('model_guard'):
                    self.managed_model = ManagedModel(
                        self.http, self.model_url, self.config['model_guard'], self.output, self.update)
                if not self.resume_after:
                    shutil.copyfile(self.config['start_state'], self.output / 'starting.state')
                self.config['start_state'] = str(self.output / 'starting.state')
                sources = (self.output / 'source-revisions' / f'after-{self.resume_after:02}-{uuid.uuid4().hex[:8]}'
                           if self.resume_after else self.output / 'source')
                shutil.copytree(ROOT / 'src/imajev_player', sources,
                                ignore=shutil.ignore_patterns('__pycache__'))
                shutil.copyfile(ROOT / 'scripts/llama-server-safe-loader.py', sources / 'llama-server-safe-loader.py')
                manifest = {'config': self.config, 'queue': self.queue,
                            'rom_sha256': digest(Path(self.config['rom'])),
                            'start_sha256': digest(Path(self.config['start_state'])),
                            'packages': {name: importlib.metadata.version(name)
                                         for name in ('pyboy', 'pokemon-agent', 'httpx')},
                            'protocol': self.config.get('protocol', 'lab-v2.6-persistent-memory-comparison'), 'prompt': PROMPT,
                            'warmup': 'reactive-384-tokens-with-2000-calibration-words',
                            'observation_settling': {'minimum_after_input_seconds': .35, 'stable_seconds': .2, 'timeout_seconds': 3},
                            'loading': 'direct-io; lazy CPU embeddings; dedicated launcher override',
                            'loader_sha256': digest(ROOT / 'scripts/llama-server-safe-loader.py'),
                            'hypothesis': self.config.get('hypothesis') or ('Persistent task memory improves goal completion under the same time and token budgets.'
                                           if self.config.get('compare_memory') else
                                           'Reactive throughput outweighs bounded planning benefits.'),
                            'story_detectors': 'provisional; validate before publishing rankings'}
                manifest['first_run'] = self.resume_after + 1
                write_json(self.output / (f'revision-{sources.name}.json'
                                          if self.resume_after else 'manifest.json'), manifest)
                # Drain only when the user starts the lab, never during preflight.
                self.update(stage='draining_live_controller')
                prior = await self.http.get(self.config['controller_url'] + '/api/status')
                prior.raise_for_status()
                write_json(self.output / (f'previous-controller-after-{self.resume_after:02}.json'
                                         if self.resume_after else 'previous-controller.json'), prior.json())
                await self.post(self.config['controller_url'] + '/api/maintenance/drain', {}, 600)
                self.owns_model = True
                await self.unload()
                await self.start_emulator()
                for index, run in enumerate(self.queue):
                    if index < self.resume_after:
                        continue
                    if self.stop.is_set():
                        break
                    await self.run_one({**run, 'navigation_revision': self.config.get('navigation_revision', 'downward-ledges-v1')}, index)
                self.update(stage='interrupted' if self.stop.is_set() else 'complete', current=None)
        except asyncio.CancelledError:
            self.update(stage='interrupted', deadline=None)
            raise
        except Exception as exc:  # noqa: BLE001 - retain failed experiment artifacts
            self.update(stage='failed', error=repr(exc), deadline=None)
        finally:
            if self.owns_model:
                final_stage = self.status['stage']
                try:
                    async with httpx.AsyncClient(timeout=30) as self.http:
                        await self.unload()
                except Exception as exc:  # noqa: BLE001 - report cleanup failures
                    self.status['cleanup_error'] = repr(exc)
                    final_stage = 'failed'
                self.update(stage=final_stage)
            if self.process:
                self.process.terminate()
                try:
                    await asyncio.to_thread(self.process.wait, timeout=10)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    await asyncio.to_thread(self.process.wait)
                self.emulator_log.close()
            if self.lock:
                self.lock.close()
            self.write_report()

    def write_report(self):
        lines = ['# One-hour lab results', '', 'Raw pilot results; story flags remain provisional.', '',
                 '| Run | Policy | Memory | Status | Actions | Milestone evidence |',
                 '|---|---|---|---|---:|---|']
        for result in self.status['results']:
            lines.append(f"| {result['run_id']} | {result['policy']} | "
                         f"{result.get('memory_mode', 'On' if result.get('persistent_memory') else 'Off')} | {result['status']} | "
                         f"{result['actions']} | {', '.join(result['milestones']) or 'None'} |")
        lines += ['', 'Interpretation: pending review of saved frames and event logs.',
                  f"Batch status: {self.status['stage']}", '']
        for attempt in self.status.get('interrupted_attempts', []):
            lines.append(f"Interrupted attempt retained separately: {attempt['run_id']} ({attempt.get('error', 'interrupted')}).")
        for change in self.status.get('protocol_changes', []):
            lines.append(f"Protocol changes from run {change['first_run']}: {change['protocol']}. {change['reason']}.")
        (self.output / 'REPORT.md').write_text('\n'.join(lines))


def can_act(deadline: float, stopped: bool) -> bool:
    return not stopped and time.monotonic() < deadline


async def verify_exclusive_services():
    for name in ('ollama.service', 'nemotron-vllm.service'):
        result = await asyncio.to_thread(subprocess.run,
            ['systemctl', 'show', name, '-p', 'ActiveState', '--value'],
            capture_output=True, text=True, timeout=10, check=True)
        if result.stdout.strip() not in {'inactive', 'failed'}:
            raise ValueError(f'Competing system model service {name} must be stopped first')


async def preflight(config: dict, http: httpx.AsyncClient):
    for name in ('rom', 'start_state'):
        if not Path(config[name]).is_file():
            raise ValueError(f'Missing {name}: {config[name]}')
    if digest(Path(config['start_state'])) != config['start_sha256']:
        raise ValueError('Starting save hash changed')
    if config['repeats'] < 1 or config['duration_seconds'] <= 0:
        raise ValueError('Repeats and duration must be positive')
    if config.get('model_guard'):
        loader = Path(config['model_guard']['loader_path'])
        if not loader.is_file() or digest(loader) != digest(ROOT / 'scripts/llama-server-safe-loader.py'):
            raise ValueError('Safe model loader missing or changed; refusing to load')
        if not loader.with_name('llama-server.original').is_file():
            raise ValueError('Original model backend missing')
    if config.get('model_guard') and (ROOT / 'data/pokemon-model-exclusive').exists():
        await verify_exclusive_services()
    response = await http.get(config['model_url'] + '/api/tags')
    response.raise_for_status()
    installed = {m['name']: m for m in response.json()['models']}
    for name in config['models']:
        if name not in installed or installed[name]['digest'] != config['model_digests'][name]:
            raise ValueError(f'Missing or changed model: {name}')
        response = await http.post(config['model_url'] + '/api/show', json={'model': name})
        response.raise_for_status()
        if not {'vision', 'thinking'} <= set(response.json().get('capabilities', [])):
            raise ValueError(f'Model lacks vision/thinking: {name}')
    # Refuse to attach to another process's emulator.
    import socket
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(('127.0.0.1', config['emulator_port']))


def create_app(lab: Lab):
    async def capture_frames():
        while True:
            if lab.process and lab.process.poll() is None:
                try:
                    async with httpx.AsyncClient(timeout=2) as http:
                        response = await http.get(lab.game_url + '/screenshot')
                        response.raise_for_status()
                        lab.frame = response.content
                        lab.status['frame_ts'] = time.time()
                except httpx.HTTPError:
                    pass
            await asyncio.sleep(0.25)

    @asynccontextmanager
    async def lifespan(app):
        task = asyncio.create_task(lab.run())
        capture = asyncio.create_task(capture_frames())
        yield
        capture.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await capture
        lab.stop.set()
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    app = FastAPI(lifespan=lifespan)

    @app.get('/')
    async def index():
        return FileResponse(ROOT / 'src/imajev_player/static/lab.html')

    @app.get('/api/status')
    async def status():
        return lab.status

    @app.get('/api/frame')
    async def frame():
        return Response(lab.frame, media_type='image/png', headers={'Cache-Control': 'no-store'})

    return app


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'experiments/overnight.json')
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--after-runs', type=int, default=0)
    args = parser.parse_args()
    if bool(args.resume) != bool(args.after_runs) or args.after_runs < 0:
        parser.error('--resume and a positive --after-runs must be used together')
    config = (json.loads((args.resume / 'manifest.json').read_text())['config']
              if args.resume else json.loads(args.config.read_text()))
    if args.preflight:
        async def check():
            async with httpx.AsyncClient(timeout=30) as http:
                await preflight(config, http)
        asyncio.run(check())
        print(json.dumps({'ready': True, 'runs': schedule(config)}, indent=2))
        return
    output = args.resume or ROOT / 'data/lab' / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6])
    lab = Lab(config, output, resume_after=args.after_runs)
    uvicorn.run(create_app(lab), host='0.0.0.0', port=config['dashboard_port'],
                log_level='info', access_log=False)


if __name__ == '__main__':
    main()
