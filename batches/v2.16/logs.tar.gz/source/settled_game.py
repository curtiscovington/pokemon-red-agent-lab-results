"""Consistent post-input observations and explicit write-failure attribution."""
import asyncio
import json
import time

import httpx


class InputOutcomeUnknown(RuntimeError):
    pass


def context_key(state):
    return json.dumps({
        'map': state.get('map'), 'position': state.get('player', {}).get('position'),
        'facing': state.get('player', {}).get('facing'),
        'interface': state.get('interface'), 'battle': state.get('battle'),
    }, sort_keys=True)


class SettledGame:
    def __init__(self, game):
        self.game = game
        self.last_input = float('-inf')
        self.inputs_sent = 0
        self.deadline = float('inf')

    def __getattr__(self, name):
        return getattr(self.game, name)

    async def act(self, actions):
        try:
            result = await self.game.act(actions)
        except httpx.HTTPError as exc:
            raise InputOutcomeUnknown(f'POST /action: {type(exc).__name__}: {exc}') from exc
        self.last_input = time.monotonic()
        self.inputs_sent += len(actions)
        return result

    async def observe(self):
        await asyncio.sleep(min(max(0, self.deadline-time.monotonic()),
                                max(0, self.last_input + .35 - time.monotonic())))
        deadline = min(self.deadline, time.monotonic() + 3)
        previous = None
        stable_since = time.monotonic()
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('GET /observation: observation deadline reached')
            state, screen = await asyncio.wait_for(self.game.observe(), timeout=deadline-time.monotonic())
            now = time.monotonic()
            key = context_key(state)
            if key != previous:
                previous, stable_since = key, now
            elif now - stable_since >= .2:
                return state, screen
            if now >= deadline:
                raise TimeoutError('GET /observation: interface did not settle within 3 seconds')
            await asyncio.sleep(.05)

    async def state(self):
        state, _ = await self.observe()
        return state
