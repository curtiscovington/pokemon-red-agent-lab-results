# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-reactive-77de9e82 | reactive | evidence | completed | 434 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 02-reactive-e10d2cba | reactive | evidence | completed | 400 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 03-reactive-009d6393 | reactive | evidence | completed | 378 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 04-reactive-e4ff8e48 | reactive | evidence | completed | 430 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 05-reactive-eed6e8db | reactive | evidence | completed | 453 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 06-reactive-473bdd13 | reactive | evidence | completed | 606 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 07-reactive-405fc1d1 | reactive | evidence | completed | 349 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 08-reactive-e9714296 | reactive | evidence | completed | 427 | party_observed, provisional_has_parcel, provisional_has_pokedex |

Interpretation: pending review of saved frames and event logs.
Batch status: complete
