# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-reactive-66d609c2 | reactive | evidence | completed | 336 | party_observed |
| 02-reactive-522b90f8 | reactive | evidence | completed | 376 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 03-reactive-f53c756e | reactive | evidence | completed | 403 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 04-reactive-655fbb5e | reactive | evidence | completed | 438 | party_observed |
| 05-reactive-61b747df | reactive | evidence | completed | 405 | party_observed |
| 06-reactive-466deeb1 | reactive | evidence | completed | 458 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 07-reactive-0528a966 | reactive | evidence | completed | 362 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 08-reactive-681c4ed9 | reactive | evidence | completed | 337 | party_observed |

Interpretation: pending review of saved frames and event logs.
Batch status: complete
