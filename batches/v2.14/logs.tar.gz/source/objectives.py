"""Disclosed Red-specific guidance; completion comes only from observed evidence."""
import re

from .outcome_metrics import normalized


class Objectives:
    def __init__(self):
        self.had_parcel = False
        self.delivery_text = False
        self.delivered = False
        self.pokedex = False

    def observe(self, state):
        parcel = any(i.get('id') == 70 and i.get('quantity', 0) > 0 for i in state.get('bag', []))
        self.had_parcel |= parcel
        text = normalized(' '.join(state.get('interface', {}).get('text', [])))
        self.delivery_text |= bool(re.search(r'\bDELIVERED OAK\s*S?\s*PARCEL\b', text))
        self.delivered |= self.had_parcel and self.delivery_text and not parcel
        self.pokedex |= bool(re.search(r'\bGOT POKEDEX FROM OAK\b', text))
        starter = any(1 <= p.get('level', 0) <= 100 and p.get('species_id', 0) > 0
                      for p in state.get('party', []))
        if not starter:
            goal = ('obtain_starter', 'Leave the house. In Pallet Town walk north to meet Oak, then follow him and choose a starter in his lab.', 'A valid Pokemon appears in party.')
        elif not self.delivered and not self.pokedex:
            if parcel:
                goal = ('deliver_parcel', 'Return south through Route 1 to Pallet Town, enter Oak\'s Lab and speak to Oak. Do not revisit the Mart to collect another parcel.', 'Delivery dialogue and parcel removed from bag.')
            else:
                goal = ('collect_parcel', 'Travel north to Viridian City, enter the Mart and speak to its clerk.', 'Oak\'s Parcel (item 70) appears in bag.')
        elif not self.pokedex:
            goal = ('receive_pokedex', 'Continue Oak\'s conversation until the Pokedex is received.', 'Explicit Pokedex receipt dialogue.')
        elif not state.get('player', {}).get('badges'):
            goal = ('first_badge', 'Travel north through Viridian City, Route 2 and Viridian Forest toward Pewter City. Prepare your team, heal when needed, and defeat Brock.', 'First badge observed.')
        else:
            goal = ('continue_journey', 'Continue toward the next badge, keeping the team healthy.', 'Further badges observed.')
        return {'id': goal[0], 'instruction': goal[1], 'success_evidence': goal[2],
                'source': 'Explicit Pokemon Red guide; completion checked from observed game state.'}
