# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-random-58ce08c7 | random | evidence | completed | 1355 | party_observed |
| 02-scripted-0093cd7c | scripted | evidence | completed | 988 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 03-reactive-3f3ae61d | reactive | evidence | completed | 423 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 04-scripted-98267a11 | scripted | evidence | completed | 1061 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 05-reactive-94d1f052 | reactive | evidence | completed | 307 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 06-random-d9f574b7 | random | evidence | completed | 1317 | party_observed, provisional_has_parcel |
| 07-reactive-1bae2148 | reactive | evidence | completed | 395 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 08-random-13a87537 | random | evidence | completed | 1412 | party_observed, provisional_has_parcel |
| 09-scripted-21f2aaf0 | scripted | evidence | completed | 1052 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 10-reactive-a3fe2533 | reactive | evidence | completed | 370 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 11-scripted-b0522888 | scripted | evidence | completed | 1040 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 12-random-368948bc | random | evidence | completed | 1456 | party_observed |
| 13-scripted-2b285d84 | scripted | evidence | completed | 924 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 14-random-c3140edc | random | evidence | completed | 1762 | party_observed |
| 15-reactive-43112f78 | reactive | evidence | completed | 407 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 16-random-0ed2ba65 | random | evidence | completed | 1598 | party_observed |
| 17-reactive-87092e5d | reactive | evidence | completed | 387 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 18-scripted-3076f77a | scripted | evidence | completed | 907 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 19-random-19804bd0 | random | evidence | completed | 1282 | party_observed |
| 20-scripted-c7251dcf | scripted | evidence | completed | 959 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 21-reactive-7c996b9e | reactive | evidence | completed | 297 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 22-scripted-d5093fbb | scripted | evidence | completed | 992 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 23-reactive-f442ad40 | reactive | evidence | completed | 464 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 24-random-3daf863e | random | evidence | completed | 1671 | party_observed, provisional_has_parcel |
| 25-reactive-86caff46 | reactive | evidence | completed | 376 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 26-random-9008cc7b | random | evidence | completed | 1871 | party_observed |
| 27-scripted-2653f927 | scripted | evidence | completed | 998 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 28-reactive-c83f4a58 | reactive | evidence | completed | 342 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 29-scripted-f1a090d0 | scripted | evidence | completed | 947 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 30-random-0cfa5981 | random | evidence | completed | 1540 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 31-scripted-60cc4774 | scripted | evidence | completed | 862 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 32-random-e3eb93a6 | random | evidence | completed | 1497 | party_observed |
| 33-reactive-dae8fb74 | reactive | evidence | completed | 376 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 34-random-d2d49143 | random | evidence | completed | 1323 | party_observed, provisional_has_parcel |
| 35-reactive-5b4d0859 | reactive | evidence | completed | 334 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 36-scripted-c23e6f37 | scripted | evidence | completed | 873 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 37-random-610b8817 | random | evidence | completed | 1291 | party_observed |
| 38-scripted-e104a99d | scripted | evidence | completed | 952 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 39-reactive-76efdad3 | reactive | evidence | completed | 345 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 40-scripted-754e2899 | scripted | evidence | completed | 1063 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 41-reactive-03678850 | reactive | evidence | completed | 379 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 42-random-f45d639e | random | evidence | completed | 1538 | party_observed |
| 43-reactive-fe1b6814 | reactive | evidence | completed | 590 | party_observed, provisional_has_parcel |
| 44-random-80c94829 | random | evidence | completed | 1510 | party_observed |
| 45-scripted-f1b5d122 | scripted | evidence | completed | 1130 | party_observed, provisional_has_parcel, provisional_has_pokedex |

Interpretation: pending review of saved frames and event logs.
Batch status: complete
