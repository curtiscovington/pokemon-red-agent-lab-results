"""Opt-in separate process for the route-informed script; never alters a live lab."""
from . import lab
from .scripted_route_policy import ScriptedRoutePolicy, VERSION


def main():
    original_schedule = lab.schedule
    def schedule(config):
        if config.get('scripted_variant') != VERSION:
            raise ValueError('This entrypoint requires the explicit route-v2 protocol')
        runs = original_schedule(config)
        if any(r['policy'] != 'scripted' for r in runs):
            raise ValueError('This validation batch is scripted-route only')
        return [{**r, 'scripted_variant': VERSION} for r in runs]
    lab.schedule = schedule
    lab.BaselinePolicy = ScriptedRoutePolicy
    lab.main()


if __name__ == '__main__':
    main()
