"""Route-aware + damage-aware baseline v3, separate from historical selectors."""
import json
from collections import OrderedDict
from .baseline_policies import BaselinePolicy, context_from
from .scripted_route_policy import ScriptedRoutePolicy
from .combat_policy import choose_attack

VERSION = 'red-route-combat-v4'


class ScriptedCombatPolicy(ScriptedRoutePolicy):
    def __init__(self, policy='scripted', seed=0):
        super().__init__(policy, seed)
        self.fallback_visits = OrderedDict()

    def choose(self, request):
        context = context_from(request)
        actions = request['format']['properties']['action']['enum']
        attack = choose_attack(context, actions)
        if attack:return attack
        action, rule = super().choose(request)
        if rule == 'route_target_unavailable':
            # Choose among offered destinations only; never raw-button bypass a
            # suppressed NPC. Prefer alternatives we have not already retried.
            targets = [a for a in actions if a.startswith('go:')]
            if targets:
                mid = context['state'].get('map', {}).get('map_id')
                action = min(targets, key=lambda a: self.fallback_visits.get((mid, a), 0))
                key = (mid, action)
                self.fallback_visits[key] = self.fallback_visits.get(key, 0) + 1
                self.fallback_visits.move_to_end(key)
                while len(self.fallback_visits) > 128:self.fallback_visits.popitem(last=False)
                return action, 'available_route_fallback'
        return action, rule

    @staticmethod
    def route(mid, mission, goal, actions):
        if mid == 13:
            # Route 2 has disconnected north/south sections. The offered north
            # edge identifies the reachable Pewter side, including after a loss.
            north = next((a for a in actions if a.startswith('go:13-edge-up-')), None)
            if north and mission in ('continue', 'heal'):
                return north
        if mid == 47 and mission == 'heal':
            # Already at forest's north gate: proceed toward nearby Pewter.
            return next((a for a in actions if a in ('go:47-exit-1','go:47-exit-2')), 'go:47-exit-1')
        return ScriptedRoutePolicy.route(mid, mission, goal, actions)

    def response(self, request):
        action, rule = self.choose(request)
        return {'message': {'role': 'assistant', 'content': json.dumps({'action': action})},
                'done': True, 'done_reason': 'stop', 'policy': 'scripted',
                'policy_rule': rule, 'policy_version': VERSION,
                'policy_variant': 'route_and_combat_informed'}


def policy_factory(policy, seed):
    return ScriptedCombatPolicy(policy, seed) if policy == 'scripted' else BaselinePolicy(policy, seed)
