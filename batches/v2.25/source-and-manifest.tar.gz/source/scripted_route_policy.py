"""Separate route-informed script; deliberately adds disclosed Red-specific knowledge.

No imports or edits to this module occur in the running v2.22 baseline process.
Route IDs below come from archived observed transitions, not live hidden ROM data.
Only currently offered actions can execute. Dialogue/inventory evidence advances
missions; issuing a walking command never counts as mission completion.
"""
import json
from .baseline_policies import BaselinePolicy, context_from, scripted

VERSION = 'red-parcel-route-v2'

# Named roles/destinations are prior knowledge added by this variant.
LOCAL_TARGETS = {
    'viridian_mart': 'go:1-exit-2',
    'mart_clerk': 'go:42-object-1',
    'oak_lab': 'go:0-exit-3',
    'oak': 'go:40-object-5',
    'viridian_center': 'go:1-exit-1',
    'pewter_center': 'go:2-exit-7',
    'pewter_gym': 'go:2-exit-3',
    'brock': 'go:54-object-1',
}


class ScriptedRoutePolicy(BaselinePolicy):
    def __init__(self, policy='scripted', seed=0):
        if policy != 'scripted':
            raise ValueError('Route policy is a scripted variant')
        super().__init__(policy, seed)
        self.parcel_seen = False
        self.pokedex_received = False

    def choose(self, request):
        context = context_from(request)
        actions = request['format']['properties']['action']['enum']
        if not actions:
            raise ValueError('Empty offered action enum')
        state = context['state']
        ui = state.get('interface') or {}
        goal = context.get('objective', {}).get('id')
        parcel = any(i.get('id') == 70 and i.get('quantity', 0) > 0 for i in state.get('bag', []))
        self.parcel_seen |= parcel
        # These guide stages require observed delivery/Pokedex evidence upstream.
        self.pokedex_received |= goal in {'reach_forest', 'cross_forest', 'reach_pewter',
            'heal_team', 'enter_pewter_gym', 'challenge_brock', 'continue_journey'}
        text = ' '.join(ui.get('text', [])).upper()
        self.pokedex_received |= 'GOT POKEDEX FROM OAK' in text or 'GOT POKÉDEX FROM OAK' in text
        if (state.get('battle') or {}).get('in_battle') or ui.get('kind') not in (None, 'overworld'):
            return scripted(context, actions)
        if goal == 'obtain_starter' and (state.get('map') or {}).get('map_id') not in (37, 38):
            return scripted(context, actions)
        if goal in ('recover_team', 'heal_team'):
            mission = 'heal'
        elif self.pokedex_received:
            mission = 'continue'
        elif parcel or self.parcel_seen or goal in ('deliver_parcel', 'receive_pokedex'):
            mission = 'deliver'
        else:
            mission = 'collect'
        mid = (state.get('map') or {}).get('map_id')
        desired = self.route(mid, mission, goal, actions)
        if desired in actions:
            return desired, 'route_' + mission
        retained = context.get('walking_destination', {}).get('action')
        if retained and 'cancel_route' in actions and retained != desired:
            return 'cancel_route', 'release_route_for_' + mission
        if desired:
            # Do not use raw buttons to bypass route/NPC suppression.
            return ('wait' if 'wait' in actions else actions[0]), 'route_target_unavailable'
        return scripted(context, actions)

    @staticmethod
    def route(mid, mission, goal, actions):
        def edge(direction):
            return next((a for a in actions if a.startswith(f'go:{mid}-edge-{direction}-')),
                        f'go:{mid}-edge-{direction}-unavailable')
        def exits(*numbers):
            choices = [f'go:{mid}-exit-{n}' for n in numbers]
            return next((a for a in choices if a in actions), choices[0])
        if mid == 38:
            return exits(1)
        if mid == 37:
            return exits(1, 2)
        if mid == 40:
            return LOCAL_TARGETS['oak'] if mission == 'deliver' else exits(1, 2)
        if mid == 42:
            return LOCAL_TARGETS['mart_clerk'] if mission == 'collect' else exits(1, 2)
        if mid in (41, 58):
            if mission == 'heal':
                return f'go:{mid}-object-1'
            return exits(1, 2)
        if mid == 0:
            return LOCAL_TARGETS['oak_lab'] if mission == 'deliver' else edge('up')
        if mid == 12:
            return edge('down' if mission == 'deliver' else 'up')
        if mid == 1:
            if mission == 'collect':return LOCAL_TARGETS['viridian_mart']
            if mission == 'deliver':return edge('down')
            if mission == 'heal':return LOCAL_TARGETS['viridian_center']
            return edge('up')
        if mid == 13:
            return edge('down') if mission in ('deliver', 'collect', 'heal') else (
                edge('up') if goal == 'reach_pewter' else exits(6))
        if mid in (47, 50):
            return exits(3, 4) if mission in ('deliver', 'collect', 'heal') else exits(1, 2)
        if mid == 51:
            return exits(3, 4, 5, 6) if mission in ('deliver', 'collect', 'heal') else exits(1, 2)
        if mid == 2:
            return LOCAL_TARGETS['pewter_center'] if mission == 'heal' else LOCAL_TARGETS['pewter_gym']
        if mid == 54:
            return exits(1, 2) if mission == 'heal' else LOCAL_TARGETS['brock']
        return None

    def response(self, request):
        action, rule = self.choose(request)
        return {'message': {'role': 'assistant', 'content': json.dumps({'action': action})},
                'done': True, 'done_reason': 'stop', 'policy': 'scripted',
                'policy_rule': rule, 'policy_version': VERSION,
                'policy_variant': 'route_informed'}
