"""Translate lab evidence into the existing Game Boy dashboard snapshot format."""
from __future__ import annotations

import json
import time
from collections import deque
from pathlib import Path

from .actions import LAB_ACTION_MACROS as ACTION_MACROS


class LabPresentation:
    def __init__(self, root: Path):
        self.root = root
        self.run_id = None
        self.path = None
        self.offset = 0
        self.inputs = deque(maxlen=80)
        self.decisions = deque(maxlen=30)
        self.turn = 0
        self.last_game = None
        self.allowed = set()

    def read_events(self, run_id):
        if run_id != self.run_id:
            self.run_id = run_id
            self.path = next(self.root.glob(f'*/{run_id}/events.jsonl'), None) if run_id else None
            self.offset = 0
            self.inputs.clear()
            self.decisions.clear()
            self.turn = 0
            self.last_game = None
            self.allowed.clear()
        if not self.path and run_id:
            self.path = next(self.root.glob(f'*/{run_id}/events.jsonl'), None)
        if not self.path:
            return
        with self.path.open('rb') as source:
            source.seek(self.offset)
            for line in source:
                # A writer may be midway through an append; retry that line next time.
                if not line.endswith(b'\n'):
                    break
                self.offset += len(line)
                event = json.loads(line)
                kind = event['type']
                if kind == 'observation':
                    self.last_game = event['state']
                elif kind == 'request':
                    self.allowed = set(event['request']['format']['properties']['action']['enum'])
                elif kind == 'response':
                    message = event['response'].get('message') or {}
                    try:
                        answer = json.loads(message.get('content', ''))
                    except (TypeError, ValueError):
                        answer = {}
                    if not isinstance(answer, dict):
                        answer = {}
                    choice = answer.get('action')
                    targets = (self.last_game or {}).get('navigation', {}).get('targets', [])
                    target = next((t for t in targets if 'go:' + t['id'] == choice), None)
                    label = ('Go to ' + target['label']) if target else (ACTION_MACROS[choice].label if isinstance(choice, str) and choice in ACTION_MACROS else choice if isinstance(choice, str) and choice in self.allowed else '—')
                    valid = (isinstance(choice, str) and (choice in self.allowed or choice in ACTION_MACROS or target is not None)
                             and event['response'].get('done_reason') != 'length'
)
                    self.decisions.appendleft({
                        'choice': choice if valid else None,
                        'choices': [choice] if valid else [],
                        'label': label if valid else '—',
                        'labels': [label] if valid else [],
                        'reasoning': message.get('thinking') or answer.get('explanation') or
                                     event['response'].get('policy_rule', '').replace('_', ' ') or
                                     ('Selected ' + choice if valid else 'No valid structured action was returned.'),
                        'mode': 'action_first_json', 'abstained': not valid,
                        'latency_ms': event.get('latency_seconds', 0) * 1000,
                        'turn': self.turn + 1, 'ts': event['ts'], 'top': [],
                    })
                elif kind == 'navigation_step':
                    action = event['action']
                    self.inputs.appendleft({'action': action, 'label': action.removeprefix('walk_').removeprefix('press_').upper(),
                                            'source': 'lab', 'turn': self.turn + 1, 'ts': event['ts']})
                elif kind == 'action_completed':
                    macro = ACTION_MACROS.get(event['action'])
                    self.turn += 1
                    for action in (macro.actions if macro else []):
                        self.inputs.appendleft({'action': action, 'label': macro.label,
                                                'source': 'lab', 'turn': self.turn,
                                                'ts': event['ts']})

    def snapshot(self, lab: dict, game: dict | None = None) -> dict:
        current = lab.get('current') or {}
        if not current and lab.get('results'):
            current = {**lab['results'][-1], 'index': len(lab['results'])}
        self.read_events(current.get('run_id'))
        duration = current.get('duration_seconds', 3600)
        deadline = lab.get('deadline')
        remaining = max(0, deadline - time.time()) if deadline else None
        played = max(0, duration - remaining) if remaining is not None else 0
        stage = lab.get('stage', 'waiting').replace('_', ' ')
        policy = current.get('policy', '')
        run_type = {'reactive': 'Reactive', 'deliberative': 'Deliberative', 'random': 'Random', 'scripted': 'Scripted'}.get(policy, 'Preparing')
        if lab.get('purpose') == 'rehearsal':
            run_type = 'Rehearsal' if current.get('index', 1) == 1 else 'Reload check'
        title = f"{run_type} · {current.get('index', '-')} of {len(lab.get('runs', []))}"
        clock = f'{int(remaining)//60:02}:{int(remaining)%60:02} remaining' if remaining is not None else stage.capitalize()
        if lab.get('stage') in {'complete', 'failed', 'interrupted'}:
            title = 'Experiment'
            clock = stage.capitalize()
        times = sorted({event['ts'] for event in self.inputs})
        average = (times[-1] - times[0]) / (len(times) - 1) if len(times) > 1 else None
        model = current.get('model') or (lab.get('runs') or [{}])[0].get('model', 'model')
        setup = ('Thinking on' if policy == 'deliberative' else 'Thinking off') + (' · Auto-walk' if current.get('navigation') else ' · no pathfinder')
        if current.get('decision_matrix'):
            setup += ' · ' + ('Staged goals' if current.get('staged_goals') else 'Guided goals' if current.get('objective_controller') else 'Model goals')
            if current.get('persistent_walk'):
                setup += ' · ' + ('Progress recovery' if current.get('progress_control') else 'Resume walks')
            setup += ' · ' + ('Action only' if current.get('action_only') else 'With explanation')
        elif current.get('memory_mode'):
            setup += ' · ' + {'adaptive': 'Adaptive memory', 'evidence': 'Evidence memory', 'journey': 'Persistent journeys'}.get(current['memory_mode'], 'Basic memory')
        elif 'persistent_memory' in current:
            setup += ' · Memory on' if current['persistent_memory'] else ' · Memory off'
        display_model = {'qwen3.8-flash-next:iq4_nl': 'Qwen3.8 Flash Next · IQ4_NL'}.get(model, model)
        if policy in {'random', 'scripted'}:
            display_model = 'None — uniform random choices' if policy == 'random' else 'None — fixed decision rules'
            setup = 'Fixed controls · One-hour budget'
        return {
            'lab': {'run_id': current.get('run_id'), 'stage': stage, 'remaining': remaining},
            'control': 'running' if deadline else 'paused',
            'goals': {'short_term': f'{title} · {clock}',
                      'medium_term': setup,
                      'ultimate': display_model},
            'mission_labels': ['RUN', 'SETUP', 'MODEL'],
            'lessons': [], 'turn': self.turn, 'last_error': lab.get('error'),
            'services': {'game': bool(game or self.last_game), 'model': bool(deadline) and policy not in {'random', 'scripted'}},
            'model': {'backend': policy if policy in {'random', 'scripted'} else 'ollama', 'name': model if policy not in {'random', 'scripted'} else None},
            'game': game or self.last_game, 'inputs': list(self.inputs),
            'decisions': ([{**self.decisions[0], 'label': lab['navigation'], 'labels': [lab['navigation']]}] + list(self.decisions)[1:]
                          if lab.get('navigation') and self.decisions else list(self.decisions)),
            'timing': {'running': bool(deadline), 'played_seconds': played,
                       'last_action_ts': times[-1] if times else None,
                       'average_action_interval_seconds': average},
        }
