"""Frozen request-only baselines: no emulator, map database or hidden state access."""
import json
import random
import re
import unicodedata

VERSION = 'request-only-v1'
BASELINES = {'random', 'scripted'}


def context_from(request):
    text = request['messages'][0]['content']
    return json.loads(text[text.index('{"state":'):])


def normalized(text):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(text)).lower()
                   if not unicodedata.combining(c))


def decision_tags(request):
    context = context_from(request)
    actions = request['format']['properties']['action']['enum']
    state = context['state']
    kind = (state.get('interface') or {}).get('kind')
    return {'version': VERSION, 'offered': len(actions),
            'go': sum(a.startswith('go:') for a in actions),
            'moves': sum(a.startswith('use:') for a in actions),
            'singleton': len(actions) == 1,
            'resume_cancel': 'cancel_route' in actions,
            'battle': bool((state.get('battle') or {}).get('in_battle')),
            'dialogue_menu': kind not in (None, 'overworld'),
            'healing_objective': context.get('objective', {}).get('id') in ('heal_team', 'recover_team'),
            'reconsider': bool(context.get('repeat_feedback', {}).get('reconsider')),
            'objective': context.get('objective', {}).get('id'),
            'restricted_interactions': len(context.get('progress_control', {}).get('repeated_interaction_actions', [])),
            'restricted_routes': len(context.get('failed_routes', {}))}


class BaselinePolicy:
    def __init__(self, policy, seed):
        if policy not in BASELINES:
            raise ValueError(policy)
        self.policy = policy
        self.rng = random.Random(seed)

    def choose(self, request):
        actions = request['format']['properties']['action']['enum']
        if not actions:
            raise ValueError('Empty offered action enum')
        if self.policy == 'random':
            return self.rng.choice(actions), 'uniform_offered_action'
        return scripted(context_from(request), actions)

    def response(self, request):
        action, rule = self.choose(request)
        return {'message': {'role': 'assistant', 'content': json.dumps({'action': action})},
                'done': True, 'done_reason': 'stop',
                'policy': self.policy, 'policy_rule': rule, 'policy_version': VERSION}


def scripted(context, actions):
    """Priority rules over exactly the text/fields supplied in the model request.

    Ties retain offered-action order. Only random has private RNG state; script
    uses the common recent-action/evidence fields, not a private world model.
    """
    state = context['state']
    ui = state.get('interface') or {}
    goal = context.get('objective', {}).get('id', '')
    descriptions = context.get('allowed_actions', {})
    descriptions = descriptions if isinstance(descriptions, dict) else {}
    labels = {a: normalized(descriptions.get(a, '')) for a in actions}
    recent = context.get('recent_actions', [])
    repeat = context.get('repeat_feedback', {})
    avoid = set(repeat.get('repeated_local_actions', [])) if repeat.get('reconsider') else set()
    usable = [a for a in actions if a not in avoid] or actions
    battle = bool((state.get('battle') or {}).get('in_battle'))
    if battle:
        for a in actions:
            if a.startswith('use:'):
                return a, 'first_usable_move'
        for member in state.get('party', []):
            for move in member.get('moves', []):
                a = 'select:' + move.get('name', '').upper()
                if move.get('pp', 0) > 0 and a in actions:
                    return a, 'first_visible_usable_move'
        if 'select:FIGHT' in actions:
            return 'select:FIGHT', 'open_fight'
    if 'finish_name' in actions and ui.get('kind') == 'naming':
        return 'finish_name', 'finish_name'
    if 'skill:dialogue' in actions:
        return 'skill:dialogue', 'advance_dialogue'
    if 'select:YES' in actions:
        nickname = 'nickname' in normalized(' '.join(ui.get('text', [])))
        return ('select:NO' if nickname and 'select:NO' in actions else 'select:YES'), 'answer_yes_except_nickname'
    selections = [a for a in actions if a.startswith('select:')]
    if selections:
        return selections[0], 'first_visible_menu_option'
    if battle or ui.get('kind') not in (None, 'overworld'):
        if 'confirm' in actions:
            return 'confirm', 'confirm_current_interface'
    walking = context.get('walking_destination', {}).get('action')
    if walking in actions:
        # The common harness will re-offer destinations after cancellation.
        if goal in ('heal_team', 'recover_team') and 'cancel_route' in actions and not any(
                word in labels[walking] for word in ('nurse', 'pokemon center')):
            return 'cancel_route', 'reconsider_route_for_healing'
        return walking, 'resume_destination'
    go = [a for a in usable if a.startswith('go:')]
    if go:
        here = normalized((state.get('map') or {}).get('map_name', ''))
        instruction = normalized(context.get('objective', {}).get('instruction', ''))
        destinations = context.get('observed_destinations', {})
        desired = {'collect_parcel': 'mart', 'deliver_parcel': 'lab',
                   'receive_pokedex': 'lab', 'heal_team': 'pokemon center',
                   'recover_team': 'pokemon center', 'enter_pewter_gym': 'gym',
                   'challenge_brock': 'gym', 'reach_pewter': 'pewter',
                   'reach_forest': 'forest'}.get(goal, '')
        interaction_needed = ((desired and desired in here and goal in
            ('collect_parcel', 'deliver_parcel', 'receive_pokedex', 'heal_team', 'recover_team', 'challenge_brock')))
        direction = 'south' if goal in ('deliver_parcel', 'recover_team') else 'north' if 'north' in instruction else ''
        def rank(a):
            label = labels[a]
            score = 0
            if goal == 'obtain_starter' and 'poke ball' in label:
                score += 100
            if goal in ('heal_team', 'recover_team') and 'nurse' in label:
                score += 100
            if desired and desired in normalized(destinations.get(a, {}).get('name', '')):
                score += 80
            if desired and desired in label and desired not in here:
                score += 70
            if interaction_needed and ('person' in label or 'nurse' in label):
                score += 60
            if direction and direction + ' passage' in label and not (desired and desired in here):
                score += 50
            if 'exit' in label:
                score += 20
                # Choose the northern/southern exit from visible coordinates.
                point = re.search(r'at \((\d+),(\d+)\)', label)
                if point and direction:
                    score += (1 if direction == 'south' else -1) * int(point[2]) / 1000
            if 'passage' in label:
                score += 10
            if a in destinations and desired and desired not in normalized(destinations[a].get('name', '')):
                score -= 25
            score -= recent.count(a) * 5
            return score
        return max(go, key=rank), 'objective_and_visible_target'
    for action in ('confirm', 'cancel', 'wait'):
        if action in usable:
            return action, 'fallback_' + action
    return usable[0], 'first_offered_fallback'
