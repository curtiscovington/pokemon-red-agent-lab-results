"""Frozen three-arm comparison with the improved script; shared lab unchanged."""
from . import lab
from .scripted_combat_policy import VERSION, policy_factory


def main():
    original_schedule = lab.schedule
    def schedule(config):
        if config.get('scripted_variant') != VERSION:
            raise ValueError('Expected explicit combat-v3 protocol')
        return [{**r, **({'scripted_variant': VERSION} if r['policy'] == 'scripted' else {})}
                for r in original_schedule(config)]
    lab.schedule = schedule
    lab.BaselinePolicy = policy_factory
    lab.main()


if __name__ == '__main__':main()
