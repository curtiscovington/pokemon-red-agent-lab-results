"""Current-map assistance from live Red RAM; no destination/story lookup tables.

Layout reference: pret/pokered ram/wram.asm and macros/ram.asm. Coordinates are
16px movement tiles; the map buffer has a three-block border of 32px blocks.
"""
from __future__ import annotations

import asyncio
import time
from collections import Counter, deque

DIRECTIONS = {'up': (0, -1), 'down': (0, 1), 'left': (-1, 0), 'right': (1, 0)}
# pokered data/tilesets/ledge_tiles.asm: standing tile, ledge tile.
DOWN_LEDGES = {(0x2C, 0x37), (0x39, 0x36), (0x39, 0x37)}


def downward_jumps(tiles, grid, tileset):
    """Directed two-tile edges; never make the ledge itself walkable."""
    if tileset != 0:  # OVERWORLD only; tile IDs mean different things indoors.
        return []
    return [{'x': x, 'y': y, 'direction': 'down', 'landing_x': x, 'landing_y': y+2}
            for y in range(len(grid)-2) for x in range(len(grid[y]))
            if grid[y][x] and grid[y+2][x]
            and (tiles[y][x], tiles[y+1][x]) in DOWN_LEDGES]


def position(state):
    p = state['player']['position']
    return p['x'], p['y']


def interrupted(state):
    return ((state.get('interface') is not None and not state['interface'].get('navigation_available')) or
            state.get('battle', {}).get('in_battle') or
            state.get('dialog', {}).get('active') or
            state.get('dialog', {}).get('joy_ignore') or
            state.get('navigation', {}).get('blocked_by_ui'))


def read_map(emu, state):
    if interrupted(state):
        return {'targets': [], 'available': False}
    read = emu.read_u8
    tiles = emu.read_range(0xC3A0, 360)
    for y in range(18):
        row = bytes(tiles[y*20:(y+1)*20])
        for x in range(17):
            if row[x:x+3] == bytes([0x79, 0x7A, 0x7A]) and 0x7B in row[x+3:]:
                return {'targets': [], 'available': False, 'blocked_by_ui': True}
    w, h = read(0xD369), read(0xD368)
    if not (0 < w <= 64 and 0 < h <= 128 and (w + 6) * (h + 6) <= 1300):
        return {'targets': [], 'available': False}
    bank, blocks = read(0xD52B), emu.read_u16(0xD52C)
    collision = emu.read_u16(0xD530)
    if not (0x4000 <= blocks < 0x8000 and 0 < collision < 0x8000):
        return {'targets': [], 'available': False}
    rom = emu._pyboy.memory
    walk_tiles = set()
    for offset in range(256):
        tile = rom[0 if collision < 0x4000 else bank, collision + offset]
        if tile == 255:
            break
        walk_tiles.add(tile)
    grid, tile_grid = [], []
    for y in range(h * 2):
        row, tile_row = [], []
        for x in range(w * 2):
            block = read(0xC6E8 + (y // 2 + 3) * (w + 6) + x // 2 + 3)
            tile = rom[bank, blocks + block * 16 + (y % 2) * 8 + 4 + (x % 2) * 2]
            row.append(tile in walk_tiles)
            tile_row.append(tile)
        grid.append(row)
        tile_grid.append(tile_row)
    map_id = state['map']['map_id']
    targets = []
    for i in range(min(read(0xD3AE), 32)):
        y, x = read(0xD3AF + 4 * i), read(0xD3B0 + 4 * i)
        if x < w * 2 and y < h * 2:
            destination = read(0xD3B2 + 4 * i)
            label = 'Pokemon Center entrance' if destination in (41, 58) else f'Exit {i+1}'
            targets.append({'id': f'{map_id}-exit-{i+1}', 'label': label,
                            'kind': 'exit', 'x': x, 'y': y})
    for i in range(min(read(0xD4B0), 16)):
        y, x = read(0xD4B1 + 2 * i), read(0xD4B2 + 2 * i)
        if x < w * 2 and y < h * 2:
            targets.append({'id': f'{map_id}-sign-{i+1}', 'label': f'Sign {i+1}',
                            'kind': 'interact', 'x': x, 'y': y})
    hidden = set()
    for entry in range(16):
        sprite = read(0xD5CE + entry * 2)
        if sprite == 255:
            break
        flag = read(0xD5CF + entry * 2)
        if read(0xD5A6 + flag // 8) & (1 << (flag % 8)):
            hidden.add(sprite)
    for i in range(1, min(read(0xD4E1), 15) + 1):
        if i in hidden:
            continue
        picture = read(0xC100 + i * 16)
        y, x = read(0xC204 + i * 16) - 4, read(0xC205 + i * 16) - 4
        # Hidden/removed objects have no picture; off-screen objects remain in RAM.
        if picture and 0 <= x < w * 2 and 0 <= y < h * 2:
            label = {0x3D: 'Poké Ball', 0x40: 'Paper', 0x41: 'Book', 0x42: 'Clipboard'}.get(
                picture, 'Person' if picture < 0x3D else 'Object')
            if picture == 0x29:
                label = 'Nurse'
            approaches = []
            counter_tiles = set(emu.read_range(0xD532, 3)) - {255}
            for dx, dy in DIRECTIONS.values():
                mx, my, ax, ay = x+dx, y+dy, x+2*dx, y+2*dy
                if (0 <= ay < len(grid) and 0 <= ax < len(grid[ay])
                        and 0 <= my < len(tile_grid) and 0 <= mx < len(tile_grid[my])
                        and tile_grid[my][mx] in counter_tiles and grid[ay][ax]):
                    approaches.append([ax, ay])
            targets.append({'id': f'{map_id}-object-{i}', 'label': f'{label} {i}',
                            'kind': 'interact', 'x': x, 'y': y,
                            'counter_approaches': approaches})
            grid[y][x] = False
    # Connected outdoor edges are local passages, with no destination names leaked.
    connections = read(0xD370)
    for direction, bit in [('up', 8), ('down', 4), ('left', 2), ('right', 1)]:
        if connections & bit:
            cells = ([(x, 0 if direction == 'up' else h*2-1) for x in range(w*2)]
                     if direction in ('up', 'down') else
                     [(0 if direction == 'left' else w*2-1, y) for y in range(h*2)])
            # One target per contiguous opening, not every edge tile.
            group = []
            for x, y in cells + [(-1, -1)]:
                if x >= 0 and grid[y][x]:
                    group.append((x, y))
                elif group:
                    x, y = group[len(group)//2]
                    name = {'up': 'North', 'down': 'South', 'left': 'West', 'right': 'East'}[direction]
                    targets.append({'id': f'{map_id}-edge-{direction}-{x}-{y}',
                                    'label': f'{name} passage', 'kind': 'edge',
                                    'x': x, 'y': y, 'direction': direction})
                    group = []
    return {'available': True, 'map_id': map_id, 'walkable': grid, 'targets': targets,
            'jumps': downward_jumps(tile_grid, grid, read(0xD367))}


def route(state, target):
    nav = state.get('navigation', {})
    grid = nav.get('walkable', [])
    start = position(state)
    point = target['x'], target['y']
    goals = ({(point[0]+dx, point[1]+dy) for dx, dy in DIRECTIONS.values()}
             if target['kind'] == 'interact' else {point})
    if target['kind'] == 'interact':
        goals.update(tuple(p) for p in target.get('counter_approaches', []))
    # Never walk through a different warp en route to the selected destination.
    other_exits = {(t['x'], t['y']) for t in nav.get('targets', [])
                   if t['kind'] == 'exit' and t['id'] != target['id']}
    jumps = {(j['x'], j['y'], j['direction']): (j['landing_x'], j['landing_y'])
             for j in nav.get('jumps', [])}
    queue = deque([(start, [])])
    seen = {start}
    while queue:
        (x, y), path = queue.popleft()
        if (x, y) in goals:
            return path
        for direction, (dx, dy) in DIRECTIONS.items():
            nx, ny = x+dx, y+dy
            if (x, y, direction) in jumps:
                if (nx, ny) in other_exits:
                    continue
                nx, ny = jumps[x, y, direction]
            if ((nx, ny) not in seen and (nx, ny) not in other_exits and
                    0 <= ny < len(grid) and 0 <= nx < len(grid[ny]) and grid[ny][nx]):
                seen.add((nx, ny))
                queue.append(((nx, ny), path + [direction]))
    return None


def choices(state):
    if interrupted(state):
        return {}
    result = {}
    for target in state.get('navigation', {}).get('targets', []):
        path = route(state, target)
        if path is not None:
            result['go:' + target['id']] = f"{target['label']} at ({target['x']},{target['y']}); {len(path)} steps"
    return result


async def navigate(game, target_id, *, deadline, stopped, log, update):
    state = await game.state()
    initial_map = state.get('map', {}).get('map_id')
    count, stalled = 0, 0
    transitions = Counter()
    exit_attempts = set()
    result = {'target': target_id, 'inputs': [], 'reason': 'step_limit'}
    while count < 96:
        if stopped() or time.monotonic() >= deadline:
            result['reason'] = 'deadline'
            break
        if state.get('map', {}).get('map_id') != initial_map:
            result['reason'] = 'map_changed'
            # Map id changes before warp/object buffers finish loading.
            await asyncio.sleep(min(1.5, max(0, deadline - time.monotonic())))
            break
        if interrupted(state):
            result['reason'] = 'dialogue_or_battle'
            break
        target = next((t for t in state.get('navigation', {}).get('targets', [])
                       if t['id'] == target_id), None)
        if not target:
            result['reason'] = 'target_unavailable'
            break
        path = route(state, target)
        if path is None:
            result['reason'] = 'blocked'
            break
        update(navigation=f"Walking to {target['label']}")
        if path:
            action = 'walk_' + path[0]
        elif target['kind'] == 'interact':
            dx, dy = target['x']-position(state)[0], target['y']-position(state)[1]
            direction = ((dx > 0)-(dx < 0), (dy > 0)-(dy < 0))
            facing = next(d for d, delta in DIRECTIONS.items() if delta == direction)
            action = 'press_a' if state['player'].get('facing') == facing else 'walk_' + facing
        elif target['kind'] == 'edge':
            action = 'walk_' + target['direction']
        elif target['y'] == 0:
            action = 'walk_up'  # Border warps require crossing out of the map.
        elif target['y'] == len(state['navigation']['walkable']) - 1:
            action = 'walk_down'
        elif target['x'] == 0:
            action = 'walk_left'
        elif target['x'] == len(state['navigation']['walkable'][target['y']]) - 1:
            action = 'walk_right'
        else:
            # Warps may require pressing into a non-walkable doorway tile.
            # Try each direction once from the warp, rather than repeatedly
            # stepping off and back from the same side. No map-specific rules.
            direction = next((d for d in DIRECTIONS if d not in exit_attempts), None)
            if direction is None:
                result['reason'] = 'movement_cycle'
                break
            exit_attempts.add(direction)
            action = 'walk_' + direction
        before = position(state)
        jump = next((j for j in state.get('navigation', {}).get('jumps', [])
                     if (j['x'], j['y']) == before and action == 'walk_' + j['direction']), None)
        # Single input per request; uncertainty/timeout is propagated, never retried.
        if stopped() or time.monotonic() >= deadline:
            result['reason'] = 'deadline'
            break
        await game.act([action])
        result['inputs'].append(action)
        count += 1
        state = await game.state()
        if jump:
            # A hop lasts longer than a walk macro. Do not plan from the airborne
            # midpoint or issue another button while the engine simulates the hop.
            landing = jump['landing_x'], jump['landing_y']
            settle_deadline = min(deadline, time.monotonic() + 1.5)
            while (time.monotonic() < settle_deadline and not stopped()
                   and state.get('map', {}).get('map_id') == initial_map
                   and not state.get('battle', {}).get('in_battle')
                   and (position(state) != landing or interrupted(state))):
                await asyncio.sleep(min(.05, max(0, settle_deadline-time.monotonic())))
                state = await game.state()
        log('navigation_step', target=target_id, action=action,
            position=state.get('player', {}).get('position'), map=state.get('map'))
        if action == 'press_a':
            result['reason'] = 'interacted'
            break
        if state.get('map', {}).get('map_id') == initial_map and not interrupted(state):
            transition = (before, action, position(state))
            transitions[transition] += 1
            if transitions[transition] >= 3 and position(state) != before:
                result['reason'] = 'movement_cycle'
                break
        stalled = stalled + 1 if position(state) == before else 0
        if stalled >= 3:
            result['reason'] = 'blocked'
            break
        await asyncio.sleep(0)
    update(navigation=None)
    result['end_position'] = state.get('player', {}).get('position')
    result['interrupted_in_battle'] = bool(state.get('battle', {}).get('in_battle'))
    return result
