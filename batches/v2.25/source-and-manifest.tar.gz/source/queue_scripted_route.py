"""Pinned, one-shot follow-up launcher; never replaces an unfinished pilot."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
import httpx
from .experiment_sequence import service
from .lab import ROOT, write_json


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--after',type=Path,required=True)
    parser.add_argument('--config',type=Path,required=True)
    args=parser.parse_args()
    invocation=service('show','pokemon-lab.service','-p','InvocationID','--value')
    record={'after_batch':args.after.name,'after_invocation':invocation,'config':str(args.config),'queued_at':time.time()}
    path=ROOT/'data/queued-scripted-route-v2.json'
    def update(**values):
        record.update(values);write_json(path,record);print(json.dumps(values),flush=True)
    update(stage='queued')
    try:
        limit=time.monotonic()+86400
        while time.monotonic()<limit:
            if service('show','pokemon-lab.service','-p','InvocationID','--value')!=invocation:
                raise RuntimeError('Pinned pilot service invocation changed')
            status=json.loads((args.after/'status.json').read_text())
            if status['stage'] in ('failed','interrupted'):
                raise RuntimeError('Pilot stopped unexpectedly; follow-up will not launch')
            if status['stage']=='complete':
                if len(status['results'])!=len(status['runs']) or any(r['status']!='completed' for r in status['results']):
                    raise RuntimeError('Pilot completion ledger is incomplete')
                break
            time.sleep(5)
        else:raise TimeoutError('Queue expired after24h')
        config=json.loads(args.config.read_text())
        if config.get('scripted_variant')!='red-parcel-route-v2' or config.get('policies')!=['scripted']:
            raise ValueError('Unexpected follow-up selector')
        freeze=json.loads(Path(config['freeze_file']).read_text())
        for name,expected in freeze['sha256'].items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
                raise ValueError('Frozen follow-up file changed: '+name)
        update(stage='starting')
        service('stop','pokemon-lab.service')
        override=Path(f'/run/user/{os.getuid()}/systemd/user/pokemon-lab.service.d/99-scripted-route.conf')
        override.parent.mkdir(parents=True,exist_ok=True)
        override.write_text('[Service]\nExecStart=\nExecStart='+sys.executable+' -m imajev_player.scripted_route_lab --config '+str(args.config)+'\n')
        service('daemon-reload')
        # Start API metadata only; baseline supervisor drains/stops it before play.
        service('start','pokemon-ollama-next.service')
        with httpx.Client(timeout=2) as http:
            for _ in range(30):
                try:
                    http.get(config['model_url']+'/api/tags').raise_for_status();break
                except httpx.HTTPError:time.sleep(1)
            else:raise RuntimeError('Model metadata API unavailable')
        subprocess.run([sys.executable,'-m','imajev_player.scripted_route_lab','--config',str(args.config),'--preflight'],check=True,timeout=60,capture_output=True)
        service('start','pokemon-lab.service')
        with httpx.Client(timeout=3) as http:
            for _ in range(60):
                try:
                    r=http.get('http://127.0.0.1:'+str(config['dashboard_port'])+'/api/status');r.raise_for_status();new=r.json()
                    if new['batch_id']!=args.after.name:
                        if new['stage'] in ('failed','interrupted'):raise RuntimeError('Follow-up failed startup')
                        if new.get('current'):
                            update(stage='started',batch_id=new['batch_id'],started_at=time.time());return
                except httpx.HTTPError:pass
                time.sleep(1)
            raise RuntimeError('Follow-up did not start')
    except Exception as exc:
        update(stage='failed',error=repr(exc));raise


if __name__=='__main__':main()
