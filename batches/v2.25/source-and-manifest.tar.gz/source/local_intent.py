"""Per-run local destination retained through battle and dialogue interruptions."""
from .navigation import choices, interrupted


class LocalIntent:
    def __init__(self):
        self.pending = None
        self.failed = {}

    def exclusions(self, state):
        mid = state.get('map', {}).get('map_id')
        pos = state.get('player', {}).get('position', {})
        for action, failure in list(self.failed.items()):
            old = failure['position']
            moved = (pos and old and abs(pos['x']-old['x']) + abs(pos['y']-old['y']) >= 4)
            if mid != failure['map_id'] or moved:
                del self.failed[action]
        return list(self.failed)

    def context(self, state):
        if self.pending:
            p = self.pending
            changed = (state.get('map', {}).get('map_id') != p['map_id'] or
                       state.get('verified_objective', {}).get('id') != p['objective'])
            blocked = not interrupted(state) and p['action'] not in choices(state)
            if changed or blocked:
                self.pending = None
        return dict(self.pending) if self.pending else None

    def record(self, action, result, state):
        if not action.startswith('go:'):
            return
        failed = result.get('reason') in ('movement_cycle', 'blocked') or (
            result.get('reason') == 'step_limit' and result.get('end_position') is not None
            and result['end_position'] == state.get('player', {}).get('position'))
        if failed:
            self.failed[action] = {'map_id': state.get('map', {}).get('map_id'),
                                   'position': result.get('end_position') or state.get('player', {}).get('position', {})}
            if len(self.failed) > 32:
                del self.failed[next(iter(self.failed))]
            self.pending = None
            return
        if result.get('reason') not in ('dialogue_or_battle', 'step_limit'):

            self.pending = None
            return
        if (result.get('reason') == 'dialogue_or_battle'
                and not result.get('interrupted_in_battle', True)
                and result.get('end_position') == state.get('player', {}).get('position')):
            self.pending = None
            return
        previous = self.pending or {}
        attempts = previous.get('attempts', 0) + 1 if previous.get('action') == action else 1
        # Bound repeated resumptions even when an exit is broken or repeatedly interrupted.
        self.pending = ({'action': action, 'map_id': state['map']['map_id'],
                         'objective': state.get('verified_objective', {}).get('id'),
                         'attempts': attempts, 'status': 'paused; resume when overworld is ready'}
                        if attempts <= 12 else None)
