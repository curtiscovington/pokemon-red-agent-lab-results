"""Same compact post-run checks for every policy, including successful runs."""
import json
from collections import Counter


def audit_run(folder):
    summary = json.loads((folder / 'summary.json').read_text())
    outcomes = json.loads((folder / 'outcome-metrics.json').read_text())
    offered = None
    counts = Counter()
    rules = Counter()
    selected = []
    flagged = []
    badge_text = []
    first_badge = None
    for line_number, line in enumerate((folder / 'events.jsonl').open(), 1):
        e = json.loads(line)
        kind = e['type']
        elapsed = e.get('elapsed')
        if kind == 'request':
            offered = e['request']['format']['properties']['action']['enum']
            counts['requests'] += 1
            tags = e.get('decision', {})
            for k, v in tags.items():
                if v is True:
                    counts['request_' + k] += 1
            if counts['requests'] == 1 or counts['requests'] % 100 == 0:
                selected.append({'line': line_number, 'elapsed': elapsed, 'kind': kind})
        if kind == 'response' and offered is not None:
            counts['responses'] += 1
            try:
                a = json.loads(e['response']['message']['content'])['action']
                if a not in offered:
                    counts['outside_enum'] += 1
            except (ValueError, KeyError, TypeError):
                counts['malformed'] += 1
            if e['response'].get('policy_rule'):
                rules[e['response']['policy_rule']] += 1
        if kind in ('error', 'failure', 'stale_action_discarded', 'late_response_ignored'):
            counts[kind] += 1
            if len(flagged) < 64:
                flagged.append({'line': line_number, 'elapsed': elapsed, 'kind': kind})
        if kind == 'action_completed':
            reason = e.get('result', {}).get('reason')
            if reason in ('movement_cycle', 'blocked', 'step_limit', 'unavailable', 'unchanged'):
                counts[reason] += 1
                if len(flagged) < 64:
                    flagged.append({'line': line_number, 'elapsed': elapsed, 'kind': reason})
        state = e.get('state') or {}
        text = ' '.join((state.get('interface') or {}).get('text', []))
        if elapsed is not None and 0 <= elapsed <= summary['duration_seconds']:
            if 'BOULDER' in text.upper() and len(badge_text) < 3:
                badge_text.append({'elapsed': elapsed, 'text': text, 'line': line_number})
            if (state.get('player') or {}).get('badges') and first_badge is None:
                first_badge = {'elapsed': elapsed, 'line': line_number}
    return {'version': 'policy-audit-v1', 'run': summary['run_id'], 'policy': summary['policy'],
            'counts': dict(counts), 'script_rules': dict(rules),
            'milestones': outcomes['first_observed_seconds'], 'first_badge': first_badge,
            'badge_dialogue': badge_text, 'fixed_trace_samples': selected,
            'flagged_trace_samples': flagged,
            'sampling': 'First request and every 100th request; first 64 error/stale/navigation-failure events. Counts cover all events. References are 1-based JSONL lines; no duplicate screenshots.',
            'manual_review': 'pending', 'status': summary['status'],
            'resource_affected': summary.get('resource_affected', False)}
