"""Deterministic immediate-damage heuristic using public Gen-I species/move data.

No hidden battle stats: estimate unobserved stats with neutral DVs and zero EVs.
Not a full battle simulator; ignores stat stages, critical hits and future setup.
"""
import json
import re
from pathlib import Path

DATA = json.loads(Path(__file__).with_name('combat_data.json').read_text())
SPECIAL = {'FIRE', 'WATER', 'GRASS', 'ELECTRIC', 'ICE', 'PSYCHIC_TYPE', 'DRAGON'}


def key(name):
    return re.sub('[^A-Z0-9]', '', str(name).upper()).replace('NIDORAN♀', 'NIDORANF')


def stats(mon):
    name = str(mon.get('species', '')).replace('♀', 'F').replace('♂', 'M')
    return DATA['species'].get(key(name), {})


def estimate(move, attacker, enemy):
    """Expected capped immediate damage per turn, approximate Gen-I mechanics."""
    own, foe = stats(attacker), stats(enemy)
    typ = move['type']
    mult = 1
    for t in foe.get('types', []):
        mult *= DATA['matchups'].get(typ + ':' + t, 1)
    if not mult:
        return 0
    level = attacker.get('level', 5)
    name, effect = move['name'], move['effect']
    if name in ('SEISMIC_TOSS', 'NIGHT_SHADE'):
        damage = level
    elif name in ('DRAGON_RAGE', 'SONICBOOM'):
        damage = 40 if name == 'DRAGON_RAGE' else 20
    elif move['power'] <= 1:
        return 0  # no setup spam, OHKO/Counter semantics not approximated as damage
    else:
        special = typ in SPECIAL
        attack_key, defense_key = ('special', 'special') if special else ('attack', 'defense')
        attack = (2 * (own.get(attack_key, 50) + 8) * level // 100) + 5
        defense = (2 * (foe.get(defense_key, 50) + 8) * enemy.get('level', level) // 100) + 5
        if not special and 'burn' in str(attacker.get('status', '')).lower():
            attack = max(1, attack // 2)
        damage = ((2 * level // 5 + 2) * move['power'] * attack / max(1, defense) / 50 + 2)
        damage *= (1.5 if typ in own.get('types', []) else 1) * mult * .925
        if effect == 'TWO_TO_FIVE_ATTACKS_EFFECT':damage *= 3
        elif effect in ('ATTACK_TWICE_EFFECT', 'TWINEEDLE_EFFECT'):damage *= 2
        if effect in ('CHARGE_EFFECT', 'FLY_EFFECT', 'HYPER_BEAM_EFFECT'):damage /= 2
        if effect == 'EXPLODE_EFFECT':damage *= .25  # avoid sacrificing the only starter
    return min(damage, enemy.get('hp') or damage) * min(move['accuracy'] / 100, 255 / 256)


def choose_attack(context, actions):
    state = context['state']
    battle = state.get('battle') or {}
    if not battle.get('in_battle'):
        return None
    # This protocol starts with a single starter. Match visible battle name when
    # possible; otherwise first conscious party member. No unseen active-index read.
    party = [p for p in state.get('party', []) if p.get('hp', 0) > 0]
    if not party:return None
    text = {key(t) for t in (state.get('interface') or {}).get('text', [])}
    attacker = next((p for p in party if key(p.get('species')) in text), party[0])
    moves = {key(m.get('name')):m for m in attacker.get('moves', [])}
    choices = []
    for action in actions:
        if not action.startswith(('use:', 'select:')):continue
        name = key(action.split(':', 1)[1]); known = moves.get(name)
        if known is None or known.get('pp', 0) <= 0:continue
        move = DATA['moves'].get(name)
        if move:
            score = estimate(move, attacker, battle.get('enemy') or {})
            if score > 0:choices.append((score, known['pp'], action))
    if choices:
        # Stable offered order breaks equal damage/PP ties.
        return max(choices, key=lambda c: (c[0], c[1]))[2], 'expected_damage'
    return None
