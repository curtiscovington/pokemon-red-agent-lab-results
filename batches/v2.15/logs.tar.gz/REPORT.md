# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-reactive-f41bbce8 | reactive | evidence | completed | 435 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 02-reactive-54650491 | reactive | evidence | completed | 242 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 03-reactive-3df4c6d7 | reactive | evidence | completed | 295 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 04-reactive-b36f68eb | reactive | evidence | completed | 444 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 05-reactive-62f1cdad | reactive | evidence | completed | 436 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 06-reactive-268d2cfa | reactive | evidence | completed | 371 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 07-reactive-fc758106 | reactive | evidence | completed | 393 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 08-reactive-c56722d9 | reactive | evidence | completed | 458 | party_observed, provisional_has_parcel, provisional_has_pokedex |

Interpretation: pending review of saved frames and event logs.
Batch status: complete
