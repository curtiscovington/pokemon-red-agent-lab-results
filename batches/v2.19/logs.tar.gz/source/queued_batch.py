"""Start one configured batch after a pinned existing batch completes."""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import httpx

from .experiment_sequence import service
from .lab import ROOT, write_json


def completed(status):
    if status['stage'] in {'failed', 'interrupted'}:
        raise RuntimeError('Previous batch stopped unexpectedly; queued launch cancelled')
    return status['stage'] == 'complete' and len(status['results']) == len(status['runs'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--after', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    invocation = service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value')
    audit = ROOT / 'data/queued-batch.json'
    record = {'after_batch': args.after.name, 'config': str(args.config), 'queued_at': time.time()}

    def update(**values):
        record.update(values)
        write_json(audit, record)
        print(json.dumps(values), flush=True)

    update(stage='queued')
    try:
        expires = time.monotonic() + 43200
        while time.monotonic() < expires:
            if service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value') != invocation:
                raise RuntimeError('Pinned lab invocation changed; refusing to interrupt another batch')
            status = json.loads((args.after / 'status.json').read_text())
            if completed(status):
                break
            time.sleep(5)
        else:
            raise TimeoutError('Queued launch expired after 12 hours')
        update(stage='starting')
        service('stop', 'pokemon-stream-watch.service')
        service('stop', 'pokemon-lab.service')
        override = Path(f'/run/user/{os.getuid()}/systemd/user/pokemon-lab.service.d/80-four-run.conf')
        # Replace the previous four-run command only after it has finished.
        override.parent.mkdir(parents=True, exist_ok=True)
        override.write_text('[Service]\nExecStart=\nExecStart=' + sys.executable
                            + ' -m imajev_player.lab --config ' + str(args.config) + '\n')
        service('daemon-reload')
        service('restart', 'pokemon-controller.service')
        service('start', 'pokemon-ollama-next.service')
        with httpx.Client(timeout=2) as ready:
            for _ in range(30):
                try:
                    ready.get('http://127.0.0.1:11436/api/tags').raise_for_status()
                    ready.get('http://127.0.0.1:9876/api/status').raise_for_status()
                    break
                except httpx.HTTPError:
                    time.sleep(1)
            else:
                raise RuntimeError('Controller/model API did not become ready')
        subprocess.run([sys.executable, '-m', 'imajev_player.lab', '--config', str(args.config),
                        '--preflight'], check=True, timeout=60, capture_output=True)
        service('start', 'pokemon-lab.service')
        with httpx.Client(timeout=3) as http:
            for _ in range(60):
                try:
                    response = http.get('http://127.0.0.1:9877/api/status')
                    response.raise_for_status()
                    new = response.json()
                    if new['batch_id'] != args.after.name:
                        if new['stage'] in {'failed', 'interrupted'}:
                            raise RuntimeError('New batch failed startup')
                        if new.get('current'):
                            break
                except httpx.HTTPError:
                    pass
                time.sleep(1)
            else:
                raise RuntimeError('New batch did not start')
        write_json(ROOT / 'data/stream-watch.json', {
            'batch': str(ROOT / 'data/lab' / new['batch_id']), 'tail_seconds': 30,
            'lab_invocation_id': service('show', 'pokemon-lab.service', '-p', 'InvocationID', '--value'),
        })
        service('restart', 'pokemon-stream-watch.service')
        update(stage='started', batch_id=new['batch_id'], started_at=time.time())
        with (ROOT / 'RESEARCH-NOTES.md').open('a') as notes:
            notes.write('\nQueued batch started: ' + new['batch_id']
                        + ' after ' + args.after.name + '. Config: ' + str(args.config) + '.\n')
    except Exception as exc:
        update(stage='failed', error=repr(exc))
        raise


if __name__ == '__main__':
    main()
