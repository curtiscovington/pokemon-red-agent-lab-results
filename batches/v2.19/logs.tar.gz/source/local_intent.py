"""Per-run local destination retained through battle and dialogue interruptions."""
from .navigation import choices, interrupted


class LocalIntent:
    def __init__(self):
        self.pending = None

    def context(self, state):
        if self.pending:
            p = self.pending
            changed = (state.get('map', {}).get('map_id') != p['map_id'] or
                       state.get('verified_objective', {}).get('id') != p['objective'])
            blocked = not interrupted(state) and p['action'] not in choices(state)
            if changed or blocked:
                self.pending = None
        return dict(self.pending) if self.pending else None

    def record(self, action, result, state):
        if not action.startswith('go:'):
            return
        if result.get('reason') not in ('dialogue_or_battle', 'step_limit'):
            self.pending = None
            return
        previous = self.pending or {}
        attempts = previous.get('attempts', 0) + 1 if previous.get('action') == action else 1
        # Bound repeated resumptions even when an exit is broken or repeatedly interrupted.
        self.pending = ({'action': action, 'map_id': state['map']['map_id'],
                         'objective': state.get('verified_objective', {}).get('id'),
                         'attempts': attempts, 'status': 'paused; resume when overworld is ready'}
                        if attempts <= 12 else None)
