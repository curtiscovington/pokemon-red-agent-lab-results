"""Bounded, post-run diagnostics derived from existing events; no extra game/model calls."""
import argparse
import hashlib
import json
from collections import deque
from pathlib import Path

from .outcome_metrics import analyze_outcomes


def analyze(path):
    result = {'version': 2, 'retained_route_decisions': 0, 'route_cancellations': 0, 'replan_decisions': 0, 'healing_decisions': 0, 'repeated_interaction_blocks': 0, 'completed_actions': 0, 'cycle_actions': 0, 'cycle_episodes': 0,
                  'longest_cycle_seconds': 0, 'notebook_updates': 0, 'goal_changes': 0,
                  'unchanged_goal_updates': 0, 'reconsideration_episodes': 0,
                  'reconsideration_changed_action': 0, 'reconsideration_changed_context': 0,
                  'reconsideration_milestone': 0, 'reconsideration_windows_completed': 0,
                  'reconsideration_windows_censored': 0, 'response_output_tokens': 0,
                  'response_seconds': 0, 'memory_field_characters': 0}
    recent = deque(maxlen=9)
    signature = None
    goal = None
    cycle_start = None
    last_time = 0
    previous_action = None
    pending = None
    signaled = False

    def close_window(censored=False):
        nonlocal pending
        if pending is not None:
            result['reconsideration_windows_censored' if censored else
                   'reconsideration_windows_completed'] += 1
            for key in ('changed_action', 'changed_context', 'milestone'):
                result['reconsideration_' + key] += int(pending[key])
            pending = None

    with Path(path).open() as source:
        for line in source:
            if not line.endswith('\n'):
                break
            e = json.loads(line)
            t = e.get('elapsed')
            if t is None:
                continue
            last_time = t
            kind = e['type']
            if kind == 'observation':
                state = e['state']
                evidence = {k: state.get(k) for k in ('map', 'party', 'bag', 'interface', 'battle')}
                evidence['position'] = state.get('player', {}).get('position')
                signature = hashlib.sha256(json.dumps(evidence, sort_keys=True).encode()).hexdigest()
                if pending and signature != pending['context']:
                    pending['changed_context'] = True
            elif kind == 'request':
                content = e['request']['messages'][0]['content']
                start = content.find('{"state":')
                request_context = json.loads(content[start:]) if start >= 0 else {}
                notebook = request_context.get('repeat_feedback', request_context.get('notebook', {}))
                result['retained_route_decisions'] += int(bool(request_context.get('walking_destination')))
                recovery = request_context.get('progress_control', {})
                result['repeated_interaction_blocks'] += int(bool(recovery.get('repeated_interaction_actions')))
                result['replan_decisions'] += int(bool(recovery.get('replan')))
                result['healing_decisions'] += int(bool(recovery.get('healing')))
                signal = bool(notebook.get('reconsider'))
                if signal and not signaled:
                    close_window(censored=True)
                    result['reconsideration_episodes'] += 1
                    pending = {'context': signature, 'action': previous_action, 'count': 0,
                                   'changed_action': False, 'changed_context': False, 'milestone': False}
                signaled = signal
            elif kind == 'local_route_cancelled':
                result['route_cancellations'] += 1
            elif kind == 'response':
                payload = e['response']
                result['response_output_tokens'] += payload.get('eval_count') or 0
                result['response_seconds'] += e.get('latency_seconds', 0)
                try:
                    answer = json.loads(payload.get('message', {}).get('content', ''))
                except (ValueError, TypeError):
                    answer = {}
                if isinstance(answer, dict):
                    result['memory_field_characters'] += sum(len(answer[k]) for k in
                        ('objective', 'note', 'next_step', 'success_check', 'blocker', 'status')
                        if isinstance(answer.get(k), str))
            elif kind == 'milestone_evidence' and pending:
                pending['milestone'] = True
            elif kind == 'memory_updated':
                n = e['notebook']
                current = (n.get('model_objective'), (n.get('model_plan') or {}).get('next_step'))
                result['notebook_updates'] += 1
                result['unchanged_goal_updates' if current == goal else 'goal_changes'] += 1
                goal = current
            elif kind == 'action_completed':
                action = e['action']
                result['completed_actions'] += 1
                recent.append((signature, action, t))
                items = [(s, a) for s, a, _ in recent]
                period = next((p for p in (1, 2, 3) if len(items) >= 3*p and
                               items[-p:] == items[-2*p:-p] == items[-3*p:-2*p]), None)
                if period:
                    result['cycle_actions'] += 1
                    if cycle_start is None:
                        result['cycle_episodes'] += 1
                        cycle_start = list(recent)[-3*period][2]
                    result['longest_cycle_seconds'] = max(result['longest_cycle_seconds'], t-cycle_start)
                else:
                    cycle_start = None
                if pending:
                    pending['count'] += 1
                    pending['changed_action'] |= action != pending['action']
                    if pending['count'] >= 10:
                        close_window()
                previous_action = action
    close_window(censored=True)
    result['observed_seconds'] = round(last_time, 2)
    for key in ('longest_cycle_seconds', 'response_seconds'):
        result[key] = round(result[key], 2)
    return result


def write_metrics(folder):
    folder = Path(folder)
    result = analyze(folder / 'events.jsonl')
    outcomes = analyze_outcomes(folder / 'events.jsonl')
    (folder / 'outcome-metrics.json').write_text(json.dumps(outcomes, indent=2) + '\n')
    (folder / 'behavior-metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('batch', type=Path)
    args = parser.parse_args()
    for summary in sorted(args.batch.glob('*/summary.json')):
        write_metrics(summary.parent)
