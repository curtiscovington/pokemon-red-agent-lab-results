# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-reactive-52fbfeaa | reactive | evidence | completed | 663 | None |
| 02-reactive-271189e2 | reactive | evidence | completed | 385 | party_observed, provisional_has_parcel |
| 03-reactive-fef5c27f | reactive | evidence | completed | 353 | party_observed, provisional_has_parcel |
| 04-reactive-43f195fe | reactive | evidence | completed | 286 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 05-reactive-8617ba33 | reactive | evidence | completed | 286 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 06-reactive-f651c61a | reactive | evidence | completed | 633 | None |
| 07-reactive-0b9a132d | reactive | evidence | completed | 409 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 08-reactive-e49104cd | reactive | evidence | completed | 702 | party_observed, provisional_has_parcel, provisional_has_pokedex |

Interpretation: pending review of saved frames and event logs.
Batch status: complete
