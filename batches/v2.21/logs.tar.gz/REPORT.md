# One-hour lab results

Raw pilot results; story flags remain provisional.

| Run | Policy | Memory | Status | Actions | Milestone evidence |
|---|---|---|---|---:|---|
| 01-reactive-299e5504 | reactive | evidence | completed | 468 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 02-reactive-1f47de99 | reactive | evidence | completed | 401 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 03-reactive-a9da5339 | reactive | evidence | completed | 404 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 04-reactive-bafee48d | reactive | evidence | completed | 373 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 05-reactive-8df9229a | reactive | evidence | completed | 357 | party_observed, provisional_has_parcel, provisional_has_pokedex |
| 06-reactive-b82a12d0 | reactive | evidence | completed | 363 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 07-reactive-61ce49e4 | reactive | evidence | completed | 403 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |
| 08-reactive-dd1aa736 | reactive | evidence | completed | 408 | party_observed, provisional_has_parcel, provisional_has_pokedex, badges_observed |

Interpretation: pending review of saved frames and event logs.
Batch status: complete
